package blbl.cat3399.testutil.json


class TestJSONArray {
    private val items: MutableList<Any?> = ArrayList()

    fun put(value: Any?): TestJSONArray {
        items.add(value)
        return this
    }

    fun length(): Int = items.size

    fun optJSONObject(index: Int): TestJSONObject? = items.getOrNull(index) as? TestJSONObject

    fun optJSONArray(index: Int): TestJSONArray? = items.getOrNull(index) as? TestJSONArray
}
