package blbl.cat3399.feature.upload

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.UploadApi
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.model.VideoCard
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.popup.AppPopup
import blbl.cat3399.databinding.ActivityMyVideosBinding
import blbl.cat3399.feature.video.VideoCardAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MyVideosActivity : AppCompatActivity() {
    private var _binding: ActivityMyVideosBinding? = null
    private val binding get() = _binding!!

    private val adapter = VideoCardAdapter(onClick = ::openVideo, onLongClick = ::editVideo)
    private var page = 1
    private var loading = false
    private var hasMore = true
    private var selfMid = 0L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMyVideosBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener { finish() }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(this, "请先登录")
            finish()
            return
        }
        selfMid = BiliClient.cookies.getCookieValue("DedeUserID")?.toLongOrNull() ?: 0L
        if (selfMid <= 0L) {
            AppToast.show(this, "无法获取账号信息")
            finish()
            return
        }
        loadMore()
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_MENU) {
            val pos = binding.recycler.findFocusIndex()
            val card = if (pos >= 0) adapter.snapshot().getOrNull(pos) else null
            if (card != null) {
                editVideo(card, pos)
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    private fun loadMore() {
        if (loading || !hasMore) return
        loading = true
        binding.tvStatus.visibility = if (adapter.snapshot().isEmpty()) View.VISIBLE else View.GONE
        lifecycleScope.launch {
            try {
                val res =
                    withContext(Dispatchers.IO) {
                        BiliApi.spaceArcSearchPage(mid = selfMid, pn = page, ps = 30)
                    }
                if (res.items.isNotEmpty()) adapter.append(res.items)
                hasMore = res.hasMore
                if (res.items.isNotEmpty()) page++
                binding.tvStatus.visibility = View.GONE
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("MyVideos", "load failed", t)
                binding.tvStatus.text = "加载失败：" + ((t as? blbl.cat3399.core.api.BiliApiException)?.apiMessage ?: t.message)
                binding.tvStatus.visibility = View.VISIBLE
            } finally {
                loading = false
            }
        }
    }

    private fun openVideo(card: VideoCard, _pos: Int) {
        val intent = Intent(this, blbl.cat3399.feature.video.VideoDetailActivity::class.java)
        intent.putExtra("bvid", card.bvid)
        startActivity(intent)
    }

    private fun editVideo(card: VideoCard, _pos: Int): Boolean {
        if (!BiliClient.cookies.hasSessData()) return true
        val aid = card.aid ?: 0L
        if (aid <= 0L) {
            AppToast.show(this, "该稿件缺少 aid，无法编辑")
            return true
        }
        
        val handle =
            AppPopup.progress(
                context = this,
                title = "加载中",
                status = "正在读取稿件信息…",
                negativeText = "取消",
                cancelable = false,
            )
        lifecycleScope.launch {
            try {
                val detail =
                    withContext(Dispatchers.IO) { BiliApi.videoDetail(aid) }
                handle?.dismiss()
                if (isFinishing || isDestroyed) return@launch
                val title0 = detail.title?.trim()?.takeIf { it.isNotBlank() } ?: card.title
                val desc0 = detail.description?.trim().orEmpty()
                askTitle(aid, title0, desc0, card, 1)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                handle?.dismiss()
                AppToast.show(this@MyVideosActivity, "读取稿件失败：" + ((t as? blbl.cat3399.core.api.BiliApiException)?.apiMessage ?: t.message))
            }
        }
        return true
    }

    private fun askTitle(aid: Long, title0: String, desc0: String, card: VideoCard, step: Int) {
        if (step > 3) return
        val isTitle = step == 1
        val isDesc = step == 2
        val isTag = step == 3
        AppPopup.input(
            context = this,
            title = if (isTitle) "编辑标题" else if (isDesc) "编辑简介" else "编辑标签",
            initial = if (isTitle) title0 else if (isDesc) desc0 else "",
            hint = if (isTitle) "稿件标题" else if (isDesc) "稿件简介（可留空）" else "标签，用逗号分隔",
            inputType = if (isDesc) android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_FLAG_MULTI_LINE else android.text.InputType.TYPE_CLASS_TEXT,
            minLines = if (isDesc) 3 else 1,
            validate = { if (isTitle) it.isNotBlank() else true },
            onPositive = { text ->
                if (isTitle) {
                    askTitle(aid, text.trim(), desc0, card, 2)
                } else if (isDesc) {
                    askTitle(aid, title0, text.trim(), card, 3)
                } else {
                    submitEdit(aid, title0, desc0, text.trim())
                }
            },
        )
    }

    private fun submitEdit(aid: Long, title: String, desc: String, tag: String) {
        val handle =
            AppPopup.progress(
                context = this,
                title = "保存中",
                status = "正在更新稿件…",
                negativeText = "取消",
                cancelable = false,
            )
        lifecycleScope.launch {
            try {
                val ok =
                    withContext(Dispatchers.IO) {
                        UploadApi.editVideo(
                            aid = aid,
                            title = title,
                            desc = desc,
                            tag = tag.ifBlank { "生活" },
                        )
                    }
                handle?.dismiss()
                AppToast.show(this@MyVideosActivity, if (ok) "稿件已更新" else "更新失败：接口无返回")
                if (ok) loadMore()
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                handle?.dismiss()
                val msg = (t as? blbl.cat3399.core.api.BiliApiException)?.apiMessage?.takeIf { it.isNotBlank() } ?: t.message.orEmpty()
                AppToast.show(this@MyVideosActivity, "更新失败：${msg.take(80)}")
            }
        }
    }
}

private fun androidx.recyclerview.widget.RecyclerView.findFocusIndex(): Int {
    val focus = focusedChild ?: return -1
    return getChildAdapterPosition(focus)
}
