package blbl.cat3399.feature.player

import android.view.View
import blbl.cat3399.R
import blbl.cat3399.databinding.ActivityPlayerBinding


internal object PlayerOsdHoverLabel {
    private val LABEL_BY_ID: Map<Int, String> =
        mapOf(
            R.id.btn_play_pause to "播放/暂停",
            R.id.btn_prev to "上一个",
            R.id.btn_next to "下一个",
            R.id.btn_subtitle to "字幕",
            R.id.btn_danmaku to "弹幕开关",
            R.id.btn_send_danmaku to "发送弹幕",
            R.id.btn_download to "下载视频",
            R.id.btn_comments to "评论",
            R.id.btn_up to "UP主主页",
            R.id.btn_like to "点赞",
            R.id.btn_coin to "投币",
            R.id.btn_fav to "收藏",
            R.id.btn_dislike to "不感兴趣",
            R.id.btn_share to "分享",
            R.id.btn_video_mode to "画音切换",
            R.id.btn_shuffle to "刷视频模式",
            R.id.btn_list_panel to "播放列表",
            R.id.btn_detail to "视频详情",
            R.id.btn_sponsor_submit to "赞助",
            R.id.btn_advanced to "设置",
            R.id.btn_close_player to "关闭播放器",
            R.id.btn_live_rank to "贡献榜",
            R.id.btn_live_comment_style to "评论区样式",
            R.id.btn_loop to "循环播放",
            R.id.btn_rotate to "视频旋转",
            R.id.btn_season to "视频合集",
            R.id.fm_loop to "循环播放",
            R.id.fm_comments to "评论",
            R.id.fm_video_mode to "画音切换",
            R.id.btn_up_quick_profile to "UP主主页",
            R.id.btn_up_quick_follow to "关注UP主",
            R.id.fm_prev to "上一个",
            R.id.fm_play to "播放/暂停",
            R.id.fm_next to "下一个",
        )

    fun install(binding: ActivityPlayerBinding) {
        val label = binding.tvOsdHover
        val views = collectViews(binding)
        for (view in views) {
            val text = LABEL_BY_ID[view.id] ?: continue
            val prev = view.onFocusChangeListener
            view.onFocusChangeListener =
                View.OnFocusChangeListener { v, hasFocus ->
                    prev?.onFocusChange(v, hasFocus)
                    if (hasFocus) {
                        label.text = text
                        label.visibility = View.VISIBLE
                    } else if (label.visibility == View.VISIBLE) {
                        label.visibility = View.GONE
                    }
                }
        }
    }

    fun hide(binding: ActivityPlayerBinding) {
        binding.tvOsdHover.visibility = View.GONE
    }

    private fun collectViews(binding: ActivityPlayerBinding): List<View> {
        val out = ArrayList<View>()
        fun add(view: View?) {
            if (view != null) out.add(view)
        }
        val row = binding.controlsRow
        for (i in 0 until row.childCount) {
            add(row.getChildAt(i))
        }
        add(binding.btnUpQuickProfile)
        add(binding.btnUpQuickFollow)
        add(binding.fmPrev)
        add(binding.fmPlay)
        add(binding.fmNext)
        return out
    }
}
