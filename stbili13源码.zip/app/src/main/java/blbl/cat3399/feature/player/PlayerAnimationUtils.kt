package blbl.cat3399.feature.player

import android.view.View
import android.view.animation.DecelerateInterpolator


internal fun View.playActionPop() {
    if (visibility != View.VISIBLE) return
    animate().cancel()
    scaleX = 1f
    scaleY = 1f
    animate()
        .scaleX(1.32f)
        .scaleY(1.32f)
        .setDuration(140)
        .withEndAction {
            animate()
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(200)
                .setInterpolator(DecelerateInterpolator())
                .start()
        }
        .start()
}


internal fun View.playPanelSlideIn() {
    alpha = 0f
    translationX = resources.displayMetrics.widthPixels * 0.18f
    animate()
        .alpha(1f)
        .translationX(0f)
        .setDuration(220)
        .setInterpolator(DecelerateInterpolator())
        .start()
}


internal fun View.playPanelSlideOut(onEnd: () -> Unit = {}) {
    animate()
        .alpha(0f)
        .translationX(resources.displayMetrics.widthPixels * 0.1f)
        .setDuration(180)
        .withEndAction(onEnd)
        .start()
}
