package blbl.cat3399.feature.login

import android.annotation.SuppressLint
import android.graphics.Bitmap
import android.os.Bundle
import android.view.KeyEvent
import android.webkit.CookieManager
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.net.CookieStore
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.cloneInUserScale
import blbl.cat3399.databinding.ActivityWebLoginBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import okhttp3.Cookie


class WebLoginActivity : BaseActivity() {
    private var _binding: ActivityWebLoginBinding? = null
    private val binding get() = _binding!!
    private var pollJob: Job? = null
    private var successHandled = false

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityWebLoginBinding.inflate(layoutInflater.cloneInUserScale(this))
        setContentView(binding.root)
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnReload.setOnClickListener { binding.webView.reload() }

        val web = binding.webView
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadWithOverviewMode = true
        web.settings.useWideViewPort = true
        web.settings.mixedContentMode = android.webkit.WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        web.settings.userAgentString =
            "Mozilla/5.0 (Linux; Android 12; TV) AppleWebKit/537.36 " +
                "(KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36 BiliDroid/7.66.0"
        web.webViewClient =
            object : WebViewClient() {
                override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                    binding.tvStatus.text = "登录中…"
                }

                override fun onPageFinished(view: WebView?, url: String?) {
                    binding.tvStatus.text = "扫码或短信登录后自动保存并返回"
                    
                    view?.evaluateJavascript(TV_NAV_JS, null)
                    
                    val cookieHeader =
                        runCatching { CookieManager.getInstance().getCookie("https://www.bilibili.com") }
                            .getOrNull().orEmpty()
                    if (cookieHeader.contains("SESSDATA=") && !cookieHeader.contains("SESSDATA=deleted;")) {
                        tryImport(cookieHeader)
                    }
                }

                override fun onReceivedError(
                    view: WebView?,
                    errorCode: Int,
                    description: String?,
                    failingUrl: String?,
                ) {
                    binding.tvStatus.text = "加载失败($errorCode)，按重试"
                }
            }
        web.loadUrl("https://passport.bilibili.com/h5/login")
        startCookiePolling()
    }

    private fun tryImport(cookieHeader: String) {
        if (successHandled) return
        lifecycleScope.launch {
            val ok = importWebCookies(cookieHeader)
            if (ok && !successHandled) {
                successHandled = true
                pollJob?.cancel()
                AppToast.show(this@WebLoginActivity, "登录成功")
                finish()
            }
        }
    }

    private fun startCookiePolling() {
        pollJob?.cancel()
        pollJob =
            lifecycleScope.launch {
                while (isActive) {
                    delay(1000L)
                    val cookieHeader = runCatching {
                        CookieManager.getInstance().getCookie("https://www.bilibili.com")
                    }.getOrNull().orEmpty()
                    if (cookieHeader.contains("SESSDATA=") && !cookieHeader.contains("SESSDATA=deleted;")) {
                        val ok = importWebCookies(cookieHeader)
                        if (ok && !successHandled) {
                            successHandled = true
                            pollJob?.cancel()
                            runOnUiThread {
                                AppToast.show(this@WebLoginActivity, "登录成功")
                                finish()
                            }
                            return@launch
                        }
                    }
                }
            }
    }

    
    private suspend fun importWebCookies(cookieHeader: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val list = ArrayList<Cookie>()
            cookieHeader.split(";").forEach { pair ->
                val kv = pair.trim().split("=", limit = 2)
                if (kv.size != 2 || kv[0].isBlank()) return@forEach
                val name = kv[0].trim()
                val value = kv[1].trim()
                if (name.isBlank() || value.isBlank()) return@forEach
                val cookie =
                    Cookie.Builder()
                        .domain("bilibili.com")
                        .path("/")
                        .name(name)
                        .value(value)
                        .expiresAt(Long.MAX_VALUE)
                        .build()
                list.add(cookie)
            }
            if (list.none { it.name == "SESSDATA" }) return@withContext false
            BiliClient.cookies.upsertAll(list)
            val nav = BiliApi.nav()
            val data = nav.optJSONObject("data")
            val mid = data?.optLong("mid", 0L) ?: 0L
            val uname = data?.optString("uname", "").orEmpty()
            val face = data?.optString("face", "")?.takeIf { it.isNotBlank() }
            if (mid > 0L) {
                BiliClient.accounts.saveCurrentSessionAsActive(
                    appPrefs = BiliClient.prefs,
                    cookies = BiliClient.cookies,
                    name = uname,
                    avatarUrl = face,
                    mid = mid,
                )
            }
            AppLog.i("WebLogin", "import cookies ok mid=$mid name=$uname")
            true
        } catch (t: Throwable) {
            AppLog.e("WebLogin", "import failed", t)
            false
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)
        when (event.keyCode) {
            KeyEvent.KEYCODE_BACK -> {
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                    return true
                }
            }
            KeyEvent.KEYCODE_DPAD_UP -> {
                binding.webView.evaluateJavascript("window.scrollBy(0,-140)", null)
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN -> {
                binding.webView.evaluateJavascript("window.scrollBy(0,140)", null)
                return true
            }
            KeyEvent.KEYCODE_DPAD_LEFT -> {
                binding.webView.evaluateJavascript("window.scrollBy(-140,0)", null)
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT -> {
                binding.webView.evaluateJavascript("window.scrollBy(140,0)", null)
                return true
            }
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            -> {
                
                binding.webView.evaluateJavascript(TV_CLICK_JS, null)
                return true
            }
        }
        return super.dispatchKeyEvent(event)
    }

    companion object {
        private const val TV_NAV_JS =
            "window.__tvNavReady=true;" +
                "document.addEventListener('click',function(){},true);true;"
        private const val TV_CLICK_JS =
            "try{" +
                "var e=document.elementFromPoint(window.innerWidth/2,window.innerHeight/2);" +
                "if(e){e.focus();e.click();}" +
                "}catch(err){}true;"
    }

    override fun onDestroy() {
        pollJob?.cancel()
        _binding = null
        super.onDestroy()
    }
}
