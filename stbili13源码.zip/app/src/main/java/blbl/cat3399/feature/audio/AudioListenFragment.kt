package blbl.cat3399.feature.audio

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.core.view.isVisible
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.image.ImageUrl
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.model.VideoCard
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.util.Format
import blbl.cat3399.databinding.FragmentVideoGridBinding
import blbl.cat3399.databinding.ItemAudioListBinding
import blbl.cat3399.feature.player.PlayerActivity
import blbl.cat3399.ui.BackPressHandler
import blbl.cat3399.ui.RefreshKeyHandler
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class AudioListenFragment : Fragment(), RefreshKeyHandler, BackPressHandler {
    private var _binding: FragmentVideoGridBinding? = null
    private val binding get() = _binding!!
    private val adapter = AudioListAdapter()
    private var freshIdx = 1
    private var loading = false
    private var loaded = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentVideoGridBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
        binding.recycler.clearOnScrollListeners()
        binding.recycler.addOnScrollListener(
            object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    if (dy <= 0 || loading) return
                    val lm = recyclerView.layoutManager as? LinearLayoutManager ?: return
                    val last = lm.findLastVisibleItemPosition()
                    if (last >= adapter.itemCount - 8) loadMore()
                }
            },
        )
        binding.swipeRefresh.setOnRefreshListener {
            freshIdx = 1
            loadMore(isRefresh = true)
        }
        if (!loaded) loadMore(isRefresh = true)
    }

    override fun onResume() {
        super.onResume()
        binding.recycler.requestFocus()
    }

    private fun loadMore(isRefresh: Boolean = false) {
        if (loading) return
        loading = true
        val idx = freshIdx
        lifecycleScope.launch {
            try {
                val cards =
                    withContext(Dispatchers.IO) {
                        BiliApi.recommend(freshIdx = idx, ps = 20, fetchRow = 1)
                    }
                if (isRefresh) {
                    adapter.submit(cards)
                    freshIdx = idx + 1
                } else if (idx == freshIdx) {
                    adapter.append(cards)
                    freshIdx = idx + 1
                }
                loaded = true
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("Audio", "load recommend failed", t)
                AppToast.show(requireContext(), "加载失败：${t.message.orEmpty().take(40)}")
            } finally {
                loading = false
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun handleRefreshKey(): Boolean {
        if (loading) return true
        binding.swipeRefresh.isRefreshing = true
        freshIdx = 1
        loadMore(isRefresh = true)
        return true
    }

    override fun handleBackPressed(): Boolean {
        return false
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        fun newInstance() = AudioListenFragment()
    }

    private inner class AudioListAdapter : RecyclerView.Adapter<AudioListAdapter.Vh>() {
        private val items = ArrayList<VideoCard>()

        fun submit(list: List<VideoCard>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        fun append(list: List<VideoCard>) {
            if (list.isEmpty()) return
            val start = items.size
            items.addAll(list)
            notifyItemRangeInserted(start, list.size)
        }

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
            val itemBinding = ItemAudioListBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return Vh(itemBinding)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            val card = items.getOrNull(position) ?: return
            holder.bind(card)
        }

        inner class Vh(
            private val itemBinding: ItemAudioListBinding,
        ) : RecyclerView.ViewHolder(itemBinding.root) {
            init {
                itemBinding.root.setOnClickListener {
                    val card = items.getOrNull(bindingAdapterPosition) ?: return@setOnClickListener
                    startActivity(
                        Intent(requireContext(), PlayerActivity::class.java)
                            .putExtra(PlayerActivity.EXTRA_BVID, card.bvid)
                            .putExtra(PlayerActivity.EXTRA_AID, card.aid ?: -1L)
                            .putExtra(PlayerActivity.EXTRA_AUDIO_ONLY, true),
                    )
                }
            }

            fun bind(card: VideoCard) {
                itemBinding.tvTitle.text = card.title
                itemBinding.tvUp.text = card.ownerName.takeIf { it.isNotBlank() } ?: "-"
                val meta = buildString {
                    card.view?.let { append(Format.count(it)).append("次播放") }
                    if (card.durationSec > 0) {
                        if (isNotEmpty()) append(" · ")
                        append(formatDuration(card.durationSec))
                    }
                }
                itemBinding.tvMeta.text = meta
                itemBinding.ivCover.setImageDrawable(null)
                if (!card.coverUrl.isNullOrBlank()) {
                    ImageLoader.loadInto(itemBinding.ivCover, ImageUrl.cover(card.coverUrl))
                }
            }

            private fun formatDuration(sec: Int): String {
                val m = sec / 60
                val s = sec % 60
                return String.format(java.util.Locale.US, "%d:%02d", m, s)
            }
        }
    }
}
