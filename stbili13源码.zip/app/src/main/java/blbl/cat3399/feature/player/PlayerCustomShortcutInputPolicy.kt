package blbl.cat3399.feature.player

internal object PlayerCustomShortcutInputPolicy {
    
    fun canDispatchInVod(
        hasInteractiveOsd: Boolean,
        hasSidePanel: Boolean,
        hasBottomCardPanel: Boolean,
    ): Boolean {
        return !hasInteractiveOsd && !hasSidePanel && !hasBottomCardPanel
    }

    fun canDispatchInLive(
        hasInteractiveOsd: Boolean,
        hasSettingsPanel: Boolean,
    ): Boolean {
        return !hasInteractiveOsd && !hasSettingsPanel
    }
}
