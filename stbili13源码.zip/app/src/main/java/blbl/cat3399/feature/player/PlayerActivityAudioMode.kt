package blbl.cat3399.feature.player

import android.view.View
import android.widget.SeekBar
import androidx.core.view.isVisible
import blbl.cat3399.R
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.util.Format as BlblFormat
import blbl.cat3399.feature.player.engine.ExoPlayerEngine
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


internal val PlayerActivity.shuffleHistory: java.util.ArrayDeque<String>
    get() = _shuffleHistory

internal fun PlayerActivity.toggleAudioOnlyMode() {
    audioOnlyMode = !audioOnlyMode
    val engine = this.player ?: run {
        AppToast.show(this, "播放器尚未就绪")
        audioOnlyMode = !audioOnlyMode
        return
    }
    applyRenderForEngine(engine, BiliClient.prefs)
    val exo = (engine as? ExoPlayerEngine)?.exoPlayer
    if (exo != null) {
        runCatching {
            exo.trackSelectionParameters =
                exo.trackSelectionParameters
                    .buildUpon()
                    .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, audioOnlyMode)
                    .build()
        }
    }
    if (audioOnlyMode) {
        binding.playerView.isVisible = false
        binding.danmakuView.isVisible = false
        binding.fmPanel.isVisible = true
        startFmMode()
        
        setControlsVisible(false)
    } else {
        binding.fmPanel.isVisible = false
        binding.playerView.isVisible = true
        binding.danmakuView.isVisible = true
        stopFmMode()
    }
    AppToast.show(this, if (audioOnlyMode) "已切换为听视频（FM）" else "已切换为画音模式")
}


internal fun PlayerActivity.startFmMode() {
    refreshFmUi()
    refreshFmDetail()
    updateFmPlayIcon()
    updateFmLoopIcon()
    
    binding.fmPanel.requestFocus()
    binding.fmVideoMode.setOnClickListener {
        toggleAudioOnlyMode()
        AppToast.show(this, "已切换为画音模式")
    }
    binding.fmLoop.setOnClickListener {
        toggleFmLoop()
        setControlsVisible(true)
    }
    binding.fmComments.setOnClickListener {
        showCommentsPanel()
    }
    binding.fmLike.setOnClickListener { onLikeButtonClicked(showControls = false) }
    binding.fmCoin.setOnClickListener { onCoinButtonClicked(showControls = false) }
    binding.fmFav.setOnClickListener { onFavButtonClicked(showControls = false) }

    binding.fmSeek.max = 1000
    binding.fmSeek.setOnSeekBarChangeListener(
        object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (!fromUser) return
                val durMs = player?.duration?.coerceAtLeast(0L) ?: 0L
                val targetMs = durMs * progress / 1000L
                binding.fmTimeStart.text = BlblFormat.clock(targetMs / 1000)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {
                fmSeeking = true
            }

            override fun onStopTrackingTouch(seekBar: SeekBar?) {
                fmSeeking = false
                val durMs = player?.duration?.coerceAtLeast(0L) ?: 0L
                val targetMs = durMs * (seekBar?.progress ?: 0) / 1000L
                runCatching { player?.seekTo(targetMs) }
                showSeekHint(BlblFormat.clock(targetMs / 1000), hold = false)
            }
        },
    )

    binding.fmPlay.setOnClickListener {
        togglePlayPauseFromUser()
        updateFmPlayIcon()
        setControlsVisible(true)
    }
    
    binding.fmPrev.setOnClickListener {
        if (shuffleHistory.isNotEmpty()) {
            shuffleToPrevOrToast()
        } else {
            playPrevByPlaybackMode(userInitiated = true)
        }
        setControlsVisible(true)
    }
    binding.fmNext.setOnClickListener {
        val mode = resolvedPlaybackMode()
        if (BiliClient.prefs.shuffleModeEnabled) {
            playRandomNext(userInitiated = true)
        } else if (mode == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_RECOMMEND || mode == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_NONE) {
            playRecommendedNext(userInitiated = true)
        } else {
            playNextByPlaybackMode(userInitiated = true)
        }
        setControlsVisible(true)
    }

    
    val pressables =
        listOf(
            binding.fmLike, binding.fmCoin, binding.fmFav,
            binding.fmPlay, binding.fmPrev, binding.fmNext,
            binding.fmLoop, binding.fmComments, binding.fmVideoMode,
        )
    for (v in pressables) installFmPressAnimation(v)

    
    binding.fmPanel.alpha = 0f
    binding.fmPanel.animate().alpha(1f).setDuration(260).start()
    binding.fmCoverFrame.scaleX = 0.82f
    binding.fmCoverFrame.scaleY = 0.82f
    binding.fmCoverFrame.animate().scaleX(1f).scaleY(1f).setDuration(320).start()

    fmProgressJob?.cancel()
    fmProgressJob =
        lifecycleScope.launch {
            while (true) {
                updateFmProgress()
                delay(500)
            }
        }
    updateFmProgress()
}

internal fun PlayerActivity.stopFmMode() {
    fmProgressJob?.cancel()
    fmProgressJob = null
    fmDiscAnimator?.cancel()
    binding.fmCoverFrame.rotation = 0f
}


private fun PlayerActivity.updateFmDiscRotation(playing: Boolean) {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    val animator = fmDiscAnimator
    if (playing) {
        if (animator == null) {
            val loaded = runCatching { android.animation.AnimatorInflater.loadAnimator(this, R.animator.blbl_fm_disc_rotate) }.getOrNull()
            val value = loaded as? android.animation.ValueAnimator ?: return
            value.setTarget(binding.fmCoverFrame)
            fmDiscAnimator = value
            value.start()
        } else if (!animator.isStarted) {
            animator.start()
        } else if (!animator.isRunning) {
            animator.resume()
        }
    } else {
        if (animator?.isRunning == true) animator.pause()
    }
}


internal fun PlayerActivity.refreshFmUi() {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    val main =
        currentMainTitle?.trim().orEmpty().ifBlank {
            binding.tvTitle.text?.toString()?.trim().orEmpty()
        }.ifBlank { "-" }
    binding.fmTitle.text = main
    val owner = currentOwnerName?.trim().orEmpty()
    val viewCount = currentPlayerViewCount?.takeIf { it >= 0L }
    val sub = if (viewCount != null && owner.isNotBlank()) "$owner · ${BlblFormat.count(viewCount)}播放" else owner
    binding.fmSub.text = sub.ifBlank { "-" }
    
    val face = currentUpAvatar?.takeIf { it.isNotBlank() }
    if (!face.isNullOrBlank()) {
        binding.fmOwnerAvatar.visibility = View.VISIBLE
        ImageLoader.loadInto(binding.fmOwnerAvatar, face)
    } else {
        binding.fmOwnerAvatar.visibility = View.GONE
    }
    val coverUrl = currentCoverUrl
    if (!coverUrl.isNullOrBlank()) {
        loadFmCover(coverUrl)
    }
    animateFmSwitch()
    updateFmPlayIcon()
}


internal fun PlayerActivity.refreshFmDetail() {
    val bvid = currentBvid.trim().takeIf { it.isNotBlank() } ?: return
    lifecycleScope.launch {
        val detail =
            withContext(Dispatchers.IO) {
                runCatching { BiliApi.videoDetail(bvid) }.getOrNull()
            }
        if (detail == null) return@launch
        if (!isFinishing && !isDestroyed && audioOnlyMode) {
            currentCoverUrl = detail.coverUrl?.takeIf { it.isNotBlank() } ?: currentCoverUrl
            currentOwnerName = detail.owner?.name?.takeIf { it.isNotBlank() } ?: currentOwnerName
            if (detail.title?.isNotBlank() == true) currentMainTitle = detail.title
            detail.stat.view?.let { if (it >= 0L) currentPlayerViewCount = it }
            refreshFmUi()
            detail.coverUrl?.takeIf { it.isNotBlank() }?.let { loadFmCover(it) }
        }
    }
}


internal fun PlayerActivity.loadFmCover(url: String) {
    binding.fmCover.setImageDrawable(null)
    binding.fmCover.alpha = 0.25f
    ImageLoader.loadInto(
        binding.fmCover,
        url,
        onSuccess = {
            binding.fmCover.animate().cancel()
            binding.fmCover.animate().alpha(1f).setDuration(240).start()
        },
        onFailure = {
            binding.fmCover.alpha = 1f
        },
    )
}

internal fun PlayerActivity.updateFmProgress() {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    val durMs = player?.duration?.coerceAtLeast(0L) ?: 0L
    val posMs = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
    if (durMs > 0L) {
        if (!fmSeeking) {
            binding.fmSeek.max = 1000
            binding.fmSeek.progress = ((posMs * 1000L) / durMs).toInt().coerceIn(0, 1000)
        }
        binding.fmTimeStart.text = BlblFormat.clock(posMs / 1000)
        binding.fmTimeEnd.text = BlblFormat.clock(durMs / 1000)
    } else {
        binding.fmTimeStart.text = "00:00"
        binding.fmTimeEnd.text = "00:00"
    }
    updateFmPlayIcon()
}

internal fun PlayerActivity.updateFmPlayIcon() {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    val playing = player?.isPlaying == true
    binding.fmPlay.setImageResource(if (playing) R.drawable.ic_player_pause else R.drawable.ic_player_play)
    updateFmDiscRotation(playing)
    
    binding.fmLike.imageTintList =
        androidx.core.content.ContextCompat.getColorStateList(
            this,
            if (actionLiked) R.color.blbl_blue else R.color.blbl_text,
        )
    binding.fmCoin.imageTintList =
        androidx.core.content.ContextCompat.getColorStateList(
            this,
            if (actionCoinCount > 0) R.color.blbl_blue else R.color.blbl_text,
        )
    binding.fmFav.imageTintList =
        androidx.core.content.ContextCompat.getColorStateList(
            this,
            if (actionFavored) R.color.blbl_blue else R.color.blbl_text,
        )
}


internal fun PlayerActivity.toggleFmLoop() {
    val next =
        if (resolvedPlaybackMode() == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE) {
            blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_NONE
        } else {
            blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE
        }
    val eng = player ?: return
    applyPlaybackModeSetting(next, eng)
    updateFmLoopIcon()
    AppToast.show(
        this,
        if (next == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE) "已开启单集循环" else "已关闭单集循环",
    )
}


internal fun PlayerActivity.updateFmLoopIcon() {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    val on = resolvedPlaybackMode() == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE
    binding.fmLoop.imageTintList =
        androidx.core.content.ContextCompat.getColorStateList(
            this,
            if (on) R.color.blbl_blue else R.color.blbl_text,
        )
    binding.fmLoop.alpha = if (on) 1f else 0.8f
}


internal fun PlayerActivity.installFmPressAnimation(view: View) {
    view.setOnTouchListener { v, event ->
        when (event.actionMasked) {
            android.view.MotionEvent.ACTION_DOWN -> {
                v.animate().cancel()
                v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(90).start()
                false
            }

            android.view.MotionEvent.ACTION_UP,
            android.view.MotionEvent.ACTION_CANCEL,
            -> {
                v.animate().cancel()
                v.animate().scaleX(1f).scaleY(1f).setDuration(130).start()
                false
            }

            else -> false
        }
    }
}

internal fun PlayerActivity.toggleShuffleMode() {
    val next = !BiliClient.prefs.shuffleModeEnabled
    BiliClient.prefs.shuffleModeEnabled = next
    AppToast.show(this, if (next) "已开启刷视频模式：遥控器上/下键切换视频" else "已关闭刷视频模式")
    setControlsVisible(true)
    binding.btnShuffle.alpha = if (next) 1.0f else 0.45f
}

internal fun PlayerActivity.pushShuffleHistory(bvid: String) {
    if (bvid.isBlank()) return
    if (shuffleHistory.lastOrNull() == bvid) return
    shuffleHistory.addLast(bvid)
    while (shuffleHistory.size > 40) shuffleHistory.removeFirst()
}

internal fun PlayerActivity.shuffleToPrevOrToast(): Boolean {
    if (shuffleHistory.isEmpty()) {
        AppToast.show(this, "已经是第一个视频")
        return true
    }
    var prev = shuffleHistory.removeLast()
    if (prev == currentBvid) {
        if (shuffleHistory.isEmpty()) {
            AppToast.show(this, "已经是第一个视频")
            return true
        }
        prev = shuffleHistory.removeLast()
    }
    if (prev.isBlank()) {
        AppToast.show(this, "已经是第一个视频")
        return true
    }
    startPlayback(
        bvid = prev,
        cidExtra = null,
        epIdExtra = null,
        aidExtra = null,
        initialTitle = null,
        startedFromList = PlayerVideoListKind.RECOMMEND,
        showTitleHint = true,
    )
    return true
}



internal fun PlayerActivity.showFmMenu() {
    val items =
        listOf(
            "切换画音模式",
            if (BiliClient.prefs.shuffleModeEnabled) "关闭刷视频模式" else "开启刷视频模式（上下键切视频）",
            if (resolvedPlaybackMode() == blbl.cat3399.core.prefs.AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE) "关闭单集循环" else "开启单集循环",
            "查看评论",
        )
    blbl.cat3399.core.ui.popup.AppPopup.singleChoice(
        context = this,
        title = "听视频菜单",
        items = items,
        checkedIndex = -1,
        cancelable = true,
    ) { index, _ ->
        when (index) {
            0 -> toggleAudioOnlyMode()
            1 -> toggleShuffleMode()
            2 -> toggleFmLoop()
            3 -> showCommentsPanel()
        }
    }
}


internal fun PlayerActivity.animateFmSwitch() {
    if (!audioOnlyMode || !binding.fmPanel.isVisible) return
    binding.fmCoverFrame.animate().cancel()
    binding.fmCoverFrame.scaleX = 0.9f
    binding.fmCoverFrame.scaleY = 0.9f
    binding.fmCoverFrame.alpha = 0.4f
    binding.fmCoverFrame.animate().scaleX(1f).scaleY(1f).alpha(1f).setDuration(300).start()
}


internal fun PlayerActivity.rotateVideoSurface() {
    val next = (BiliClient.prefs.playerRotation + 90) % 360
    BiliClient.prefs.playerRotation = next
    applyPlayerRotation()
    AppToast.show(this, "画面旋转 ${next}°")
}


internal fun PlayerActivity.applyPlayerRotation() {
    val deg = BiliClient.prefs.playerRotation
    val root = binding.root
    
    root.post {
        if (isFinishing || isDestroyed) return@post
        val w = root.width.toFloat()
        val h = root.height.toFloat()
        if (w > 0f && h > 0f) {
            root.pivotX = w / 2f
            root.pivotY = h / 2f
            root.rotation = deg.toFloat()
            if (deg % 180 != 0) {
                val cover = maxOf(w / h, h / w)
                root.scaleX = cover
                root.scaleY = cover
            } else {
                root.scaleX = 1f
                root.scaleY = 1f
            }
        }
    }
    binding.btnRotate.imageTintList =
        androidx.core.content.ContextCompat.getColorStateList(
            this,
            if (deg != 0) R.color.blbl_blue else R.color.blbl_text,
        )
}
