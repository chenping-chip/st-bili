package blbl.cat3399.feature.my

import android.net.Uri
import android.os.Bundle
import android.os.SystemClock
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.activity.result.contract.ActivityResultContracts
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.enableDpadTabFocus
import blbl.cat3399.core.ui.findCurrentViewPagerChildFragment
import blbl.cat3399.core.ui.findCurrentViewPagerChildFragmentAs
import blbl.cat3399.core.ui.popup.AppPopup
import blbl.cat3399.core.ui.postIfAlive
import blbl.cat3399.core.ui.requestFocusSelectedTab
import blbl.cat3399.databinding.FragmentMyTabsBinding
import blbl.cat3399.ui.BackPressHandler
import com.google.android.material.tabs.TabLayoutMediator
import blbl.cat3399.ui.RefreshKeyHandler
import blbl.cat3399.ui.SidebarFocusHost
import com.google.android.material.tabs.TabLayout
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONObject
import java.io.File

class MyTabsFragment : Fragment(), MyTabContentSwitchFocusHost, BackPressHandler {
    private var _binding: FragmentMyTabsBinding? = null
    private val binding get() = _binding!!

    private var mediator: TabLayoutMediator? = null
    private var pageCallback: androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback? = null
    private var tabs: List<MyTabSpec> = emptyList()
    private var pendingFocusFirstItemFromContentSwitch: Boolean = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentMyTabsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        setTabs(MyTabs.visibleTabs(BiliClient.prefs), force = true)
        binding.tabLayout.addOnTabSelectedListener(
            object : TabLayout.OnTabSelectedListener {
                override fun onTabSelected(tab: TabLayout.Tab) = Unit

                override fun onTabUnselected(tab: TabLayout.Tab) = Unit

                override fun onTabReselected(tab: TabLayout.Tab) {
                    refreshCurrentPageFromTabReselect()
                }
            },
        )

        pageCallback =
            object : androidx.viewpager2.widget.ViewPager2.OnPageChangeCallback() {
                override fun onPageSelected(position: Int) {
                    val tab = tabs.getOrNull(position)
                    AppLog.d("My", "page selected pos=$position key=${tab?.key} t=${SystemClock.uptimeMillis()}")
                    if (pendingFocusFirstItemFromContentSwitch) {
                        if (focusCurrentPageFirstItemFromContentSwitch()) {
                            pendingFocusFirstItemFromContentSwitch = false
                        }
                    }
                }
            }
        binding.viewPager.registerOnPageChangeCallback(pageCallback!!)

        setupUserCard()
        loadUserCard()
    }

    private val avatarPicker =
        registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
            if (uri == null) return@registerForActivityResult
            uploadAvatarFromUri(uri)
        }

    private fun setupUserCard() {
        binding.btnEditName.setOnClickListener { editName() }
        binding.btnEditAvatar.setOnClickListener { avatarPicker.launch("image/*") }
        binding.btnLogout.setOnClickListener { logout() }
        
        binding.btnFans.setOnClickListener {
            if (BiliClient.cookies.hasSessData()) {
                startActivity(android.content.Intent(requireContext(), blbl.cat3399.feature.following.FansListActivity::class.java))
            } else {
                AppToast.show(requireContext(), "请先登录")
            }
        }
        
        binding.btnMyVideos.visibility = android.view.View.GONE
        
        binding.userCard.setOnClickListener {
            if (BiliClient.cookies.hasSessData()) {
                blbl.cat3399.ui.UserInfoDialogFragment.show(requireActivity().supportFragmentManager)
            } else {
                blbl.cat3399.core.ui.AppToast.show(requireContext(), "请先登录")
            }
        }
        binding.ivUserAvatar.setOnClickListener {
            if (BiliClient.cookies.hasSessData()) {
                blbl.cat3399.ui.UserInfoDialogFragment.show(requireActivity().supportFragmentManager)
            }
        }
        binding.tvUserName.setOnClickListener {
            if (BiliClient.cookies.hasSessData()) {
                blbl.cat3399.ui.UserInfoDialogFragment.show(requireActivity().supportFragmentManager)
            }
        }
    }

    private fun loadUserCard() {
        val b = _binding ?: return
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val nav =
                    withContext(Dispatchers.IO) {
                        BiliApi.nav()
                    }
                if (_binding == null) return@launch
                val data = nav.optJSONObject("data") ?: JSONObject()
                if (nav.optInt("code", -1) != 0 || !data.optBoolean("isLogin", false)) {
                    binding.tvUserName.text = "未登录"
                    binding.btnFans.visibility = View.GONE
                    return@launch
                }
                val name = data.optString("uname", "")
                val mid = data.optLong("mid", 0L)
                val face = data.optString("face", "").takeIf { it.isNotBlank() }
                val coins = data.optDouble("money", 0.0)
                val levelInfo = data.optJSONObject("level_info") ?: JSONObject()
                val level = levelInfo.optInt("current_level", 0)
                val exp = levelInfo.optLong("current_exp", 0L)
                val expNext = levelInfo.optLong("next_exp", 0L).takeIf { it > 0L }

                
                val prefs = blbl.cat3399.core.net.BiliClient.prefs
                val overrideFans = prefs.debugOverrideFans
                val overrideFollowing = prefs.debugOverrideFollowing
                val overrideCoins = prefs.debugOverrideCoins
                val overrideLevel = prefs.debugOverrideLevel

                
                var fansText: String? = null
                var followingText: String? = null
                runCatching {
                    val stat = BiliApi.relationStat(vmid = mid)
                    fansText = overrideFans?.toString() ?: stat.follower.toString()
                    followingText = overrideFollowing?.toString() ?: stat.following.toString()
                }.onFailure {
                    fansText = overrideFans?.toString()
                    followingText = overrideFollowing?.toString()
                }

                binding.tvUserName.text = name
                binding.tvUserMeta.text =
                    buildString {
                        append("UID：$mid")
                        append(" · Lv.${overrideLevel ?: level}")
                        append(" · 硬币 ${overrideCoins ?: if (coins == coins.toLong().toDouble()) coins.toLong().toString() else String.format(java.util.Locale.US, "%.1f", coins)}")
                        if (fansText != null && followingText != null) {
                            append(" · 粉丝 $fansText · 关注 $followingText")
                        }
                    }
                binding.tvUserExp.text =
                    if (expNext != null) {
                        "经验：$exp / $expNext"
                    } else {
                        "经验：$exp"
                    }
                binding.btnFans.visibility = View.VISIBLE
                ImageLoader.loadInto(binding.ivUserAvatar, face)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("My", "load user card failed", t)
                if (_binding != null) binding.tvUserName.text = ""
            }
        }
    }

    private fun editName() {
        val current = binding.tvUserName.text?.toString().orEmpty()
        AppPopup.input(
            context = requireContext(),
            title = "修改昵称",
            initial = current,
            hint = "输入新昵称",
            positiveText = "保存",
            onPositive = { newName ->
                val name = newName.trim()
                if (name.isEmpty() || name == current) return@input
                viewLifecycleOwner.lifecycleScope.launch {
                    try {
                        withContext(Dispatchers.IO) { BiliApi.updateProfileName(name) }
                        AppToast.show(requireContext(), "昵称已修改")
                        loadUserCard()
                    } catch (t: Throwable) {
                        if (t is CancellationException) throw t
                        AppToast.show(requireContext(), "修改失败：${t.message.orEmpty().take(60)}")
                    }
                }
            },
        )
    }

    private fun uploadAvatarFromUri(uri: Uri) {
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val file =
                    withContext(Dispatchers.IO) {
                        val dir = File(requireContext().cacheDir, "avatar")
                        dir.mkdirs()
                        val out = File(dir, "avatar_upload_${System.currentTimeMillis()}.jpg")
                        requireContext().contentResolver.openInputStream(uri)?.use { input ->
                            out.outputStream().use { output -> input.copyTo(output) }
                        }
                        out
                    }
                val url =
                    withContext(Dispatchers.IO) {
                        BiliApi.uploadAvatar(file)
                    }
                AppToast.show(requireContext(), if (url.isNotBlank()) "头像已更新" else "头像上传完成")
                loadUserCard()
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppToast.show(requireContext(), "头像修改失败：${t.message.orEmpty().take(60)}")
            }
        }
    }

    private fun logout() {
        AppPopup.confirm(
            context = requireContext(),
            title = "退出登录",
            message = "确定要退出当前账号吗？",
            positiveText = "退出",
            negativeText = "取消",
            onPositive = {
                BiliClient.clearLoginSession()
                activity?.recreate()
            },
        )
    }

    override fun onResume() {
        super.onResume()
        setTabs(MyTabs.visibleTabs(BiliClient.prefs))
        
        if (BiliClient.cookies.hasSessData()) {
            loadUserCard()
        }
    }

    private fun setTabs(nextTabs: List<MyTabSpec>, force: Boolean = false) {
        val b = _binding ?: return
        val next = nextTabs.ifEmpty { MyTabs.all }
        if (!force && tabs.map { it.key } == next.map { it.key }) return

        val currentKey = tabs.getOrNull(b.viewPager.currentItem)?.key
        mediator?.detach()
        mediator = null
        tabs = next

        b.viewPager.adapter = MyPagerAdapter(this, tabs)
        mediator =
            TabLayoutMediator(b.tabLayout, b.viewPager) { tab, position ->
                tab.text = tabs.getOrNull(position)?.let { getString(it.titleRes) }.orEmpty()
            }.also { it.attach() }

        val targetIndex = currentKey?.let { key -> tabs.indexOfFirst { it.key == key }.takeIf { it >= 0 } } ?: 0
        if (targetIndex != b.viewPager.currentItem && targetIndex in tabs.indices) {
            b.viewPager.setCurrentItem(targetIndex, false)
        }

        installTabFocusHandlers(b)
    }

    private fun installTabFocusHandlers(b: FragmentMyTabsBinding) {
        val tabLayout = b.tabLayout
        tabLayout.postIfAlive(isAlive = { _binding === b }) {
            tabLayout.enableDpadTabFocus(selectOnFocusProvider = { BiliClient.prefs.tabSwitchFollowsFocus }) { position ->
                val tab = tabs.getOrNull(position)
                AppLog.d("My", "tab focus pos=$position key=${tab?.key} t=${SystemClock.uptimeMillis()}")
            }
            val tabStrip = tabLayout.getChildAt(0) as? ViewGroup ?: return@postIfAlive
            for (i in 0 until tabStrip.childCount) {
                tabStrip.getChildAt(i).setOnKeyListener { _, keyCode, event ->
                    if (event.action == KeyEvent.ACTION_DOWN && keyCode == KeyEvent.KEYCODE_DPAD_DOWN) {
                        return@setOnKeyListener focusCurrentPageFirstItem()
                    }
                    false
                }
            }
        }
    }

    private fun refreshCurrentPageFromTabReselect(): Boolean {
        val target = findCurrentViewPagerChildFragmentAs<RefreshKeyHandler>(binding.viewPager) ?: return false
        return target.handleRefreshKey()
    }

    private fun focusCurrentPageFirstItem(): Boolean {
        val byTag = findCurrentViewPagerChildFragment(binding.viewPager)
        val target = byTag as? MyTabSwitchFocusTarget
        if (target != null) return target.requestFocusFirstItemFromTabSwitch()

        val pageFragment =
            if (byTag?.view?.findViewById<RecyclerView?>(R.id.recycler) != null) {
                byTag
            } else {
                childFragmentManager.fragments.firstOrNull { it.isVisible && it.view?.findViewById<RecyclerView?>(R.id.recycler) != null }
            } ?: return false
        val recycler = pageFragment.view?.findViewById<RecyclerView?>(R.id.recycler) ?: return false

        recycler.postIfAlive(isAlive = { _binding != null }) {
            val vh = recycler.findViewHolderForAdapterPosition(0)
            when {
                vh != null -> {
                    vh.itemView.requestFocus()
                }

                recycler.adapter?.itemCount == 0 -> {
                    recycler.requestFocus()
                }

                else -> {
                    recycler.scrollToPosition(0)
                    recycler.postIfAlive(isAlive = { _binding != null }) {
                        recycler.findViewHolderForAdapterPosition(0)?.itemView?.requestFocus()
                            ?: recycler.requestFocus()
                    }
                }
            }
        }
        return true
    }

    private fun focusCurrentPageFirstItemFromContentSwitch(): Boolean {
        val target = findCurrentViewPagerChildFragmentAs<MyTabSwitchFocusTarget>(binding.viewPager)
            ?: return false
        return target.requestFocusFirstItemFromTabSwitch()
    }

    private fun focusSelectedTab(): Boolean {
        val b = _binding ?: return false
        return b.tabLayout.requestFocusSelectedTab(fallbackPosition = b.viewPager.currentItem) { _binding != null }
    }

    override fun requestFocusCurrentPageFirstItemFromContentSwitch(): Boolean {
        pendingFocusFirstItemFromContentSwitch = true
        if (focusCurrentPageFirstItemFromContentSwitch()) {
            pendingFocusFirstItemFromContentSwitch = false
        }
        return true
    }

    override fun handleBackPressed(): Boolean {
        val b = _binding ?: return false
        val scheme = BiliClient.prefs.mainBackFocusScheme

        
        if (b.tabLayout.hasFocus()) {
            return (activity as? SidebarFocusHost)?.requestFocusSidebarSelectedNav() == true
        }

        
        val inContent = b.viewPager.hasFocus() && !b.tabLayout.hasFocus()
        if (!inContent) return false

        return when (scheme) {
            AppPrefs.MAIN_BACK_FOCUS_SCHEME_A -> focusSelectedTab()
            AppPrefs.MAIN_BACK_FOCUS_SCHEME_B -> {
                if (b.viewPager.currentItem != 0) {
                    pendingFocusFirstItemFromContentSwitch = true
                    
                    
                    b.viewPager.setCurrentItem(0, false)
                    true
                } else {
                    (activity as? SidebarFocusHost)?.requestFocusSidebarSelectedNav() == true
                }
            }
            AppPrefs.MAIN_BACK_FOCUS_SCHEME_C -> {
                (activity as? SidebarFocusHost)?.requestFocusSidebarSelectedNav() == true
            }
            else -> focusSelectedTab()
        }
    }

    override fun onDestroyView() {
        pageCallback?.let { binding.viewPager.unregisterOnPageChangeCallback(it) }
        pageCallback = null
        mediator?.detach()
        mediator = null
        tabs = emptyList()
        _binding = null
        super.onDestroyView()
    }
}
