package blbl.cat3399.feature.player

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.model.VideoCard
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.databinding.FragmentShuffleBinding
import blbl.cat3399.feature.video.VideoCardActionController
import blbl.cat3399.feature.video.VideoCardAdapter
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class ShuffleFragment : Fragment() {
    private var _binding: FragmentShuffleBinding? = null
    private val binding get() = _binding!!
    private lateinit var adapter: VideoCardAdapter
    private var cards: List<VideoCard> = emptyList()
    private var loading = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentShuffleBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        val actionController =
            VideoCardActionController(
                context = requireContext(),
                scope = viewLifecycleOwner.lifecycleScope,
                dismissBehavior = blbl.cat3399.feature.video.VideoCardDismissBehavior.LocalNotInterested,
                onOpenDetail = { _, _ -> },
                onOpenUp = { _ -> },
            )
        adapter =
            VideoCardAdapter(
                onClick = { card, _ -> startShuffle(card) },
                onLongClick = { _, _ -> true },
                actionDelegate = actionController,
            )
        binding.shuffleRecycler.layoutManager = GridLayoutManager(requireContext(), spanCountForWidth())
        binding.shuffleRecycler.adapter = adapter

        binding.btnStartShuffle.setOnClickListener { startShuffle(null) }

        binding.btnStartShuffle.post { binding.btnStartShuffle.requestFocus() }
        load()
    }

    private fun spanCountForWidth(): Int {
        val w = resources.displayMetrics.widthPixels
        return when {
            w >= 1600 -> 6
            w >= 1200 -> 5
            w >= 900 -> 4
            else -> 3
        }
    }

    private fun startShuffle(card: VideoCard?) {
        val target = card ?: cards.firstOrNull()
        if (target == null) {
            AppToast.show(requireContext(), "推荐视频加载中，请稍候")
            return
        }
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(requireContext(), "刷视频建议先登录（获取完整推荐）")
        }
        BiliClient.prefs.shuffleModeEnabled = true
        startActivity(
            Intent(requireContext(), PlayerActivity::class.java)
                .putExtra(PlayerActivity.EXTRA_BVID, target.bvid)
                .putExtra(PlayerActivity.EXTRA_CID, target.cid ?: -1L)
                .putExtra(PlayerActivity.EXTRA_SHUFFLE, true),
        )
    }

    private fun load() {
        if (loading) return
        loading = true
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val items =
                    withContext(Dispatchers.IO) {
                        BiliApi.recommend(freshIdx = 0, ps = 30, fetchRow = 1)
                    }
                if (!isAdded) return@launch
                cards = items
                adapter.submit(items)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "加载失败")
                AppToast.show(requireContext(), "推荐加载失败：${msg.take(40)}")
            } finally {
                loading = false
            }
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    companion object {
        fun newInstance(): ShuffleFragment = ShuffleFragment()
    }
}
