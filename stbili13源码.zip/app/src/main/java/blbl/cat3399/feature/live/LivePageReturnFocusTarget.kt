package blbl.cat3399.feature.live


interface LivePageReturnFocusTarget {
    fun restoreFocusAfterReturnFromDetail(): Boolean
}

