@file:androidx.annotation.OptIn(markerClass = [androidx.media3.common.util.UnstableApi::class])

package blbl.cat3399.feature.player

import android.content.Intent
import android.net.Uri
import android.app.Activity
import android.app.Application
import android.graphics.SurfaceTexture
import android.os.Bundle
import android.os.Looper
import android.os.SystemClock
import android.util.TypedValue
import android.view.FocusFinder
import android.view.KeyEvent
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewGroup.MarginLayoutParams
import android.widget.FrameLayout
import android.widget.SeekBar
import androidx.constraintlayout.widget.ConstraintSet
import androidx.core.content.ContextCompat
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.MimeTypes
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.ui.PlayerView
import androidx.media3.ui.SubtitleView
import androidx.media3.datasource.DefaultDataSource
import androidx.media3.datasource.DataSource
import androidx.media3.datasource.DataSpec
import androidx.media3.datasource.TransferListener
import androidx.media3.datasource.HttpDataSource
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory
import androidx.media3.exoplayer.source.MediaSource
import androidx.media3.exoplayer.source.MergingMediaSource
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.CaptionStyleCompat
import blbl.cat3399.BlblApp
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.api.video.AudioTrack
import blbl.cat3399.core.api.video.VideoAudioKind
import blbl.cat3399.core.api.video.VideoDetail
import blbl.cat3399.core.api.video.VideoMediaRequestProfile
import blbl.cat3399.core.api.video.VideoPlayKind
import blbl.cat3399.core.api.video.VideoPlayRequest
import blbl.cat3399.core.api.video.VideoPlayStream
import blbl.cat3399.core.api.video.VideoSubtitle
import blbl.cat3399.core.api.video.VideoTrackInfo
import blbl.cat3399.core.api.video.VideoTrack
import blbl.cat3399.core.api.SponsorBlockApi
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.model.DanmakuShield
import blbl.cat3399.core.model.VideoCard
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import blbl.cat3399.core.ui.ActivityStackLimiter
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.DoubleBackToExitHandler
import blbl.cat3399.core.ui.FocusReturn
import blbl.cat3399.core.ui.FocusTreeUtils
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.popup.PopupHost
import blbl.cat3399.core.util.Format as BlblFormat
import blbl.cat3399.feature.my.BangumiDetailActivity
import blbl.cat3399.feature.player.danmaku.DanmakuSessionSettings
import blbl.cat3399.feature.player.danmaku.DanmakuFontWeight
import blbl.cat3399.feature.player.danmaku.DanmakuLaneDensity
import blbl.cat3399.feature.player.engine.BlblPlayerEngine
import blbl.cat3399.feature.player.engine.DashPlaybackCatalogResolver
import blbl.cat3399.feature.player.engine.ExoPlayerEngine
import blbl.cat3399.feature.player.engine.IjkPlayerEngine
import blbl.cat3399.feature.player.engine.IjkPlayerPlugin
import blbl.cat3399.feature.player.engine.IjkPlayerPluginUi
import blbl.cat3399.feature.player.engine.PlayerEngineKind
import blbl.cat3399.feature.player.engine.PlaybackSource
import blbl.cat3399.feature.settings.SettingsActivity
import blbl.cat3399.feature.video.VideoDetailActivity
import blbl.cat3399.feature.video.comment.VideoCommentImageViewerController
import blbl.cat3399.feature.video.comment.VideoCommentsPanelController
import blbl.cat3399.databinding.ActivityPlayerBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.CoroutineExceptionHandler
import kotlinx.coroutines.Job
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.async
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.lang.ref.WeakReference
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

class PlayerActivity : BaseActivity() {
    override fun shouldRecreateOnUiScaleChange(): Boolean = true

    internal lateinit var binding: ActivityPlayerBinding
    internal lateinit var upQuickCard: PlayerUpQuickCardController
    internal val currentUpMid: Long get() = if (::upQuickCard.isInitialized) upQuickCard.currentMid else 0L
    internal val currentUpName: String? get() = if (::upQuickCard.isInitialized) upQuickCard.currentName else null
    internal val currentUpAvatar: String? get() = if (::upQuickCard.isInitialized) upQuickCard.currentAvatar else null
    internal val currentUpFollowed: Boolean? get() = if (::upQuickCard.isInitialized) upQuickCard.currentFollowed else null
    internal val upFollowActionInFlight: Boolean get() = if (::upQuickCard.isInitialized) upQuickCard.followActionInFlight else false

    internal var player: BlblPlayerEngine? = null
    private var ijkRenderView: View? = null
    private var ijkTextureSurface: Surface? = null
    internal var pendingStartPositionMs: Long? = null
    internal var pendingStartPlayWhenReady: Boolean? = null
    internal var pendingIntentResumeCandidate: ResumeCandidate? = null
    internal var pendingIntentResumeCid: Long? = null
    internal var pendingIntentResumeEpId: Long? = null
    internal var videoCommentsController: VideoCommentsPanelController? = null
    internal var videoCommentImageViewerController: VideoCommentImageViewerController? = null
    internal var debugJob: kotlinx.coroutines.Job? = null
    internal val debug = PlayerDebugMetrics()
    internal var progressJob: kotlinx.coroutines.Job? = null
    internal var autoResumeJob: kotlinx.coroutines.Job? = null
    internal var autoResumeHintTimeoutJob: kotlinx.coroutines.Job? = null
    internal var autoResumeHintVisible: Boolean = false
    internal var autoResumeHintText: String? = null
    internal var autoResumeUndoDeadlineElapsedMs: Long = 0L
    internal var autoResumeUndoTargetMs: Long = -1L
    internal var autoSkipFetchJob: kotlinx.coroutines.Job? = null
    internal var autoSkipHintVisible: Boolean = false
    internal var autoSkipHintText: String? = null
    internal var autoNextHintVisible: Boolean = false
    internal var autoNextHintText: String? = null
    internal var autoNextAfterEndedArmed: Boolean = false
    internal var autoNextAfterEndedJob: kotlinx.coroutines.Job? = null
    internal var autoNextAfterEndedToken: Long = 0L
    private var reportProgressJob: kotlinx.coroutines.Job? = null
    internal var autoHideJob: kotlinx.coroutines.Job? = null
    internal var seekOsdHideJob: kotlinx.coroutines.Job? = null
    internal var holdSeekJob: kotlinx.coroutines.Job? = null
    internal var seekHintJob: kotlinx.coroutines.Job? = null
    internal var keyScrubEndJob: kotlinx.coroutines.Job? = null
    internal var videoShotPreviewHideJob: kotlinx.coroutines.Job? = null
    internal val sponsorSubmitPanelState = SponsorSubmitPanelState()
    internal var sponsorSubmitUploadJob: Job? = null
    internal var keyScrubPendingSeekToMs: Long? = null
    internal var scrubbing: Boolean = false
    internal var lastInteractionAtMs: Long = 0L
    private var finishOnBackKeyUp: Boolean = false
    internal var holdPrevSpeed: Float = 1.0f
    internal var holdPrevPlayWhenReady: Boolean = false
    internal var holdScrubPreviewPosMs: Long? = null
    internal var keySeekPreviewPosMs: Long? = null
    internal val bufferingOverlayController: PlayerBufferingOverlayController by lazy {
        PlayerBufferingOverlayController(
            context = this,
            bindingProvider = { if (::binding.isInitialized) binding else null },
            scope = lifecycleScope,
            playbackStateProvider = { player?.playbackState },
        )
    }
    internal var loadJob: kotlinx.coroutines.Job? = null
    internal var lastEndedActionAtMs: Long = 0L
    internal var playbackUncaughtHandler: CoroutineExceptionHandler? = null
    internal var actionLiked: Boolean = false
    internal var actionCoinCount: Int = 0
    internal var actionFavored: Boolean = false
    internal var likeActionJob: kotlinx.coroutines.Job? = null
    internal var coinActionJob: kotlinx.coroutines.Job? = null
    internal var favDialogJob: kotlinx.coroutines.Job? = null
    internal var favApplyJob: kotlinx.coroutines.Job? = null
    internal var tripleActionJob: Job? = null
    internal var socialStateFetchJob: kotlinx.coroutines.Job? = null
    internal var socialStateFetchToken: Int = 0
    internal var likeButtonHoldController: HoldToTriggerController? = null
    internal var touchController: PlayerTouchController? = null
    
    internal fun onShuffleFlingFromTouch(up: Boolean) {
        if (!BiliClient.prefs.shuffleModeEnabled) return
        if (!shuffleSwitchReady()) return
        playRandomNext(userInitiated = true)
        setControlsVisible(true)
    }

    internal val osdFocusReturn = FocusReturn()

    private val doubleBackToExit by lazy {
        DoubleBackToExitHandler(context = this, windowMs = BACK_DOUBLE_PRESS_WINDOW_MS) {
            if (osdMode != OsdMode.Hidden) setControlsVisible(false)
        }
    }

    internal var smartSeekDirection: Int = 0
    internal var smartSeekLastAtMs: Long = 0L
    internal var smartSeekTotalMs: Long = 0L
    internal var tapSeekActiveDirection: Int = 0
    internal var tapSeekActiveUntilMs: Long = 0L
    internal var keySeekHoldDetectJob: kotlinx.coroutines.Job? = null
    internal var keySeekPendingKeyCode: Int = 0
    internal var keySeekPendingDirection: Int = 0
    internal var seekOsdToken: Long = 0L
    internal var transientSeekOsdVisible: Boolean = false
    internal var bottomBarFullConstraints: ConstraintSet? = null

    internal enum class OsdMode {
        Hidden,
        Full,
        SeekTransient,
    }

    internal var osdMode: OsdMode = OsdMode.Hidden
    internal var menuRevealedPanelSessionActive: Boolean = false

    internal var currentBvid: String = ""
    internal var currentCid: Long = -1L
    internal var currentVideoIsPortrait: Boolean? = null
    internal var audioOnlyMode: Boolean = false
    internal var _shuffleHistory: java.util.ArrayDeque<String> = java.util.ArrayDeque()
    internal var lastShuffleSwitchAtMs: Long = 0L
    internal var currentSeasonTitle: String? = null
    internal var currentSeasonCards: List<blbl.cat3399.core.model.VideoCard> = emptyList()

    
    internal fun shuffleSwitchReady(): Boolean {
        val now = SystemClock.elapsedRealtime()
        if (now - lastShuffleSwitchAtMs < 450L) return false
        lastShuffleSwitchAtMs = now
        return true
    }

    internal var currentCoverUrl: String? = null
    internal var currentOwnerName: String? = null
    internal var fmProgressJob: kotlinx.coroutines.Job? = null
    internal var fmDiscAnimator: android.animation.ValueAnimator? = null
    internal var fmSeeking: Boolean = false
    internal var downloadingVideo: DownloadingState? = null
    internal var seamlessQualitySwitchDisabledForPlayback: Boolean = false
    internal var pendingResolutionSuccessHintQn: Int? = null
    internal var currentEpId: Long? = null
    internal var currentAid: Long? = null
    internal var currentSeasonId: Long? = null
    internal var currentMainTitle: String? = null
    internal var currentPlayerDesc: String? = null
    internal var currentPlayerViewCount: Long? = null
    internal var currentPlayerDanmakuCount: Long? = null
    internal var currentPlayerPubDateSec: Long? = null
    internal var currentPlayerCommentCount: Long? = null
    internal var currentPlayerLikeCount: Long? = null
    internal var currentPlayerCoinCount: Long? = null
    internal var currentPlayerFavCount: Long? = null
    internal var playerInfoShelfUsesRecommendFallback: Boolean = false

    internal var pageListToken: String? = null
    internal var pageListSource: String? = null
    internal var pageListItems: List<PlayerPlaylistItem> = emptyList()
    internal var pageListUiCards: List<VideoCard> = emptyList()
    internal var pageListIndex: Int = -1
    internal var pageListContinuation: PlayerPlaylistContinuation? = null
    internal var pageListLoadMoreJob: Job? = null
    internal val pageListLoadMoreCallbacks = ArrayList<(Boolean) -> Unit>()

    internal var partsListSource: String? = null
    internal var partsListItems: List<PlayerPlaylistItem> = emptyList()
    internal var partsListUiCards: List<VideoCard> = emptyList()
    internal var partsListIndex: Int = -1
    internal var partsListContinuation: PlayerPlaylistContinuation? = null
    internal var partsListLoadMoreJob: Job? = null
    internal val partsListLoadMoreCallbacks = ArrayList<(Boolean) -> Unit>()
    internal var partsListFetchJob: kotlinx.coroutines.Job? = null
    internal var partsListFetchToken: Int = 0
    internal lateinit var session: PlayerSessionSettings
    internal var settingsPanelMenu: PlayerSettingsMenu = PlayerSettingsMenu.ROOT
    internal var bottomCardPanelKind: PlayerVideoListKind = PlayerVideoListKind.PAGE
    internal var bottomCardPanelPreferContentFocus: Boolean = false

    internal data class RelatedVideosCache(
        val bvid: String,
        val items: List<VideoCard>,
    )

    internal var relatedVideosCache: RelatedVideosCache? = null
    internal var relatedVideosFetchJob: kotlinx.coroutines.Job? = null
    internal var relatedVideosFetchToken: Int = 0
    internal var currentVideoDetail: VideoDetail? = null
    internal var subtitleAvailabilityKnown: Boolean = false
    internal var subtitleAvailable: Boolean = false
    internal var subtitleConfig: MediaItem.SubtitleConfiguration? = null
    internal var subtitleItems: List<SubtitleItem> = emptyList()
    internal var subtitleLoadJob: Job? = null
    internal var lastAvailableQns: List<Int> = emptyList()
    internal var lastAvailableAudioIds: List<Int> = emptyList()
    private var danmakuSegmentSizeMs: Int = DANMAKU_DEFAULT_SEGMENT_MS
    private var danmakuSegmentTotal: Int = 0
    internal var danmakuShield: DanmakuShield? = null
    internal val danmakuLoadedSegments = LinkedHashSet<Int>()
    private val danmakuLoadingSegments = HashSet<Int>()
    internal val danmakuSegmentItems = LinkedHashMap<Int, List<blbl.cat3399.core.model.Danmaku>>()
    private var danmakuLoadJob: kotlinx.coroutines.Job? = null
    private var danmakuLoadGeneration: Int = 0
    private var lastDanmakuPrefetchAtMs: Long = 0L
    internal var playbackConstraints: PlaybackConstraints = PlaybackConstraints()
    internal var decodeFallbackAttemptCount: Int = 0
    internal var lastPickedDash: Playable.Dash? = null
    internal var autoResumeToken: Int = 0
    internal var autoResumeCancelledByUser: Boolean = false
    internal var autoSkipToken: Int = 0
    internal var autoSkipSegments: List<SkipSegment> = emptyList()
    internal val autoSkipHandledSegmentIds = HashSet<String>()
    internal var autoSkipPending: PendingAutoSkip? = null
    internal var autoNextPending: AutoNextTarget? = null
    internal var autoNextCancelledByUser: Boolean = false
    internal var autoSkipMarkersDirty: Boolean = true
    internal var autoSkipMarkersDurationMs: Long = -1L
    internal var autoSkipMarkersShown: Boolean = false
    internal var reportToken: Int = 0
    internal var lastReportAtMs: Long = 0L
    internal var lastReportedProgressSec: Long = -1L
    internal var currentViewDurationMs: Long? = null
    private var exitCleanupRequested: Boolean = false
    private var exitCleanupReason: String? = null
    private var exitTraceStartAtMs: Long = 0L
    private var exitTraceStartTrigger: String? = null
    @Volatile
    private var exitTracePauseAtMs: Long = 0L

    @Volatile
    private var exitTraceStopAtMs: Long = 0L

    @Volatile
    private var exitTraceDestroyAtMs: Long = 0L

    private var exitTraceStallWatchJob: kotlinx.coroutines.Job? = null
    @Volatile
    private var exitTraceStallSampled: Boolean = false
    private var exitTraceNavCallbacks: Application.ActivityLifecycleCallbacks? = null
    private var exitTraceNavTarget: WeakReference<Activity>? = null
    @Volatile
    private var exitTraceNavTargetResumedLogged: Boolean = false

    @Volatile
    private var exitTraceNavTargetFirstPreDrawLogged: Boolean = false
    private var transientPlaybackResumeRequested: Boolean? = null
    private var decoderReleaseRequestedOnStop: Boolean = false
    private var resumeAfterDecoderRelease: Boolean = false
    private var resumeAfterDecoderReleasePositionMs: Long = 0L
    private var resumeAfterDecoderReleasePlayWhenReady: Boolean = true
    private var resumeExpiredUrlReloadArmed: Boolean = false
    private var resumeExpiredUrlReloadAttempted: Boolean = false
    private var playUrlAutoRefreshJob: kotlinx.coroutines.Job? = null
    private var playUrlAutoRefreshToken: Int = 0
    private var playUrlAutoRefreshLastReloadAtElapsedMs: Long = 0L

    internal var currentVideoShot: VideoShot? = null
    internal var videoShotImageCache: VideoShotImageCache? = null
    internal var videoShotFetchJob: Job? = null
    internal var videoShotPreviewRequestId: Long = 0L
    internal var startupEnhancementJob: Job? = null
    internal var currentVideoContentWidth: Int? = null
    internal var currentVideoContentHeight: Int? = null

    private fun isPlayerTeardownInProgress(): Boolean {
        return exitCleanupRequested || isFinishing || isDestroyed || decoderReleaseRequestedOnStop || resumeAfterDecoderRelease
    }

    private fun shouldSuppressPlayerError(error: Throwable): Boolean {
        if (!isPlayerTeardownInProgress()) return false
        val playbackException = error as? PlaybackException
        val errorLabel = playbackException?.errorCodeName ?: (error.message ?: error::class.java.simpleName)
        trace?.log("player:error:ignored", "type=$errorLabel teardown=1")
        AppLog.i(
            "Player",
            "ignorePlayerError teardown=1 finishing=${if (isFinishing) 1 else 0} destroyed=${if (isDestroyed) 1 else 0} " +
                "exitCleanup=${if (exitCleanupRequested) 1 else 0} releaseOnStop=${if (decoderReleaseRequestedOnStop) 1 else 0} " +
                "resumeAfterRelease=${if (resumeAfterDecoderRelease) 1 else 0} type=$errorLabel",
        )
        return true
    }

    private fun exitTraceStart(trigger: String) {
        if (exitTraceStartAtMs != 0L) return
        val now = SystemClock.elapsedRealtime()
        exitTraceStartAtMs = now
        exitTraceStartTrigger = trigger
        startExitStallWatcherIfNeeded()
        registerExitNavCallbacksIfNeeded()
        AppLog.i(
            "Player",
            "$EXIT_TRACE_PREFIX dt=+0ms inst=${System.identityHashCode(this)} start=$trigger " +
                "bvid=${currentBvid.takeLast(8)} aid=${currentAid ?: -1} cid=$currentCid thread=${Thread.currentThread().name}",
        )
    }

    private fun exitTraceLog(stage: String, extra: String = "") {
        val now = SystemClock.elapsedRealtime()
        val dtText =
            if (exitTraceStartAtMs > 0L) {
                "dt=+${now - exitTraceStartAtMs}ms"
            } else {
                "dt=?"
            }
        val suffix = if (extra.isBlank()) "" else " $extra"
        AppLog.i(
            "Player",
            "$EXIT_TRACE_PREFIX $dtText inst=${System.identityHashCode(this)} " +
                "bvid=${currentBvid.takeLast(8)} aid=${currentAid ?: -1} cid=$currentCid $stage$suffix",
        )
    }

    private fun startExitStallWatcherIfNeeded() {
        if (exitTraceStallWatchJob != null) return
        if (exitTraceStartAtMs <= 0L) return
        exitTraceStallWatchJob =
            lifecycleScope.launch(Dispatchers.Default) {
                
                
                val thresholdMs = 600L
                delay(thresholdMs)
                if (exitTraceStartAtMs <= 0L) return@launch
                if (exitTraceStopAtMs != 0L) return@launch
                if (exitTraceDestroyAtMs != 0L) return@launch
                if (exitTraceStallSampled) return@launch
                exitTraceStallSampled = true

                val now = SystemClock.elapsedRealtime()
                val dt = (now - exitTraceStartAtMs).coerceAtLeast(0L)
                val phase =
                    when {
                        exitTracePauseAtMs == 0L -> "wait_onPause"
                        exitTraceStopAtMs == 0L -> "wait_onStop"
                        else -> "wait_unknown"
                    }
                val main = Looper.getMainLooper().thread
                val state = main.state.toString()
                val top = captureThreadStackTop(main, maxFrames = 14)
                exitTraceLog(
                    "stall:$phase",
                    "waited=${dt}ms start=${exitTraceStartTrigger.orEmpty()} mainState=$state top=$top",
                )
            }
    }

    private fun captureThreadStackTop(thread: Thread, maxFrames: Int): String {
        val frames =
            runCatching { thread.stackTrace.toList() }
                .getOrDefault(emptyList())
                .asSequence()
                
                .filterNot { f ->
                    val c = f.className
                    c.startsWith("java.lang.Thread") ||
                        c.startsWith("dalvik.system.VMStack") ||
                        c.startsWith("kotlinx.coroutines")
                }
                .take(maxFrames.coerceAtLeast(1))
                .toList()

        if (frames.isEmpty()) return "(empty)"
        
        return frames.joinToString(" <- ") { f ->
            val cls = f.className.substringAfterLast('.')
            "$cls.${f.methodName}:${f.lineNumber}"
        }
    }

    private fun registerExitNavCallbacksIfNeeded() {
        if (exitTraceNavCallbacks != null) return
        if (exitTraceStartAtMs <= 0L) return

        val cb =
            object : Application.ActivityLifecycleCallbacks {
                override fun onActivityCreated(activity: Activity, savedInstanceState: Bundle?) = Unit
                override fun onActivityStarted(activity: Activity) = Unit
                override fun onActivityPaused(activity: Activity) = Unit
                override fun onActivityStopped(activity: Activity) = Unit
                override fun onActivitySaveInstanceState(activity: Activity, outState: Bundle) = Unit
                override fun onActivityDestroyed(activity: Activity) = Unit

                override fun onActivityResumed(activity: Activity) {
                    if (exitTraceStartAtMs <= 0L) return
                    if (activity === this@PlayerActivity) return
                    if (exitTraceNavTargetResumedLogged) return
                    exitTraceNavTargetResumedLogged = true
                    exitTraceNavTarget = WeakReference(activity)

                    exitTraceLog(
                        "nav:target:resumed",
                        "activity=${activity.javaClass.simpleName} targetInst=${System.identityHashCode(activity)}",
                    )

                    
                    
                    
                    val decor = activity.window?.decorView ?: return
                    val observer = decor.viewTreeObserver
                    observer.addOnPreDrawListener(
                        object : android.view.ViewTreeObserver.OnPreDrawListener {
                            override fun onPreDraw(): Boolean {
                                if (!decor.viewTreeObserver.isAlive) return true
                                decor.viewTreeObserver.removeOnPreDrawListener(this)
                                if (exitTraceStartAtMs <= 0L) return true
                                if (exitTraceNavTargetFirstPreDrawLogged) return true
                                exitTraceNavTargetFirstPreDrawLogged = true
                                exitTraceLog(
                                    "nav:target:first_preDraw",
                                    "activity=${activity.javaClass.simpleName} targetInst=${System.identityHashCode(activity)}",
                                )
                                unregisterExitNavCallbacks(reason = "target_first_preDraw")
                                return true
                            }
                        },
                    )
                }
            }

        exitTraceNavCallbacks = cb
        runCatching { application.registerActivityLifecycleCallbacks(cb) }
            .onSuccess { exitTraceLog("nav:callbacks:register") }
            .onFailure { exitTraceNavCallbacks = null }
    }

    private fun unregisterExitNavCallbacks(reason: String) {
        val cb = exitTraceNavCallbacks ?: return
        exitTraceNavCallbacks = null
        runCatching { application.unregisterActivityLifecycleCallbacks(cb) }
        exitTraceLog("nav:callbacks:unregister", "reason=$reason")
    }

    internal class PlaybackTrace(private val id: String) {
        private val startMs = SystemClock.elapsedRealtime()
        private var lastMs = startMs

        fun log(stage: String, extra: String = "") {
            val now = SystemClock.elapsedRealtime()
            val total = now - startMs
            val delta = now - lastMs
            lastMs = now
            val suffix = if (extra.isBlank()) "" else " $extra"
            
            AppLog.i("Player", "traceId=$id +${total}ms (+${delta}ms) $stage$suffix")
        }
    }

    internal var trace: PlaybackTrace? = null
    internal var traceFirstFrameLogged: Boolean = false

    internal fun prepareTransientPlaybackExit() {
        val engine = player ?: return
        val shouldResume = engine.isPlaying || engine.playWhenReady
        transientPlaybackResumeRequested = shouldResume
        decoderReleaseRequestedOnStop = engine is ExoPlayerEngine
        trace?.log(
            "player:transientExit",
            "resume=${if (shouldResume) 1 else 0} releaseOnStop=${if (decoderReleaseRequestedOnStop) 1 else 0}",
        )
        engine.pause()
    }

    private fun releaseDecoderNowForBackground() {
        val engine = player ?: return
        if (engine !is ExoPlayerEngine) return
        if (exitCleanupRequested || isFinishing || isDestroyed) return
        val pos = engine.currentPosition.coerceAtLeast(0L)
        val shouldPlayAfterReturn =
            transientPlaybackResumeRequested
                ?: (engine.isPlaying || engine.playWhenReady)
        transientPlaybackResumeRequested = null
        trace?.log("exo:releaseOnStop:do", "pos=${pos}ms")

        
        stopReportProgressLoop(flush = false, reason = "transient_nav")
        enqueueExitProgressReport(reason = "transient_nav")

        resumeAfterDecoderRelease = true
        resumeAfterDecoderReleasePositionMs = pos
        resumeAfterDecoderReleasePlayWhenReady = shouldPlayAfterReturn

        
        if (::binding.isInitialized) {
            binding.playerView.player = null
        }
        engine.playWhenReady = false
        engine.stop()
    }

    private fun requestExitCleanup(reason: String) {
        if (reason.isNotBlank()) exitTraceStart("cleanup:$reason")
        if (exitCleanupRequested) return
        exitCleanupRequested = true
        exitCleanupReason = reason
        transientPlaybackResumeRequested = null
        decoderReleaseRequestedOnStop = false
        cancelPlayUrlAutoRefresh(reason = "exit_cleanup:$reason")
        trace?.log("activity:exit:request", "reason=$reason")
        exitTraceLog(
            "exitCleanup:request",
            "reason=$reason thread=${Thread.currentThread().name} bvid=${currentBvid.takeLast(8)} aid=${currentAid ?: -1} cid=$currentCid",
        )

        val t0 = SystemClock.elapsedRealtime()
        val tPause = SystemClock.elapsedRealtime()
        player?.pause()
        val pauseCostMs = SystemClock.elapsedRealtime() - tPause
        exitTraceLog("exitCleanup:pause", "cost=${pauseCostMs}ms")
        exitTraceLog("exitCleanup:detachView", "deferred=1")

        val tStop = SystemClock.elapsedRealtime()
        stopReportProgressLoop(flush = false, reason = reason)
        val stopCostMs = SystemClock.elapsedRealtime() - tStop
        exitTraceLog("exitCleanup:stopReportLoop", "cost=${stopCostMs}ms")

        val tEnq = SystemClock.elapsedRealtime()
        enqueueExitProgressReport(reason = reason)
        val enqCostMs = SystemClock.elapsedRealtime() - tEnq
        exitTraceLog("exitCleanup:enqueueExitReport", "cost=${enqCostMs}ms")

        val totalCostMs = SystemClock.elapsedRealtime() - t0
        exitTraceLog("exitCleanup:done", "totalCost=${totalCostMs}ms")
    }

    private fun enqueueExitProgressReport(reason: String) {
        val trace = trace
        
        
        if (autoResumeHintVisible) {
            trace?.log("report:skip", "autoResumeHint=1 reason=$reason")
            return
        }
        val exo = player ?: return
        val progressSec = (exo.currentPosition.coerceAtLeast(0L) / 1000L)

        val tChecks0 = SystemClock.elapsedRealtime()
        val shouldHistory = shouldReportHistoryNow()
        val tChecks1 = SystemClock.elapsedRealtime()
        val shouldHeartbeat = shouldReportWebHeartbeatNow()
        val tChecks2 = SystemClock.elapsedRealtime()
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog(
                "exitReport:check",
                "reason=$reason history=${if (shouldHistory) 1 else 0} heartbeat=${if (shouldHeartbeat) 1 else 0} " +
                    "costHistory=${tChecks1 - tChecks0}ms costHeartbeat=${tChecks2 - tChecks1}ms total=${tChecks2 - tChecks0}ms",
            )
        }
        if (!shouldHistory && !shouldHeartbeat) return

        val cid = currentCid
        val aid = currentAid
        val epId = currentEpId
        val isPgc = epId != null && epId > 0L
        val heartbeatType = if (isPgc) 4 else 3
        val seasonId = parseSeasonIdFromPlaylistSource()
        val exitPlayType = if (exitCleanupRequested || isFinishing) 4 else 0

        if (shouldHistory && aid != null) trace?.log("report:history:enqueue", "sec=$progressSec reason=$reason")
        if (shouldHeartbeat) trace?.log("report:heartbeat:enqueue", "sec=$progressSec type=$heartbeatType reason=$reason")
        BlblApp.launchIo {
            if (shouldHistory && aid != null) {
                runCatching {
                    BiliApi.historyReport(aid = aid, cid = cid, progressSec = progressSec, platform = "android")
                }.onSuccess {
                    trace?.log("report:history", "ok=1 sec=$progressSec reason=$reason")
                }.onFailure {
                    trace?.log("report:history", "ok=0 sec=$progressSec reason=$reason")
                }
            }
            if (shouldHeartbeat) {
                runCatching {
                    BiliApi.webHeartbeat(
                        aid = aid,
                        bvid = currentBvid,
                        cid = cid,
                        epId = epId.takeIf { isPgc },
                        seasonId = seasonId.takeIf { isPgc },
                        playedTimeSec = progressSec,
                        type = heartbeatType,
                        playType = exitPlayType,
                    )
                }.onSuccess {
                    trace?.log("report:heartbeat", "ok=1 sec=$progressSec type=$heartbeatType reason=$reason")
                }.onFailure {
                    trace?.log("report:heartbeat", "ok=0 sec=$progressSec type=$heartbeatType reason=$reason")
                }
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerOsdSizing.applyTheme(this)
        ActivityStackLimiter.register(group = ACTIVITY_STACK_GROUP, activity = this, maxDepth = ACTIVITY_STACK_MAX_DEPTH)
        val prefs = BiliClient.prefs
        val playerInflater = PlayerOsdSizing.cloneInflater(this, layoutInflater)
        val root =
            playerInflater.inflate(
                if (prefs.playerRenderViewType == AppPrefs.PLAYER_RENDER_VIEW_TEXTURE_VIEW) R.layout.activity_player_texture else R.layout.activity_player,
                null,
            )
        binding = ActivityPlayerBinding.bind(root)
        upQuickCard =
            PlayerUpQuickCardController(
                activity = this,
                binding = binding,
                isCardVisible = { isTopBarContentVisible() },
                keepControlsVisible = { setControlsVisible(true) },
                beforeOpenUpDetail = { prepareTransientPlaybackExit() },
                onUiUpdated = {
                    updatePlayerInfoUpUi()
                    updateUpButton()
                },
            )
        setContentView(binding.root)
        Immersive.apply(this, prefs.fullscreenEnabled)
        PlayerUiMode.applyVideo(this, binding)
        ensureBottomBarConstraintSets()

        binding.bottomBar.visibility = View.GONE
        binding.progressPersistentBottom.max = SEEK_MAX
        updateTopBarUi()
        resetBufferingOverlayState()
        binding.tvSeekHint.visibility = View.GONE
        binding.btnBack.setOnClickListener { finish() }
        
        binding.btnBack.isFocusable = false
        binding.btnBack.isFocusableInTouchMode = false
        binding.tvOnline.text = "-人正在观看"
        binding.llTitleMeta.visibility = View.VISIBLE
        binding.tvViewCount.text = "-"
        binding.tvPubdate.text = ""
        binding.tvPubdate.visibility = View.GONE

        val bvid = intent.getStringExtra(EXTRA_BVID).orEmpty()
        val cidExtra = intent.getLongExtra(EXTRA_CID, -1L).takeIf { it > 0 }
        val epIdExtra = intent.getLongExtra(EXTRA_EP_ID, -1L).takeIf { it > 0 }
        val aidExtra = intent.getLongExtra(EXTRA_AID, -1L).takeIf { it > 0 }
        val seasonIdExtra = intent.getLongExtra(EXTRA_SEASON_ID, -1L).takeIf { it > 0 }
        audioOnlyMode = intent.getBooleanExtra(EXTRA_AUDIO_ONLY, false)
        
        
        BiliClient.prefs.shuffleModeEnabled = intent.getBooleanExtra(EXTRA_SHUFFLE, false)
        val startPositionMsExtra =
            intent.getLongExtra(EXTRA_START_POSITION_MS, -1L)
                .takeIf { intent.hasExtra(EXTRA_START_POSITION_MS) && it > 0L }
        pageListToken = intent.getStringExtra(EXTRA_PLAYLIST_TOKEN)?.trim()?.takeIf { it.isNotBlank() }
        pageListIndex = intent.getIntExtra(EXTRA_PLAYLIST_INDEX, -1)
        val pageListIndexExtra = pageListIndex
        pageListToken?.let { token ->
            val p = PlayerPlaylistStore.get(token)
            if (p != null && p.items.isNotEmpty()) {
                pageListSource = p.source
                pageListItems = p.items
                pageListUiCards =
                    p.uiCards.takeIf { it.isNotEmpty() && it.size == p.items.size }
                        ?: emptyList()
                pageListContinuation = p.continuation
                val idx = pageListIndex.takeIf { it in pageListItems.indices } ?: p.index
                pageListIndex = idx.coerceIn(0, pageListItems.lastIndex)
                PlayerPlaylistStore.updateIndex(token, pageListIndex)
            } else {
                pageListUiCards = emptyList()
            }
        }
        if (epIdExtra != null) {
            AppLog.i(
                "Player",
                "CONTINUE_DEBUG intentPgc bvid=${bvid.takeLast(8)} cidExtra=${cidExtra ?: -1L} epIdExtra=$epIdExtra " +
                    "aidExtra=${aidExtra ?: -1L} token=${pageListToken?.takeLast(6).orEmpty()} " +
                    "idxExtra=$pageListIndexExtra idxResolved=$pageListIndex src=${pageListSource.orEmpty()}",
            )
        }
        trace =
            PlaybackTrace(
                buildString {
                    val token = bvid.takeLast(8).ifBlank { aidExtra?.toString(16) ?: "unknown" }
                    append(token)
                    append('-')
                    append((System.currentTimeMillis() and 0xFFFF).toString(16))
                },
            ).also { it.log("activity:onCreate") }
        currentBvid = bvid
        currentEpId = epIdExtra
        currentAid = aidExtra
        currentSeasonId = seasonIdExtra ?: parseBangumiSeasonIdFromSource(pageListSource)
        if (startPositionMsExtra != null) {
            pendingIntentResumeCandidate =
                ResumeCandidate(
                    rawTime = startPositionMsExtra,
                    rawTimeUnitHint = RawTimeUnitHint.MILLIS_LIKELY,
                    source = "intent",
                )
            pendingIntentResumeCid = cidExtra
            pendingIntentResumeEpId = epIdExtra
        }
        if (currentBvid.isBlank() && currentAid == null) {
            AppToast.show(this, "缺少 bvid/aid")
            finish()
            return
        }

        pendingStartPositionMs =
            intent.getLongExtra(EXTRA_ENGINE_SWITCH_RESUME_POSITION_MS, -1L)
                .takeIf { intent.hasExtra(EXTRA_ENGINE_SWITCH_RESUME_POSITION_MS) && it >= 0L }
        pendingStartPlayWhenReady =
            if (intent.hasExtra(EXTRA_ENGINE_SWITCH_RESUME_PLAY_WHEN_READY)) {
                intent.getBooleanExtra(EXTRA_ENGINE_SWITCH_RESUME_PLAY_WHEN_READY, true)
            } else {
                null
            }
        val sessionOverrideJson =
            intent.getStringExtra(EXTRA_ENGINE_SWITCH_SESSION_JSON)
                ?.trim()
                ?.takeIf { it.isNotBlank() }

        session = PlayerSessionSettings(
            playbackSpeed = prefs.playerSpeed,
            preferCodec = prefs.playerPreferredCodec,
            seamlessQualitySwitchEnabled = prefs.playerSeamlessQualitySwitchEnabled,
            preferAudioId = prefs.playerPreferredAudioId,
            preferredQn = if (isPgcLikePlayback()) prefs.playerPreferredQnPgc else prefs.playerPreferredQn,
            targetQn = 0,
            playbackModeOverride = null,
            subtitleEnabled = prefs.subtitleEnabledDefault,
            subtitleLangOverride = null,
            subtitleTextSizeSp = prefs.subtitleTextSizeSp,
            subtitleBottomPaddingFraction = prefs.subtitleBottomPaddingFraction,
            subtitleBackgroundOpacity = prefs.subtitleBackgroundOpacity,
            audioBalanceLevel = AudioBalanceLevel.fromPrefValue(prefs.playerAudioBalanceLevel),
            persistentBottomProgressEnabled = prefs.playerPersistentBottomProgressEnabled,
            danmaku = DanmakuSessionSettings(
                enabled = prefs.danmakuEnabled,
                opacity = prefs.danmakuOpacity,
                textSizeSp = prefs.danmakuTextSizeSp,
                fontWeight = DanmakuFontWeight.fromPrefValue(prefs.danmakuFontWeight),
                strokeWidthPx = prefs.danmakuStrokeWidthPx,
                speedLevel = prefs.danmakuSpeed,
                area = prefs.danmakuArea,
                laneDensity = DanmakuLaneDensity.fromPrefValue(prefs.danmakuLaneDensity),
                followBiliShield = prefs.danmakuFollowBiliShield,
                showHighLikeIcon = prefs.danmakuShowHighLikeIcon,
                aiShieldEnabled = prefs.danmakuAiShieldEnabled,
                aiShieldLevel = prefs.danmakuAiShieldLevel,
                allowScroll = prefs.danmakuAllowScroll,
                allowTop = prefs.danmakuAllowTop,
                allowBottom = prefs.danmakuAllowBottom,
                allowColor = prefs.danmakuAllowColor,
                allowSpecial = prefs.danmakuAllowSpecial,
            ),
            debugEnabled = prefs.playerDebugEnabled,
            engineKind = PlayerEngineKind.fromPrefValue(prefs.playerEngineKind),
        )
        if (sessionOverrideJson != null) {
            session = session.restoreFromEngineSwitchJsonString(sessionOverrideJson)
        }

        val desiredEngineKind = session.engineKind
        val engineKind =
            if (desiredEngineKind == PlayerEngineKind.IjkPlayer && !IjkPlayerPlugin.isInstalled(this)) {
                val status = IjkPlayerPlugin.status(this)
                val text =
                    if (status == IjkPlayerPlugin.InstallStatus.NeedsUpdate) {
                        "IjkPlayer 插件需要更新，已临时使用 ExoPlayer"
                    } else {
                        "IjkPlayer 插件未安装，已临时使用 ExoPlayer"
                    }
                AppToast.showLong(this, text)
                IjkPlayerPluginUi.ensureInstalled(this) {
                    if (!isFinishing && !isDestroyed) recreate()
                }
                PlayerEngineKind.ExoPlayer
            } else {
                desiredEngineKind
            }
        if (session.engineKind != engineKind) {
            session = session.copy(engineKind = engineKind)
        }
        updatePersistentBottomProgressBarVisibility()
        val engine: BlblPlayerEngine =
            when (engineKind) {
                PlayerEngineKind.IjkPlayer -> {
                    IjkPlayerEngine(context = this)
                }
                PlayerEngineKind.ExoPlayer -> {
                    ExoPlayerEngine(
                        context = this,
                        audioBalanceLevel = session.audioBalanceLevel,
                        onTransferHost = { kind, host ->
                            when (kind) {
                                DebugStreamKind.VIDEO -> debug.videoTransferHost = host
                                DebugStreamKind.AUDIO -> debug.audioTransferHost = host
                                DebugStreamKind.MAIN -> debug.videoTransferHost = host
                            }
                        },
                        onBytesTransferred = { _, bytes ->
                            recordBufferingTransferBytes(bytes)
                        },
                    )
                }
            }
        player = engine
        applyRenderForEngine(engine, prefs)
        val exo = (engine as? ExoPlayerEngine)?.exoPlayer
        trace?.log("player:created", "kind=${engine.kind.prefValue}")
        binding.danmakuView.setPositionProvider { player?.currentPosition ?: 0L }
        binding.danmakuView.setIsPlayingProvider { player?.isPlaying == true }
        binding.danmakuView.setPlaybackSpeedProvider { player?.playbackSpeed ?: 1.0f }
        binding.danmakuView.setConfigProvider { session.danmaku.toConfig() }
        if (engine.capabilities.subtitlesSupported && exo != null) {
            configureSubtitleView()
        }
        engine.setPlaybackSpeed(session.playbackSpeed)
        applyPlaybackMode(engine)
        
        if (engine.capabilities.subtitlesSupported && exo != null) {
            applySubtitleEnabled(exo)
        }
        engine.addListener(
            object : BlblPlayerEngine.Listener {
                override fun onPlayerError(error: Throwable) {
                    resetBufferingOverlayState()
                    if (shouldSuppressPlayerError(error)) return
                    AppLog.e("Player", "onPlayerError", error)
                    val playbackException = error as? PlaybackException
                    if (playbackException != null) {
                        if (engine.isSeamlessQualitySource && !seamlessQualitySwitchDisabledForPlayback) {
                            seamlessQualitySwitchDisabledForPlayback = true
                            AppLog.w(
                                "Player",
                                "seamless DASH playback failed; fallback to legacy source error=${playbackException.errorCodeName}",
                                playbackException,
                            )
                            trace?.log("player:seamlessFallback", "error=${playbackException.errorCodeName}")
                            reloadStream(keepPosition = true, resetConstraints = false, reason = "seamless_player_error")
                            return
                        }
                        val httpCode = findHttpResponseCode(playbackException)
                        trace?.log("player:error", "type=${playbackException.errorCodeName} http=${httpCode ?: -1}")
                        if (maybeReloadExpiredUrlAfterResume(playbackException, httpCode)) return
                        val picked = lastPickedDash
                        if (
                            picked != null &&
                            picked.shouldAttemptDolbyFallback() &&
                            shouldAttemptHighSpecFallback(playbackException) &&
                            decodeFallbackAttemptCount < HIGH_SPEC_FALLBACK_MAX_ATTEMPTS
                        ) {
                            val nextConstraints = nextPlaybackConstraintsForDolbyFallback(picked)
                            if (nextConstraints != null) {
                                val nextAttempt = decodeFallbackAttemptCount + 1
                                AppLog.w(
                                    "Player",
                                    "fallback attempt=$nextAttempt/${HIGH_SPEC_FALLBACK_MAX_ATTEMPTS} error=${playbackException.errorCodeName} " +
                                        "pickedQn=${picked.qn} codecid=${picked.codecid} dv=${picked.isDolbyVision} " +
                                        "audio=${picked.audioKind}(${picked.audioId}) from=$playbackConstraints to=$nextConstraints",
                                )
                                decodeFallbackAttemptCount = nextAttempt
                                playbackConstraints = nextConstraints
                                trace?.log(
                                    "player:fallback",
                                    "attempt=$decodeFallbackAttemptCount/${HIGH_SPEC_FALLBACK_MAX_ATTEMPTS} type=${playbackException.errorCodeName} to=$nextConstraints",
                                )
                                AppToast.show(this@PlayerActivity, "杜比/无损播放失败，尝试回退到普通轨道…")
                                reloadStream(keepPosition = true, resetConstraints = false)
                                return
                            }
                        }
                        AppToast.show(this@PlayerActivity, "播放失败：${playbackException.errorCodeName}")
                        return
                    }
                    AppToast.showLong(this@PlayerActivity, "播放失败：${error.message ?: "未知错误"}")
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updatePlayPauseIcon(isPlaying)
                    restartAutoHideTimer()
                    
                    binding.danmakuView.invalidate()
                    if (isPlaying) {
                        startReportProgressLoop()
                    } else {
                        
                        stopReportProgressLoop(flush = false, reason = "pause")
                    }
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    updateProgressUi()
                    val state =
                        when (playbackState) {
                            Player.STATE_IDLE -> "IDLE"
                            Player.STATE_BUFFERING -> "BUFFERING"
                            Player.STATE_READY -> "READY"
                            Player.STATE_ENDED -> "ENDED"
                            else -> playbackState.toString()
                        }
                    trace?.log("player:state", "state=$state pos=${engine.currentPosition}ms")
                    if (playbackState == Player.STATE_BUFFERING && debug.lastPlaybackState != Player.STATE_BUFFERING && engine.playWhenReady) {
                        debug.rebufferCount++
                    }
                    if (playbackState == Player.STATE_BUFFERING) {
                        bufferingOverlayController.onBufferingStarted(
                            resetSpeedSample = debug.lastPlaybackState != Player.STATE_BUFFERING,
                        )
                    } else {
                        resetBufferingOverlayState()
                    }
                    debug.lastPlaybackState = playbackState
                    if (playbackState == Player.STATE_READY && resumeExpiredUrlReloadArmed) {
                        resumeExpiredUrlReloadArmed = false
                        trace?.log("player:resumeReload:disarm", "state=READY")
                    }
                    if (playbackState == Player.STATE_ENDED) {
                        stopReportProgressLoop(flush = true, reason = "ended")
                        handlePlaybackEnded(engine)
                    }
                }

                override fun onPositionDiscontinuity(newPositionMs: Long) {
                    
                    
                    binding.danmakuView.notifySeek(newPositionMs)
                    requestDanmakuSegmentsForPosition(newPositionMs, immediate = true)
                }

                override fun onVideoSizeChanged(width: Int, height: Int) {
                    if (width <= 0 || height <= 0) return
                    currentVideoContentWidth = width
                    currentVideoContentHeight = height
                    debug.videoInputWidth = width
                    debug.videoInputHeight = height
                    binding.videoShotPreview.setContentAspectRatio(width, height)
                    if (engine.kind != PlayerEngineKind.IjkPlayer) return
                    binding.ijkAspect.setAspectRatio(width.toFloat() / height.toFloat())
                }

                override fun onVideoTrackChanged(qn: Int, codecid: Int) {
                    trace?.log("player:videoTrack", "qn=$qn codecid=$codecid pos=${engine.currentPosition}ms")
                    applyResolutionFallbackIfNeeded(requestedQn = session.targetQn, actualQn = qn)
                    pendingResolutionSuccessHintQn?.let {
                        pendingResolutionSuccessHintQn = null
                        showSeekHint("已切换到 ${qnLabel(qn)}", hold = false)
                    }
                }

                override fun onRenderedFirstFrame() {
                    if (engine.kind != PlayerEngineKind.IjkPlayer) return
                    if (traceFirstFrameLogged) return
                    traceFirstFrameLogged = true
                    trace?.log("ijk:firstFrame", "pos=${engine.currentPosition}ms")
                }
            },
        )

        exo?.addAnalyticsListener(
            object : AnalyticsListener {
            override fun onVideoDecoderInitialized(
                eventTime: EventTime,
                decoderName: String,
                initializedTimestampMs: Long,
                initializationDurationMs: Long,
            ) {
                debug.videoDecoderName = decoderName
            }

            override fun onVideoInputFormatChanged(eventTime: EventTime, format: Format, decoderReuseEvaluation: DecoderReuseEvaluation?) {
                debug.videoInputWidth = format.width.takeIf { it > 0 }
                debug.videoInputHeight = format.height.takeIf { it > 0 }
                debug.videoInputFps = format.frameRate.takeIf { it > 0f }
            }

            override fun onDroppedVideoFrames(eventTime: EventTime, droppedFrames: Int, elapsedMs: Long) {
                debug.droppedFramesTotal += droppedFrames.toLong().coerceAtLeast(0L)
            }

            override fun onVideoFrameProcessingOffset(eventTime: EventTime, totalProcessingOffsetUs: Long, frameCount: Int) {
                val now = eventTime.realtimeMs
                val last = debug.renderFpsLastAtMs
                debug.renderFpsLastAtMs = now
                if (last == null) return
                val deltaMs = now - last
                if (deltaMs <= 0L || deltaMs > 60_000L) return
                val frames = frameCount.coerceAtLeast(0)
                if (frames == 0) return
                debug.renderFps = (frames * 1000f) / deltaMs.toFloat()
            }

            override fun onRenderedFirstFrame(eventTime: EventTime, output: Any, renderTimeMs: Long) {
                if (traceFirstFrameLogged) return
                traceFirstFrameLogged = true
                trace?.log("exo:firstFrame", "pos=${engine.currentPosition}ms")
            }
        },
        )

        val settingsAdapter = PlayerSettingsAdapter { item -> handleSettingsItemClick(item) }
        binding.recyclerSettings.adapter = settingsAdapter
        binding.recyclerSettings.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        binding.recyclerSettings.addOnChildAttachStateChangeListener(
            object : androidx.recyclerview.widget.RecyclerView.OnChildAttachStateChangeListener {
                override fun onChildViewAttachedToWindow(view: View) {
                    view.setOnKeyListener { v, keyCode, event ->
                        if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                        val holder = binding.recyclerSettings.findContainingViewHolder(v) ?: return@setOnKeyListener false
                        val pos =
                            holder.bindingAdapterPosition.takeIf { it != androidx.recyclerview.widget.RecyclerView.NO_POSITION }
                                ?: return@setOnKeyListener false

                        when (keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                if (pos == 0) return@setOnKeyListener true
                                false
                            }

                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                val last = (binding.recyclerSettings.adapter?.itemCount ?: 0) - 1
                                if (pos == last) return@setOnKeyListener true
                                false
                            }

                            KeyEvent.KEYCODE_DPAD_RIGHT -> true

                            else -> false
                        }
                    }
                }

                override fun onChildViewDetachedFromWindow(view: View) {
                    view.setOnKeyListener(null)
                }
            },
        )
        refreshSettings(settingsAdapter)
        updateDebugOverlay()
        initPlayerInfoPanel()
        initSidePanels()
        initBottomCardPanel()
        initSponsorSubmitPanel()

        initControls(engine)
        applyOsdButtonsVisibility()

        val uncaughtHandler =
            CoroutineExceptionHandler { _, t ->
                AppLog.e("Player", "uncaught", t)
                AppToast.showLong(this@PlayerActivity, "播放失败：${t.message}")
                finish()
            }
        playbackUncaughtHandler = uncaughtHandler
        startPlayback(
            bvid = bvid,
            cidExtra = cidExtra,
            epIdExtra = epIdExtra,
            aidExtra = aidExtra,
            seasonIdExtra = seasonIdExtra,
            initialTitle = pageListItems.getOrNull(pageListIndex)?.title,
            startedFromList = PlayerVideoListKind.PAGE,
        )
    }

    internal data class PlayFetchResult(
        val stream: VideoPlayStream,
        val playable: Playable,
    )

    internal fun requestOnlineWatchingText(bvid: String, cid: Long) {
        
        binding.tvOnline.text = "-人正在观看"
        lifecycleScope.launch {
            val countText =
                withContext(Dispatchers.IO) {
                    runCatching {
                        BiliApi.videoOnlineStatus(bvid = bvid, cid = cid).displayCountText()
                    }.getOrDefault("-")
                }
            binding.tvOnline.text = "${countText}人正在观看"
        }
    }

    private fun recordVVoucher(vVoucher: String) {
        val prefs = BiliClient.prefs
        prefs.gaiaVgateVVoucher = vVoucher
        prefs.gaiaVgateVVoucherSavedAtMs = System.currentTimeMillis()
    }

    private suspend fun requestPlayStream(
        bvid: String,
        aid: Long?,
        cid: Long,
        epId: Long?,
        qn: Int,
        fnval: Int,
        tryLook: Boolean,
    ): VideoPlayStream {
        val safeBvid = bvid.trim()
        val safeAid = aid?.takeIf { it > 0 }
        val safeEpId = epId?.takeIf { it > 0 }
        val request =
            if (safeEpId != null) {
                VideoPlayRequest(
                    kind = VideoPlayKind.PGC,
                    bvid = safeBvid.takeIf { it.isNotBlank() },
                    aid = safeAid,
                    cid = cid,
                    epId = safeEpId,
                    qn = qn,
                    fnval = fnval,
                    tryLook = tryLook,
                    preferCodec = session.preferCodec,
                )
            } else {
                if (safeBvid.isBlank() && safeAid == null) error("bvid or aid required")
                VideoPlayRequest(
                    kind = VideoPlayKind.UGC,
                    bvid = safeBvid.takeIf { it.isNotBlank() },
                    aid = safeAid,
                    cid = cid,
                    qn = qn,
                    fnval = fnval,
                    tryLook = tryLook,
                    preferCodec = session.preferCodec,
                )
            }
        return BiliApi.playUrl(request)
    }

    private fun shouldAttemptTryLookFallback(stream: VideoPlayStream): Boolean {
        return !stream.hasPlayableStream()
    }

    private fun buildPlayStreamRiskPayload(stream: VideoPlayStream): String {
        val dash = stream.dash
        return buildString {
            append("source=").append(stream.source.prefValue)
            append(" kind=").append(stream.request.kind)
            append(" tryLook=").append(if (stream.request.tryLook) 1 else 0)
            append(" hasPlayableUrl=").append(if (stream.hasPlayableStream()) 1 else 0)
            append(" durationMs=").append(stream.durationMs ?: -1L)
            append(" dash=").append(if (dash != null) 1 else 0)
            append(" dashVideo=").append(dash?.videos?.size ?: 0)
            append(" dashAudio=").append(dash?.audios?.size ?: 0)
            append(" progressive=").append(stream.progressive.size)
            append(" supportQns=").append(stream.supportFormats.map { it.quality }.filter { it > 0 }.distinct())
            append(" hasVVoucher=").append(if (stream.vVoucher != null) 1 else 0)
            append(" clips=").append(stream.clipSegments.size)
            append(" resume=").append(if (stream.resume != null) 1 else 0)
        }
    }

    private fun buildPlayUrlRiskContext(
        bvid: String,
        aid: Long?,
        cid: Long,
        epId: Long?,
        qn: Int,
        fnval: Int,
    ): String =
        buildString {
            append("bvid=").append(bvid.trim().ifBlank { "-" })
            append(" aid=").append(aid ?: -1L)
            append(" cid=").append(cid)
            append(" epId=").append(epId ?: -1L)
            append(" qn=").append(qn)
            append(" fnval=").append(fnval)
            append(" sourcePref=").append(BiliClient.prefs.apiSource)
        }

    private fun logPlayUrlRiskResponse(
        stage: String,
        reason: String,
        context: String,
        stream: VideoPlayStream,
    ) {
        AppLog.w(
            "Player",
            buildString {
                append("risk-control ").append(stage).append(" reason=").append(reason).append('\n')
                append("context: ").append(context).append('\n')
                append(buildPlayStreamRiskPayload(stream))
            },
        )
    }

    private fun logPlayUrlRiskException(
        stage: String,
        reason: String,
        context: String,
        error: BiliApiException,
    ) {
        AppLog.w(
            "Player",
            "risk-control $stage reason=$reason context: $context apiCode=${error.apiCode} apiMessage=${error.apiMessage}",
        )
    }

    internal suspend fun loadPlayableWithTryLookFallback(
        bvid: String,
        aid: Long?,
        cid: Long,
        epId: Long?,
        qn: Int,
        fnval: Int,
        constraints: PlaybackConstraints,
    ): PlayFetchResult {
        val riskContext =
            buildPlayUrlRiskContext(
                bvid = bvid,
                aid = aid,
                cid = cid,
                epId = epId,
                qn = qn,
                fnval = fnval,
            )

        suspend fun requestTryLook(reason: String): VideoPlayStream {
            AppLog.w("Player", "risk-control try_look request reason=$reason context: $riskContext")
            return try {
                requestPlayStream(
                    bvid = bvid,
                    aid = aid,
                    cid = cid,
                    epId = epId,
                    qn = qn,
                    fnval = fnval,
                    tryLook = true,
                )
            } catch (t: Throwable) {
                AppLog.e("Player", "risk-control try_look request failed reason=$reason context: $riskContext", t)
                throw t
            }
        }

        suspend fun buildTryLookResult(
            fallbackStream: VideoPlayStream,
            riskCode: Int,
            riskMessage: String,
            failureMessage: String,
            reason: String,
        ): PlayFetchResult {
            logPlayUrlRiskResponse(
                stage = "try_look_response",
                reason = reason,
                context = riskContext,
                stream = fallbackStream,
            )
            val stream = fallbackStream.withRiskControl(code = riskCode, message = riskMessage)
            return try {
                val playable = pickPlayable(stream, constraints)
                PlayFetchResult(stream = stream, playable = playable)
            } catch (t: Throwable) {
                AppLog.e("Player", "risk-control try_look fallback failed reason=$reason context: $riskContext", t)
                throw BiliApiException(apiCode = -352, apiMessage = failureMessage)
            }
        }

        val primaryStream =
            try {
                requestPlayStream(
                    bvid = bvid,
                    aid = aid,
                    cid = cid,
                    epId = epId,
                    qn = qn,
                    fnval = fnval,
                    tryLook = false,
                )
            } catch (t: Throwable) {
                val e = t as? BiliApiException
                if (e != null && isRiskControl(e)) {
                    logPlayUrlRiskException(
                        stage = "primary_playurl_exception",
                        reason = "risk_api_error",
                        context = riskContext,
                        error = e,
                    )
                    val fallbackStream =
                        try {
                            requestTryLook(reason = "risk_api_error")
                        } catch (_: Throwable) {
                            throw BiliApiException(
                                apiCode = -352,
                                apiMessage = "风控拦截：主请求被限制，且 try_look 请求失败",
                            )
                        }
                    return buildTryLookResult(
                        fallbackStream = fallbackStream,
                        riskCode = e.apiCode,
                        riskMessage = e.apiMessage,
                        failureMessage = "风控拦截：主请求被限制，且 try_look 兜底失败",
                        reason = "risk_api_error",
                    )
                }
                throw t
            }

        if (shouldAttemptTryLookFallback(primaryStream)) {
            primaryStream.vVoucher?.let { recordVVoucher(it) }
            logPlayUrlRiskResponse(
                stage = "primary_playurl_response",
                reason = "no_playable_url",
                context = riskContext,
                stream = primaryStream,
            )
            val fallbackStream =
                try {
                    requestTryLook(reason = "no_playable_url")
                } catch (_: Throwable) {
                    throw BiliApiException(
                        apiCode = -352,
                        apiMessage = "风控拦截：主返回未提供可播放地址，且 try_look 请求失败",
                    )
                }
            return buildTryLookResult(
                fallbackStream = fallbackStream,
                riskCode = -352,
                riskMessage = "fallback try_look after no playable stream",
                failureMessage = "风控拦截：主返回未提供可播放地址，且 try_look 兜底失败",
                reason = "no_playable_url",
            )
        }

        val playable = pickPlayable(primaryStream, constraints)
        return PlayFetchResult(stream = primaryStream, playable = playable)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("window:focus", "hasFocus=${if (hasFocus) 1 else 0}")
        }
        if (hasFocus) Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)
    }

    override fun onResume() {
        super.onResume()
        PlayerOsdSizing.applyTheme(this)
        PlayerUiMode.applyVideo(this, binding)
        applyOsdButtonsVisibility()
        
        binding.btnBack.isFocusable = false
        binding.btnBack.isFocusableInTouchMode = false
        updatePersistentBottomProgressBarVisibility()
        (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.let { refreshSettings(it) }
        consumeTransientPlaybackResumeIfNeeded()
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode

        if (dispatchCommentImageViewerKey(event)) return true

        
        
        val popupHost = PopupHost.peek(this)
        if (popupHost != null) {
            if (popupHost.consumeBackLikeKeyEventIfNeeded(event)) {
                finishOnBackKeyUp = false
                return true
            }
            if (popupHost.hasModalView()) {
                return super.dispatchKeyEvent(event)
            }
        }

        if (dispatchSponsorSubmitPanelKey(event)) return true

        if (isBottomCardPanelVisible()) {
            val focused = currentFocus
            val focusInPanel = focused != null && FocusTreeUtils.isDescendantOf(focused, binding.recommendPanel)

            if (
                keyCode == KeyEvent.KEYCODE_BACK ||
                keyCode == KeyEvent.KEYCODE_ESCAPE ||
                keyCode == KeyEvent.KEYCODE_BUTTON_B
            ) {
                
                if (event.action == KeyEvent.ACTION_DOWN) {
                    finishOnBackKeyUp = false
                    hideBottomCardPanel()
                }
                return true
            }

            
            
            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_UP,
                KeyEvent.KEYCODE_DPAD_DOWN,
                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                KeyEvent.KEYCODE_DPAD_CENTER,
                KeyEvent.KEYCODE_ENTER,
                KeyEvent.KEYCODE_NUMPAD_ENTER,
                KeyEvent.KEYCODE_BUTTON_A,
                -> {
                    if (event.action == KeyEvent.ACTION_DOWN && isInteractionKey(keyCode)) noteUserInteraction()
                    if (!focusInPanel) {
                        ensureBottomCardPanelFocus()
                        return true
                    }
                    return super.dispatchKeyEvent(event)
                }
            }
        }

        if (event.action == KeyEvent.ACTION_DOWN && isInteractionKey(keyCode)) noteUserInteraction()

        when (val shortcutResult = dispatchPlayerCustomShortcutIfNeeded(event)) {
            PlayerCustomShortcutDispatchResult.NotHandled -> Unit
            PlayerCustomShortcutDispatchResult.Consumed -> return true
            is PlayerCustomShortcutDispatchResult.RunDefaultShortPress -> {
                return dispatchDefaultPlayerShortPress(
                    downEvent = shortcutResult.downEvent,
                    upEvent = shortcutResult.upEvent,
                )
            }
        }

        return dispatchPlayerKeyEventWithoutCustomShortcut(event)
    }

    private fun dispatchDefaultPlayerShortPress(downEvent: KeyEvent, upEvent: KeyEvent): Boolean {
        return PlayerDefaultShortPressDispatcher.dispatchAndConsume(
            context = this,
            downEvent = downEvent,
            upEvent = upEvent,
            dispatchDefaultEvent = ::dispatchPlayerKeyEventWithoutCustomShortcut,
        )
    }

    private fun dispatchPlayerKeyEventWithoutCustomShortcut(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        
        
        if (audioOnlyMode && binding.fmPanel.isVisible) {
            if (event.action == KeyEvent.ACTION_DOWN) {
                when (keyCode) {
                    KeyEvent.KEYCODE_DPAD_UP,
                    KeyEvent.KEYCODE_DPAD_DOWN,
                    -> {
                        if (event.repeatCount == 0 && shuffleSwitchReady()) {
                            playRandomNext(userInitiated = false)
                        }
                        return true
                    }

                    KeyEvent.KEYCODE_DPAD_CENTER,
                    KeyEvent.KEYCODE_ENTER,
                    KeyEvent.KEYCODE_NUMPAD_ENTER,
                    -> {
                        val focused = currentFocus
                        val onFmControl =
                            focused != null &&
                                focused !== binding.fmPanel &&
                                focused !== binding.fmSeek &&
                                FocusTreeUtils.isDescendantOf(focused, binding.fmPanel)
                        if (onFmControl) return super.dispatchKeyEvent(event)
                        togglePlayPauseFromUser()
                        updateFmPlayIcon()
                        setControlsVisible(true)
                        return true
                    }

                    KeyEvent.KEYCODE_BACK,
                    KeyEvent.KEYCODE_ESCAPE,
                    KeyEvent.KEYCODE_BUTTON_B,
                    -> {
                        finishOnBackKeyUp = false
                        exitTraceLog("fm:back", "exit=1")
                        requestExitCleanup(reason = "fm_back")
                        finish()
                        return true
                    }

                    else -> Unit
                }
            }
            
        }
        if (event.action == KeyEvent.ACTION_UP) {
            if (
                keyCode == KeyEvent.KEYCODE_BACK ||
                keyCode == KeyEvent.KEYCODE_ESCAPE ||
                keyCode == KeyEvent.KEYCODE_BUTTON_B
            ) {
                if (finishOnBackKeyUp) {
                    finishOnBackKeyUp = false
                    exitTraceStart("back:up")
                    exitTraceLog(
                        "back:up exit=1",
                        "osd=$osdMode sidePanel=${if (isSidePanelVisible()) 1 else 0} thread=${Thread.currentThread().name}",
                    )
                    requestExitCleanup(reason = "back")
                    trace?.log("activity:finish", "via=back")
                    finish()
                }
                return true
            }

            if (isSeekKey(keyCode)) {
                
                
                val pendingDir = keySeekPendingDirection.takeIf { keySeekPendingKeyCode == keyCode } ?: 0
                if (keySeekPendingKeyCode == keyCode) clearKeySeekPending()

                if (holdSeekJob != null) {
                    stopHoldSeek()
                    return true
                }

                if (pendingDir != 0) {
                    smartSeek(direction = pendingDir, showControls = false, hintKind = SeekHintKind.Step)
                    return true
                }
            }
            return super.dispatchKeyEvent(event)
        }

        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        when (keyCode) {
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_SETTINGS,
            -> {
                if (audioOnlyMode && binding.fmPanel.isVisible) {
                    showFmMenu()
                    return true
                }
                if (menuRevealedPanelSessionActive && isOverlayPanelVisible()) {
                    when {
                        isCommentsPanelVisible() -> hideCommentsPanel()
                        isSettingsPanelVisible() -> hideSettingsPanel()
                        isBottomCardPanelVisible() -> hideBottomCardPanel()
                        else -> {
                            menuRevealedPanelSessionActive = false
                            setControlsVisible(false)
                        }
                    }
                    return true
                }
                if (isSidePanelVisible()) {
                    if (!isSettingsPanelVisible()) {
                        showSettingsPanel()
                    }
                    return true
                }
                if (
                    osdMode == OsdMode.Hidden
                ) {
                    showSettingsPanel(openedFromMenuKey = true)
                    return true
                }
                setControlsVisible(true)
                focusFirstControl()
                return true
            }

            KeyEvent.KEYCODE_INFO,
            KeyEvent.KEYCODE_GUIDE,
            -> {
                val wasHidden = osdMode == OsdMode.Hidden
                setControlsVisible(true)
                if (wasHidden) {
                    restoreLastOsdFocusOr { focusFirstControl() }
                } else {
                    focusFirstControl()
                }
                return true
            }

            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_ESCAPE,
            KeyEvent.KEYCODE_BUTTON_B,
            -> {
                val rolledBackAutoResume = tryRollbackAutoResumeOnBack()
                val cancelledAutoResume = !rolledBackAutoResume && autoResumeHintVisible
                val cancelledAutoSkip = autoSkipHintVisible || autoSkipPending != null
                
                
                val cancelledAutoNext = autoNextHintVisible
                if (cancelledAutoResume) cancelPendingAutoResume(reason = "back")
                if (cancelledAutoSkip) cancelPendingAutoSkip(reason = "back", markIgnored = true)
                if (cancelledAutoNext) cancelPendingAutoNext(reason = "back", markCancelledByUser = true)
                if (rolledBackAutoResume || cancelledAutoResume || cancelledAutoSkip || cancelledAutoNext) {
                    finishOnBackKeyUp = false
                    exitTraceLog(
                        "back:down action=cancel_hint",
                        "resume=${if (rolledBackAutoResume || cancelledAutoResume) 1 else 0} rollback=${if (rolledBackAutoResume) 1 else 0} skip=${if (cancelledAutoSkip) 1 else 0} next=${if (cancelledAutoNext) 1 else 0} osd=$osdMode sidePanel=${if (isSidePanelVisible()) 1 else 0}",
                    )
                    return true
                }
                finishOnBackKeyUp = false
                if (isSidePanelVisible()) {
                    exitTraceLog(
                        "back:down action=side_panel",
                        "settings=${if (isSettingsPanelVisible()) 1 else 0} comments=${if (isCommentsPanelVisible()) 1 else 0} thread=${if (isCommentThreadVisible()) 1 else 0}",
                    )
                    return onSidePanelBackPressed()
                }
                if (osdMode != OsdMode.Hidden) {
                    exitTraceLog("back:down action=hide_osd", "osd=$osdMode")
                    setControlsVisible(false)
                    return true
                }
                val enabled = BiliClient.prefs.playerDoubleBackToExit
                val willExit = doubleBackToExit.shouldExit(enabled = enabled)
                finishOnBackKeyUp = willExit
                exitTraceLog(
                    "back:down action=exit_check",
                    "doubleBack=${if (enabled) 1 else 0} willExitOnUp=${if (willExit) 1 else 0}",
                )
                return true
            }

            KeyEvent.KEYCODE_DPAD_UP -> {
                if (isSidePanelVisible()) return super.dispatchKeyEvent(event)
                if (BiliClient.prefs.shuffleModeEnabled) {
                    
                    if (event.repeatCount == 0 && shuffleSwitchReady()) {
                        playRandomNext(userInitiated = false)
                    }
                    return true
                }
                val wasHidden = osdMode == OsdMode.Hidden
                
                
                if (wasHidden) {
                    if (showListPanelFromShortcut()) return true
                }
                setControlsVisible(true)
                if (!binding.seekProgress.isFocused) {
                    if (wasHidden) {
                        restoreLastOsdFocusOr { focusSeekBar() }
                    } else {
                        focusSeekBar()
                    }
                    return true
                }
            }

            KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (isSidePanelVisible()) return super.dispatchKeyEvent(event)
                if (BiliClient.prefs.shuffleModeEnabled) {
                    if (event.repeatCount == 0 && shuffleSwitchReady()) {
                        playRandomNext(userInitiated = false)
                    }
                    return true
                }
                if (binding.seekProgress.isFocused) {
                    setControlsVisible(true)
                    focusFirstControl()
                    return true
                }
                if (osdMode == OsdMode.Hidden) {
                    setControlsVisible(true)
                    focusDownKeyOsdTargetControl()
                    return true
                }
            }

            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_BUTTON_A,
            -> {
                if (!isSidePanelVisible() && binding.seekProgress.isFocused) {
                    if (event.repeatCount == 0) {
                        togglePlayPauseFromUser()
                    }
                    return true
                }
                if (!isSidePanelVisible() && !hasControlsFocus()) {
                    if (osdMode == OsdMode.Hidden) {
                        binding.btnPlayPause.performClick()
                        if (osdMode != OsdMode.Hidden) {
                            restoreLastOsdFocusOr { focusFirstControl() }
                        }
                        return true
                    }
                    setControlsVisible(true)
                    restoreLastOsdFocusOr { focusFirstControl() }
                    return true
                }
                if (osdMode == OsdMode.Hidden && !isSidePanelVisible()) {
                    binding.btnPlayPause.performClick()
                    if (osdMode != OsdMode.Hidden) {
                        restoreLastOsdFocusOr { focusFirstControl() }
                    }
                    return true
                }
            }

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE,
            -> {
                binding.btnPlayPause.performClick()
                return true
            }

            KeyEvent.KEYCODE_MEDIA_NEXT -> {
                playNextByPlaybackMode(userInitiated = true)
                return true
            }

            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> {
                playPrevByPlaybackMode(userInitiated = true)
                return true
            }

            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_MEDIA_REWIND,
            KeyEvent.KEYCODE_BUTTON_L1,
            KeyEvent.KEYCODE_BUTTON_L2,
            -> {
                if (keyCode == KeyEvent.KEYCODE_DPAD_LEFT && isSidePanelVisible()) {
                    val panelRoot =
                        when {
                            isCommentsPanelVisible() -> binding.commentsPanel
                            isSettingsPanelVisible() -> binding.settingsPanel
                            else -> null
                        }
                    val focusedView = currentFocus
                    val hasLeftFocusInPanel =
                        if (panelRoot != null && focusedView != null) {
                            FocusFinder.getInstance()
                                .findNextFocus(panelRoot, focusedView, View.FOCUS_LEFT) != null
                        } else {
                            false
                        }
                    
                    if (!hasLeftFocusInPanel) return onSidePanelBackPressed()
                    return super.dispatchKeyEvent(event)
                }
                if (isSidePanelVisible()) return super.dispatchKeyEvent(event)
                if (hasControlsFocusOutsideSeekBar()) return super.dispatchKeyEvent(event)

                if (event.repeatCount > 0) {
                    clearKeySeekPending()
                    
                    startHoldScrub(direction = -1, showControls = false)
                    return true
                }

                if (holdSeekUsesProgressPreview(direction = -1)) showSeekOsd()
                beginKeySeekPending(keyCode = keyCode, direction = -1, showControls = false)
                return true
            }

            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
            KeyEvent.KEYCODE_BUTTON_R1,
            KeyEvent.KEYCODE_BUTTON_R2,
            -> {
                if (isSidePanelVisible()) return super.dispatchKeyEvent(event)
                if (hasControlsFocusOutsideSeekBar()) return super.dispatchKeyEvent(event)

                if (event.repeatCount > 0) {
                    clearKeySeekPending()
                    if (binding.seekProgress.isFocused) {
                        startHoldScrub(direction = +1, showControls = false)
                    } else {
                        startHoldSeek(direction = +1, showControls = false)
                    }
                    return true
                }

                if (holdSeekUsesProgressPreview(direction = +1)) showSeekOsd()
                beginKeySeekPending(keyCode = keyCode, direction = +1, showControls = false)
                return true
            }
        }

        return super.dispatchKeyEvent(event)
    }

    override fun onStop() {
        touchController?.onStop()
        cancelPlayerCustomShortcutPending()
        cancelDeferredKeySeekPreview()
        exitTraceStopAtMs = SystemClock.elapsedRealtime()
        if (exitCleanupRequested || isFinishing) {
            exitTraceStart("onStop")
            exitTraceLog(
                "lifecycle:onStop",
                "isFinishing=${if (isFinishing) 1 else 0} changingConfig=${if (isChangingConfigurations) 1 else 0} cleanupReason=${exitCleanupReason.orEmpty()}",
            )
        }
        trace?.log("activity:onStop")
        val releaseDecoderOnStop = decoderReleaseRequestedOnStop
        decoderReleaseRequestedOnStop = false
        if (isChangingConfigurations) {
            transientPlaybackResumeRequested = null
        }
        super.onStop()
        player?.pause()
        if ((exitCleanupRequested || isFinishing) && !isChangingConfigurations) {
            val tDetach = SystemClock.elapsedRealtime()
            if (::binding.isInitialized && binding.playerView.player != null) {
                binding.playerView.player = null
            }
            val detachCostMs = SystemClock.elapsedRealtime() - tDetach
            if (exitTraceStartAtMs > 0L) {
                exitTraceLog("exitCleanup:detachView:onStop", "cost=${detachCostMs}ms")
            }
        }
        if (releaseDecoderOnStop && !isChangingConfigurations) {
            releaseDecoderNowForBackground()
        } else {
            val flush = !isFinishing && !isChangingConfigurations && !exitCleanupRequested
            stopReportProgressLoop(flush = flush, reason = if (flush) "stop" else "stop_skip")
        }
    }

    override fun onStart() {
        super.onStart()
        val engine = player ?: return
        val exo = (engine as? ExoPlayerEngine)?.exoPlayer
        if (!resumeAfterDecoderRelease) return
        if (exitCleanupRequested || isFinishing || isDestroyed) return

        val pos = resumeAfterDecoderReleasePositionMs.coerceAtLeast(0L)
        val playWhenReadyAfterReturn = resumeAfterDecoderReleasePlayWhenReady
        resumeAfterDecoderRelease = false
        resumeAfterDecoderReleasePositionMs = 0L
        resumeAfterDecoderReleasePlayWhenReady = true
        trace?.log("exo:releaseOnStop:resume", "pos=${pos}ms")

        if (exo != null && ::binding.isInitialized && binding.playerView.player == null) {
            binding.playerView.player = exo
        }
        resumeExpiredUrlReloadArmed = true
        resumeExpiredUrlReloadAttempted = false
        engine.playWhenReady = playWhenReadyAfterReturn
        engine.prepare()
        if (pos > 0L) engine.seekTo(pos)
    }

    private fun consumeTransientPlaybackResumeIfNeeded() {
        val shouldResume = transientPlaybackResumeRequested ?: return
        transientPlaybackResumeRequested = null
        if (exitCleanupRequested || isFinishing || isDestroyed || isChangingConfigurations) return
        val engine = player ?: return
        if (shouldResume) {
            trace?.log("player:transientResume")
            engine.playWhenReady = true
        }
    }

    override fun onPause() {
        exitTracePauseAtMs = SystemClock.elapsedRealtime()
        if (exitCleanupRequested || isFinishing || exitTraceStartAtMs > 0L) {
            exitTraceStart("onPause")
            exitTraceLog(
                "lifecycle:onPause",
                "isFinishing=${if (isFinishing) 1 else 0} changingConfig=${if (isChangingConfigurations) 1 else 0} cleanupReason=${exitCleanupReason.orEmpty()}",
            )
        }
        trace?.log("activity:onPause")
        
        
        player?.pause()
        super.onPause()
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("lifecycle:onPause:afterSuper")
        }
    }

    override fun finish() {
        exitTraceStart("finish()")
        exitTraceLog(
            "finish:call",
            "isFinishing=${if (isFinishing) 1 else 0} cleanupRequested=${if (exitCleanupRequested) 1 else 0} cleanupReason=${exitCleanupReason.orEmpty()}",
        )
        requestExitCleanup(reason = "finish")
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("finish:beforeSuper", "isFinishing=${if (isFinishing) 1 else 0}")
        }
        super.finish()
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("finish:afterSuper", "isFinishing=${if (isFinishing) 1 else 0}")
        }
        applyCloseTransitionNoAnim()
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("finish:afterTransition")
        }
    }

    override fun onDestroy() {
        val t0 = SystemClock.elapsedRealtime()
        exitTraceDestroyAtMs = t0
        if (exitCleanupRequested || isFinishing || exitTraceStartAtMs > 0L) {
            exitTraceStart("onDestroy")
            exitTraceLog(
                "lifecycle:onDestroy:start",
                "isFinishing=${if (isFinishing) 1 else 0} changingConfig=${if (isChangingConfigurations) 1 else 0} cleanupReason=${exitCleanupReason.orEmpty()} player=${if (player != null) 1 else 0}",
            )
        }
        trace?.log("activity:onDestroy:start")
        debugJob?.cancel()
        progressJob?.cancel()
        autoResumeJob?.cancel()
        autoResumeHintTimeoutJob?.cancel()
        reportProgressJob?.cancel()
        autoHideJob?.cancel()
        seekOsdHideJob?.cancel()
        holdSeekJob?.cancel()
        seekHintJob?.cancel()
        keyScrubEndJob?.cancel()
        videoShotPreviewHideJob?.cancel()
        sponsorSubmitUploadJob?.cancel()
        startupEnhancementJob?.cancel()
        startupEnhancementJob = null
        subtitleLoadJob?.cancel()
        subtitleLoadJob = null
        releaseTouchGestures()
        videoShotFetchJob?.cancel()
        videoShotFetchJob = null
        videoShotImageCache?.clear()
        videoShotImageCache = null
        currentVideoShot = null
        currentVideoDetail = null
        relatedVideosFetchJob?.cancel()
        videoCommentsController?.release()
        videoCommentsController = null
        videoCommentImageViewerController = null
        releaseUpQuickCardJobs()
        pageListLoadMoreJob?.cancel()
        partsListLoadMoreJob?.cancel()
        pageListLoadMoreCallbacks.clear()
        partsListLoadMoreCallbacks.clear()
        loadJob?.cancel()
        cancelDanmakuLoading(reason = "destroy")
        loadJob = null
        dismissAutoResumeHint()
        stopReportProgressLoop(flush = false, reason = "destroy")
        trace?.log("exo:detachView")
        binding.playerView.player = null
        player?.setVideoSurface(null)
        ijkTextureSurface?.release()
        ijkTextureSurface = null
        val preReleaseCostMs = SystemClock.elapsedRealtime() - t0
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("onDestroy:preRelease", "cost=${preReleaseCostMs}ms")
        }
        trace?.log("exo:release:start")
        val releaseStart = SystemClock.elapsedRealtime()
        player?.release()
        val releaseCostMs = SystemClock.elapsedRealtime() - releaseStart
        trace?.log("exo:release:done")
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("exo:release:done", "cost=${releaseCostMs}ms thread=${Thread.currentThread().name}")
        }
        player = null
        pageListToken?.let(PlayerPlaylistStore::remove)
        ActivityStackLimiter.unregister(group = ACTIVITY_STACK_GROUP, activity = this)
        trace?.log("activity:onDestroy:beforeSuper")
        val totalCostMs = SystemClock.elapsedRealtime() - t0
        if (exitTraceStartAtMs > 0L) {
            exitTraceLog("lifecycle:onDestroy:beforeSuper", "totalCost=${totalCostMs}ms")
        }
        unregisterExitNavCallbacks(reason = "destroy")
        super.onDestroy()
    }

    internal fun openCurrentMediaDetail() {
        val epId = currentEpId
        if (epId != null && epId > 0L) {
            prepareTransientPlaybackExit()
            startActivity(
                Intent(this, BangumiDetailActivity::class.java)
                    .putExtra(BangumiDetailActivity.EXTRA_EP_ID, epId)
                    .putExtra(BangumiDetailActivity.EXTRA_CONTINUE_EP_ID, epId)
                    .putExtra(BangumiDetailActivity.EXTRA_IS_DRAMA, false),
            )
            return
        }

        val bvid = currentBvid.trim()
        val aid = currentAid?.takeIf { it > 0L }
        if (bvid.isBlank() && aid == null) {
            AppToast.show(this, "缺少 bvid/aid")
            return
        }

        prepareTransientPlaybackExit()
        val title =
            currentMainTitle?.trim().orEmpty().ifBlank {
                binding.tvTitle.text?.toString()?.trim().orEmpty()
            }
        startActivity(
            Intent(this, VideoDetailActivity::class.java)
                .putExtra(VideoDetailActivity.EXTRA_BVID, bvid)
                .putExtra(VideoDetailActivity.EXTRA_CID, currentCid.takeIf { it > 0L } ?: -1L)
                .apply { aid?.let { putExtra(VideoDetailActivity.EXTRA_AID, it) } }
                .apply { if (title.isNotBlank()) putExtra(VideoDetailActivity.EXTRA_TITLE, title) }
                .apply {
                    currentUpName?.takeIf { it.isNotBlank() }?.let { putExtra(VideoDetailActivity.EXTRA_OWNER_NAME, it) }
                    currentUpAvatar?.takeIf { it.isNotBlank() }?.let { putExtra(VideoDetailActivity.EXTRA_OWNER_AVATAR, it) }
                    currentUpMid.takeIf { it > 0L }?.let { putExtra(VideoDetailActivity.EXTRA_OWNER_MID, it) }
                }
                .apply {
                    pageListToken?.takeIf { it.isNotBlank() }?.let { putExtra(VideoDetailActivity.EXTRA_PLAYLIST_TOKEN, it) }
                    pageListIndex.takeIf { it >= 0 }?.let { putExtra(VideoDetailActivity.EXTRA_PLAYLIST_INDEX, it) }
                },
        )
    }

    internal fun openCurrentUpDetail() {
        openUpQuickCardProfile()
    }

    internal fun shouldShowOsdOnPlaybackToggle(): Boolean {
        if (isSidePanelVisible()) return true
        if (osdMode != OsdMode.Hidden) return true
        return BiliClient.prefs.playerTogglePlayStateShowOsd
    }

    internal fun togglePlayPauseFromUser(showHint: Boolean = false) {
        togglePlayPause(showControls = shouldShowOsdOnPlaybackToggle(), showHint = showHint)
    }

    internal fun togglePlayPause(showControls: Boolean = true, showHint: Boolean = false) {
        val engine = player ?: return
        if (engine.playbackState == Player.STATE_ENDED) {
            restartCurrentPlaybackFromBeginning(engine = engine, showControls = showControls, showHint = showHint)
            return
        }
        val willPlay = !engine.isPlaying
        if (willPlay) {
            engine.play()
        } else {
            engine.pause()
        }
        if (showControls) setControlsVisible(true)
        if (showHint) {
            showSeekHint(if (willPlay) "播放" else "暂停", hold = false)
        }
    }

    private fun initControls(engine: BlblPlayerEngine) {
        initTouchGestures()

        binding.btnAdvanced.setOnClickListener {
            toggleSettingsPanel()
        }
        binding.btnClosePlayer.setOnClickListener {
            binding.btnBack.performClick()
        }

        installLikeButtonHoldInteraction()
        binding.btnLike.setOnClickListener { onLikeButtonClicked() }
        binding.btnCoin.setOnClickListener { onCoinButtonClicked() }
        binding.btnFav.setOnClickListener { onFavButtonClicked() }
        
        
        binding.btnDislike.setOnClickListener {
            onDislikeCurrentVideo()
            setControlsVisible(true)
        }
        binding.btnShare.setOnClickListener {
            openShareSheet()
            setControlsVisible(true)
        }

        binding.btnVideoMode.setOnClickListener {
            toggleAudioOnlyMode()
            setControlsVisible(true)
        }

        binding.btnShuffle.setOnClickListener {
            toggleShuffleMode()
            setControlsVisible(true)
        }

        binding.btnLoop.setOnClickListener {
            val modes =
                listOf(
                    AppPrefs.PLAYER_PLAYBACK_MODE_NONE,
                    AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE,
                    AppPrefs.PLAYER_PLAYBACK_MODE_RECOMMEND,
                )
            val current = resolvedPlaybackMode()
            val next =
                if (current in modes) {
                    modes[(modes.indexOf(current) + 1) % modes.size]
                } else {
                    AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE
                }
            applyPlaybackModeSetting(next, engine)
            val label =
                when (next) {
                    AppPrefs.PLAYER_PLAYBACK_MODE_LOOP_ONE -> "单集循环"
                    AppPrefs.PLAYER_PLAYBACK_MODE_RECOMMEND -> "推荐连播"
                    else -> "顺序播放"
                }
            AppToast.show(this, label)
            updatePlaylistControls()
            setControlsVisible(true)
        }

        binding.btnSeason.setOnClickListener {
            if (currentSeasonTitle.isNullOrBlank() || currentSeasonCards.isEmpty()) {
                AppToast.show(this, "当前视频暂无合集")
            } else {
                openCurrentVideoSeason()
            }
            setControlsVisible(true)
        }

        binding.btnRotate.setOnClickListener {
            rotateVideoSurface()
            setControlsVisible(true)
        }

        binding.btnPlayPause.setOnClickListener {
            togglePlayPauseFromUser()
        }
        binding.btnPrev.setOnClickListener {
            playPrevByPlaybackMode(userInitiated = true)
            setControlsVisible(true)
        }
        binding.btnNext.setOnClickListener {
            playNextByPlaybackMode(userInitiated = true)
            setControlsVisible(true)
        }

        binding.btnListPanel.setOnClickListener {
            showListPanelFromButton()
            setControlsVisible(true)
        }

        binding.btnSponsorSubmit.setOnClickListener {
            openSponsorSubmitPanel()
        }

        binding.btnDanmaku.setOnClickListener {
            setDanmakuEnabled(!session.danmaku.enabled)
            setControlsVisible(true)
        }

        binding.btnSendDanmaku.setOnClickListener {
            openDanmakuSendDialog()
            setControlsVisible(true)
        }

        binding.btnDownload.setOnClickListener {
            startCurrentVideoDownload()
            setControlsVisible(true)
        }

        binding.btnComments.setOnClickListener {
            toggleCommentsPanel()
        }

        binding.btnDetail.setOnClickListener {
            openCurrentMediaDetail()
            setControlsVisible(true)
        }

        binding.btnSubtitle.setOnClickListener {
            val exo = (engine as? ExoPlayerEngine)?.exoPlayer
            if (exo == null) {
                AppToast.show(this, "当前播放器内核不支持字幕")
                return@setOnClickListener
            }
            toggleSubtitles(exo)
            setControlsVisible(true)
        }

        binding.btnUp.setOnClickListener {
            openCurrentUpDetail()
            setControlsVisible(true)
        }
        setupUpQuickCardActions()

        binding.seekProgress.max = SEEK_MAX
        binding.seekProgress.setOnSeekBarChangeListener(
            object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                    if (!fromUser) return
                    cancelPendingAutoResume(reason = "user_seek")
                    cancelPendingAutoSkip(reason = "user_seek", markIgnored = true)
                    cancelPendingAutoNext(reason = "user_seek", markCancelledByUser = false)
                    scrubbing = true
                    noteUserInteraction()
                    if (seekBar?.isPressed != true) {
                        suppressBufferingOverlayDuringKeySeek(KEY_SCRUB_END_DELAY_MS)
                        scheduleKeyScrubEnd()
                    }

                    val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs
                    if (duration != null) {
                        val previewPos = (duration * progress) / SEEK_MAX
                        if (seekBar?.isPressed != true) {
                            keySeekPreviewPosMs = previewPos
                        }
                        binding.tvTime.text = "${formatHms(previewPos)} / ${formatHms(duration)}"

                        val hasVideoShot =
                            currentVideoShot != null &&
                                BiliClient.prefs.playerVideoShotPreviewSize != AppPrefs.PLAYER_VIDEOSHOT_PREVIEW_SIZE_OFF
                        if (hasVideoShot) {
                            showVideoShotPreviewForSeek(progress, SEEK_MAX, previewPos, binding.seekProgress)
                        } else {
                            hideVideoShotPreviewNow()
                        }
                    }

                    if (binding.seekProgress.isFocused && duration != null) {
                        val seekTo = duration * progress / SEEK_MAX
                        if (seekBar?.isPressed != true) {
                            
                            
                            keyScrubPendingSeekToMs = seekTo
                            updateBufferingOverlay()
                        } else {
                            keySeekPreviewPosMs = null
                            val isIjkDragging = engine.kind == PlayerEngineKind.IjkPlayer
                            if (!isIjkDragging) engine.seekTo(seekTo)
                        }
                    }
                }

                override fun onStartTrackingTouch(seekBar: SeekBar?) {
                    cancelPendingAutoResume(reason = "user_seek")
                    cancelPendingAutoSkip(reason = "user_seek", markIgnored = true)
                    cancelPendingAutoNext(reason = "user_seek", markCancelledByUser = false)
                    cancelDeferredKeySeekPreview(resetScrubbing = false)
                    scrubbing = true
                    keyScrubPendingSeekToMs = null
                    keyScrubEndJob?.cancel()
                    setControlsVisible(true)
                }

                override fun onStopTrackingTouch(seekBar: SeekBar?) {
                    val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs ?: return
                    val progress = seekBar?.progress ?: return
                    val seekTo = duration * progress / SEEK_MAX
                    keySeekPreviewPosMs = null
                    keyScrubPendingSeekToMs = null
                    engine.seekTo(seekTo)
                    binding.tvTime.text = "${formatHms(seekTo)} / ${formatHms(duration)}"
                    requestDanmakuSegmentsForPosition(seekTo, immediate = true)
                    scrubbing = false
                    keyScrubEndJob?.cancel()
                    scheduleHideVideoShotPreviewAfterSeek()
                    setControlsVisible(true)
                    lifecycleScope.launch { reportProgressOnce(force = true, reason = "user_seek_end") }
                }
            },
        )

        updatePlayPauseIcon(engine.isPlaying)
        updateSubtitleButton()
        updateDanmakuButton()
        updateUpButton()
        updatePlaylistControls()
        
        setControlsVisible(false)
        startProgressLoop()
    }

    internal fun applyUpInfo(detail: VideoDetail) {
        val owner = detail.owner
        setUpQuickCardOwner(
            mid = owner?.mid?.takeIf { it > 0L } ?: 0L,
            name = owner?.name?.trim()?.takeIf { it.isNotBlank() },
            avatar = owner?.avatarUrl?.trim()?.takeIf { it.isNotBlank() },
        )
        applyUpFollowState(detail.upFollowed)
    }

    internal fun updateTopTitleUi(placeholder: String?) {
        val main =
            currentMainTitle?.trim().orEmpty().ifBlank {
                placeholder?.trim().orEmpty()
            }.ifBlank { "-" }

        val partTitle =
            if (partsListSource == "MultiPage") {
                partsListItems
                    .getOrNull(partsListIndex)
                    ?.title
                    ?.trim()
                    ?.takeIf { it.isNotBlank() }
            } else {
                null
            }

        val display =
            if (!partTitle.isNullOrBlank() && main != "-" && main != partTitle) {
                "$main  $partTitle"
            } else {
                main
            }

        if (binding.tvTitle.text?.toString() != display) {
            binding.tvTitle.text = display
        }
    }

    internal fun applyTitleMeta(detail: VideoDetail) {
        currentCoverUrl = detail.coverUrl?.takeIf { it.isNotBlank() } ?: currentCoverUrl
        currentOwnerName = detail.owner?.name?.takeIf { it.isNotBlank() } ?: currentOwnerName
        if (audioOnlyMode && binding.fmPanel.isVisible) refreshFmUi()
        val viewCount = detail.stat.view?.takeIf { it >= 0L }

        if (viewCount != null) {
            binding.llViewMeta.visibility = View.VISIBLE
            binding.tvViewCount.text = BlblFormat.count(viewCount)
        } else {
            binding.llViewMeta.visibility = View.GONE
        }

        val pubDateSec = detail.pubDateSec
        val pubDateText = pubDateSec?.let { BlblFormat.pubDateText(it) }.orEmpty()
        binding.tvPubdate.text = pubDateText
        binding.tvPubdate.visibility = if (pubDateText.isNotBlank()) View.VISIBLE else View.GONE

        attachOsdFocusHints()
    }

    private fun attachOsdFocusHints() {
        
        PlayerOsdHoverLabel.install(binding)
    }

    private fun shouldReportHistoryNow(): Boolean {
        if (!BiliClient.cookies.hasSessData()) return false
        val csrf = BiliClient.cookies.getCookieValue("bili_jct").orEmpty().trim()
        if (csrf.isBlank()) return false
        val aid = currentAid ?: return false
        if (aid <= 0L) return false
        val cid = currentCid
        if (cid <= 0L) return false
        
        
        val epId = currentEpId
        if (epId != null && epId > 0L) return false
        return true
    }

    internal fun parseBangumiSeasonIdFromSource(source: String?): Long? {
        val src = source?.trim().orEmpty()
        if (!src.startsWith("Bangumi:")) return null
        val payload = src.removePrefix("Bangumi:").trim()
        if (payload.isBlank()) return null
        
        return payload.substringBefore(':').trim().toLongOrNull()?.takeIf { it > 0L }
    }

    private fun parseSeasonIdFromPlaylistSource(): Long? {
        return currentSeasonId?.takeIf { it > 0L } ?: parseBangumiSeasonIdFromSource(pageListSource)
    }

    private fun shouldReportWebHeartbeatNow(): Boolean {
        if (!BiliClient.cookies.hasSessData()) return false
        val csrf = BiliClient.cookies.getCookieValue("bili_jct").orEmpty().trim()
        if (csrf.isBlank()) return false
        val cid = currentCid
        if (cid <= 0L) return false
        val hasArchiveId = (currentAid ?: 0L) > 0L || currentBvid.isNotBlank()
        if (!hasArchiveId) return false
        return true
    }

    private fun shouldReportAnyProgressNow(): Boolean {
        return shouldReportHistoryNow() || shouldReportWebHeartbeatNow()
    }

    private fun startReportProgressLoop() {
        if (reportProgressJob != null) return
        if (!shouldReportAnyProgressNow()) return
        val token = reportToken
        reportProgressJob =
            lifecycleScope.launch {
                delay(2_000)
                while (isActive && token == reportToken) {
                    reportProgressOnce(force = false, reason = "loop")
                    delay(15_000)
                }
            }
    }

    internal fun stopReportProgressLoop(flush: Boolean, reason: String) {
        reportProgressJob?.cancel()
        reportProgressJob = null
        if (flush) lifecycleScope.launch { reportProgressOnce(force = true, reason = reason) }
    }

    internal fun requestReportProgressOnce(reason: String) {
        lifecycleScope.launch { reportProgressOnce(force = true, reason = reason) }
    }

    private suspend fun reportProgressOnce(force: Boolean, reason: String) {
        if (!shouldReportAnyProgressNow()) return
        val token = reportToken
        val exo = player ?: return
        
        if (autoResumeHintVisible) {
            trace?.log("report:skip", "autoResumeHint=1 reason=$reason force=${if (force) 1 else 0}")
            return
        }
        val cid = currentCid
        val aid = currentAid
        val epId = currentEpId
        val isPgc = epId != null && epId > 0L
        val heartbeatType = if (isPgc) 4 else 3
        val seasonId = parseSeasonIdFromPlaylistSource()
        val progressSec = (exo.currentPosition.coerceAtLeast(0L) / 1000L)
        if (token != reportToken) return

        val now = SystemClock.elapsedRealtime()
        if (!force) {
            if (now - lastReportAtMs < 14_000L) return
            if (progressSec == lastReportedProgressSec) return
        }

        val shouldHistory = shouldReportHistoryNow()
        val shouldHeartbeat = shouldReportWebHeartbeatNow()
        var anyOk = false

        if (shouldHistory && aid != null) {
            runCatching {
                BiliApi.historyReport(aid = aid, cid = cid, progressSec = progressSec, platform = "android")
            }.onSuccess {
                anyOk = true
                trace?.log("report:history", "ok=1 sec=$progressSec reason=$reason")
            }.onFailure {
                trace?.log("report:history", "ok=0 sec=$progressSec reason=$reason")
            }
        }

        if (shouldHeartbeat) {
            runCatching {
                BiliApi.webHeartbeat(
                    aid = aid,
                    bvid = currentBvid,
                    cid = cid,
                    epId = epId.takeIf { isPgc },
                    seasonId = seasonId.takeIf { isPgc },
                    playedTimeSec = progressSec,
                    type = heartbeatType,
                    playType = 0,
                )
            }.onSuccess {
                anyOk = true
                trace?.log("report:heartbeat", "ok=1 sec=$progressSec type=$heartbeatType reason=$reason")
            }.onFailure {
                trace?.log("report:heartbeat", "ok=0 sec=$progressSec type=$heartbeatType reason=$reason")
            }
        }

        if (anyOk) {
            lastReportAtMs = now
            lastReportedProgressSec = progressSec
        }
    }

    internal fun updateDanmakuButton() {
        binding.btnDanmaku.imageTintList = null
        binding.btnDanmaku.isSelected = session.danmaku.enabled
    }

    internal fun setDanmakuEnabled(enabled: Boolean) {
        applyDanmakuEnabledSetting(enabled)
    }

    internal fun updateSubtitleButton() {
        if (!subtitleAvailabilityKnown) {
            binding.btnSubtitle.isEnabled = true
            binding.btnSubtitle.alpha = 1.0f
            binding.btnSubtitle.imageTintList =
                ContextCompat.getColorStateList(this, blbl.cat3399.R.color.player_button_tint)
            return
        }
        if (!subtitleAvailable) {
            binding.btnSubtitle.isEnabled = false
            binding.btnSubtitle.alpha = 0.35f
            binding.btnSubtitle.imageTintList =
                ContextCompat.getColorStateList(this, blbl.cat3399.R.color.player_button_tint)
            return
        }

        binding.btnSubtitle.isEnabled = true
        binding.btnSubtitle.alpha = 1.0f
        val colorRes =
            if (session.subtitleEnabled) {
                blbl.cat3399.R.color.blbl_blue
            } else {
                blbl.cat3399.R.color.player_button_tint
            }
        binding.btnSubtitle.imageTintList = ContextCompat.getColorStateList(this, colorRes)
    }

    internal fun toggleSubtitles(exo: ExoPlayer) {
        if (!subtitleAvailabilityKnown) {
            loadAndEnableSubtitlesOnDemand(exo)
            return
        }
        if (!subtitleAvailable) {
            AppToast.show(this, "该视频暂无字幕")
            return
        }
        applySubtitleEnabledSetting(!session.subtitleEnabled, exo)
    }

    internal fun loadAndEnableSubtitlesOnDemand(exo: ExoPlayer) {
        if (subtitleLoadJob?.isActive == true) {
            AppToast.show(this, "字幕加载中")
            return
        }
        val detail = currentVideoDetail
        val bvid = currentBvid.trim()
        val cid = currentCid
        if (detail == null || bvid.isBlank() || cid <= 0L) {
            AppToast.show(this, "字幕信息暂不可用")
            return
        }
        AppToast.show(this, "正在加载字幕")
        startSubtitleLoad(
            detail = detail,
            bvid = bvid,
            cid = cid,
            expectedPlaybackToken = autoResumeToken,
            enableWhenLoaded = true,
            persistEnable = true,
            showUnavailableToast = true,
            reason = "manual",
            exo = exo,
        )
    }

    internal fun startSubtitleLoad(
        detail: VideoDetail,
        bvid: String,
        cid: Long,
        expectedPlaybackToken: Int,
        enableWhenLoaded: Boolean,
        persistEnable: Boolean,
        showUnavailableToast: Boolean,
        reason: String,
        exo: ExoPlayer? = null,
    ) {
        if (subtitleLoadJob?.isActive == true) {
            trace?.log("subtitle:load:skip", "reason=already_running")
            return
        }
        subtitleLoadJob =
            lifecycleScope.launch {
                try {
                    trace?.log("subtitle:load:start", "reason=$reason")
                    val config =
                        withContext(Dispatchers.IO) {
                            prepareSubtitleConfig(detail, bvid, cid, currentAid, trace)
                        }
                    if (expectedPlaybackToken != autoResumeToken || currentBvid != bvid || currentCid != cid) {
                        trace?.log("subtitle:load:skip", "reason=stale")
                        return@launch
                    }
                    subtitleConfig = config
                    subtitleAvailabilityKnown = true
                    subtitleAvailable = config != null
                    trace?.log("subtitle:load:done", "reason=$reason ok=${config != null}")
                    updateSubtitleButton()
                    (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.let { refreshSettings(it) }
                    if (config == null) {
                        if (showUnavailableToast) AppToast.show(this@PlayerActivity, "该视频暂无字幕")
                        return@launch
                    }

                    val activeExo = exo ?: (player as? ExoPlayerEngine)?.exoPlayer
                    if (activeExo == null) return@launch
                    if (enableWhenLoaded) {
                        if (persistEnable) {
                            applySubtitleEnabledSetting(true, activeExo)
                        } else {
                            applySubtitleEnabled(activeExo)
                            updateSubtitleButton()
                            (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.let { refreshSettings(it) }
                        }
                        reloadStream(keepPosition = true)
                    } else {
                        applySubtitleEnabled(activeExo)
                    }
                } catch (throwable: Throwable) {
                    if (throwable is CancellationException) throw throwable
                    trace?.log("subtitle:load:done", "reason=$reason ok=false")
                    AppLog.w("Player", "load subtitle failed reason=$reason bvid=$bvid cid=$cid", throwable)
                    if (showUnavailableToast) AppToast.show(this@PlayerActivity, "字幕加载失败")
                }
            }
    }

    internal fun applySubtitleEnabled(exo: ExoPlayer) {
        val disable = (!subtitleAvailable) || (!session.subtitleEnabled)
        exo.trackSelectionParameters =
            exo.trackSelectionParameters
                .buildUpon()
                .setTrackTypeDisabled(C.TRACK_TYPE_TEXT, disable)
                .build()
    }

    private fun Playable.Dash.shouldAttemptDolbyFallback(): Boolean =
        isDolbyVision || audioKind == DashAudioKind.DOLBY || audioKind == DashAudioKind.FLAC

    private fun nextPlaybackConstraintsForDolbyFallback(picked: Playable.Dash): PlaybackConstraints? {
        if (picked.audioKind == DashAudioKind.FLAC && playbackConstraints.allowFlacAudio) return playbackConstraints.copy(allowFlacAudio = false)
        if (picked.audioKind == DashAudioKind.DOLBY && playbackConstraints.allowDolbyAudio) return playbackConstraints.copy(allowDolbyAudio = false)
        if (picked.isDolbyVision && playbackConstraints.allowDolbyVision) return playbackConstraints.copy(allowDolbyVision = false)
        return null
    }

    private fun shouldAttemptHighSpecFallback(error: PlaybackException): Boolean {
        return when (error.errorCode) {
            PlaybackException.ERROR_CODE_FAILED_RUNTIME_CHECK,
            PlaybackException.ERROR_CODE_NOT_SUPPORTED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_MALFORMED,
            PlaybackException.ERROR_CODE_PARSING_CONTAINER_UNSUPPORTED,
            PlaybackException.ERROR_CODE_DECODER_INIT_FAILED,
            PlaybackException.ERROR_CODE_DECODER_QUERY_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FAILED,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_EXCEEDS_CAPABILITIES,
            PlaybackException.ERROR_CODE_DECODING_FORMAT_UNSUPPORTED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_WRITE_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_OFFLOAD_INIT_FAILED,
            PlaybackException.ERROR_CODE_AUDIO_TRACK_OFFLOAD_WRITE_FAILED,
            -> true

            else -> {
                val name = error.errorCodeName.uppercase(Locale.US)
                name.contains("FAILED_RUNTIME_CHECK") ||
                    name.contains("DECOD") ||
                    name.contains("DECODER") ||
                    name.contains("FORMAT") ||
                    name.contains("AUDIO_TRACK") ||
                    name.contains("NOT_SUPPORTED") ||
                    name.contains("PARSING")
            }
        }
    }

    private fun maybeReloadExpiredUrlAfterResume(error: PlaybackException, httpCode: Int?): Boolean {
        if (!resumeExpiredUrlReloadArmed) return false
        if (resumeExpiredUrlReloadAttempted) return false
        if (!isLikelyExpiredUrlError(error, httpCode)) return false
        resumeExpiredUrlReloadAttempted = true
        resumeExpiredUrlReloadArmed = false
        trace?.log("exo:resumeReload", "http=${httpCode ?: -1} type=${error.errorCodeName}")
        AppToast.show(this@PlayerActivity, "播放地址已过期，正在刷新…")
        reloadStream(keepPosition = true, resetConstraints = false, autoPlay = false)
        return true
    }

    private fun isLikelyExpiredUrlError(error: PlaybackException, httpCode: Int?): Boolean {
        if (httpCode != null && httpCode in setOf(403, 404, 410)) return true
        if (error.errorCode != PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS) return false
        val msg = (error.cause?.message ?: error.message ?: "").lowercase(Locale.US)
        return msg.contains("403") || msg.contains("404") || msg.contains("410") || msg.contains("forbidden")
    }

    internal fun cancelPlayUrlAutoRefresh(reason: String) {
        
        
        if (Thread.currentThread() !== Looper.getMainLooper().thread) {
            lifecycleScope.launch(Dispatchers.Main.immediate) {
                cancelPlayUrlAutoRefresh(reason = reason)
            }
            return
        }
        playUrlAutoRefreshJob?.cancel()
        playUrlAutoRefreshJob = null
        playUrlAutoRefreshToken++
        trace?.log("playurl:autoRefresh:cancel", "reason=$reason")
    }

    internal fun schedulePlayUrlAutoRefresh(playable: Playable, reason: String) {
        
        
        if (Thread.currentThread() !== Looper.getMainLooper().thread) {
            lifecycleScope.launch(Dispatchers.Main.immediate) {
                schedulePlayUrlAutoRefresh(playable = playable, reason = reason)
            }
            return
        }
        if (exitCleanupRequested || isFinishing || isDestroyed) return
        val exo = player ?: return

        playUrlAutoRefreshJob?.cancel()
        playUrlAutoRefreshJob = null

        val nowWallMs = System.currentTimeMillis()
        val deadlineEpochSec = pickEarliestDeadlineEpochSec(playable)

        val delayMs =
            if (deadlineEpochSec != null && deadlineEpochSec > 0L) {
                val deadlineWallMs = deadlineEpochSec * 1000L
                val refreshWallMs = deadlineWallMs - PLAYURL_AUTO_REFRESH_LEAD_MS
                (refreshWallMs - nowWallMs).coerceAtLeast(0L)
            } else {
                val durationMs = currentViewDurationMs
                if (durationMs != null && durationMs >= PLAYURL_AUTO_REFRESH_FALLBACK_MIN_DURATION_MS) {
                    PLAYURL_AUTO_REFRESH_FALLBACK_DELAY_MS
                } else {
                    trace?.log(
                        "playurl:autoRefresh:skip",
                        "reason=$reason deadline=none duration=${durationMs ?: -1}ms",
                    )
                    return
                }
            }

        val token = ++playUrlAutoRefreshToken
        val bvid = currentBvid
        val cid = currentCid
        val posMs = exo.currentPosition.coerceAtLeast(0L)
        trace?.log(
            "playurl:autoRefresh:schedule",
            "reason=$reason token=$token delay=${delayMs}ms pos=${posMs}ms deadline=${deadlineEpochSec ?: -1}",
        )

        playUrlAutoRefreshJob =
            lifecycleScope.launch(Dispatchers.Main.immediate) {
                delay(delayMs)
                if (token != playUrlAutoRefreshToken) return@launch
                val exo2 = player ?: return@launch
                if (exitCleanupRequested || isFinishing || isDestroyed) return@launch
                if (currentBvid != bvid || currentCid != cid) return@launch

                val nowElapsed = SystemClock.elapsedRealtime()
                if (nowElapsed - playUrlAutoRefreshLastReloadAtElapsedMs < PLAYURL_AUTO_REFRESH_MIN_RELOAD_INTERVAL_MS) {
                    trace?.log("playurl:autoRefresh:skip", "throttle=1 token=$token")
                    return@launch
                }
                if (exo2.playbackState == Player.STATE_ENDED && !exo2.playWhenReady) {
                    trace?.log("playurl:autoRefresh:skip", "ended=1 token=$token")
                    return@launch
                }

                playUrlAutoRefreshLastReloadAtElapsedMs = nowElapsed
                trace?.log(
                    "playurl:autoRefresh:reload",
                    "token=$token pos=${exo2.currentPosition.coerceAtLeast(0L)}ms",
                )
                reloadStream(
                    keepPosition = true,
                    resetConstraints = false,
                    autoPlay = exo2.playWhenReady,
                )
            }
    }

    private fun pickEarliestDeadlineEpochSec(playable: Playable): Long? {
        fun parseDeadlineEpochSec(url: String): Long? {
            val uri = runCatching { Uri.parse(url) }.getOrNull() ?: return null
            val raw =
                uri.getQueryParameter("deadline")
                    ?: uri.getQueryParameter("expires")
                    ?: return null
            return raw.toLongOrNull()
        }

        fun earliestDeadlineEpochSec(urls: List<String>): Long? {
            var best: Long? = null
            for (u in urls) {
                val sec = parseDeadlineEpochSec(u.trim()) ?: continue
                if (sec <= 0L) continue
                best = if (best == null) sec else minOf(best, sec)
            }
            return best
        }

        fun minNonNull(a: Long?, b: Long?): Long? =
            when {
                a == null -> b
                b == null -> a
                else -> minOf(a, b)
            }

        return when (playable) {
            is Playable.Dash -> {
                val video = earliestDeadlineEpochSec(playable.videoUrlCandidates.ifEmpty { listOf(playable.videoUrl) })
                val audio = earliestDeadlineEpochSec(playable.audioUrlCandidates.ifEmpty { listOf(playable.audioUrl) })
                minNonNull(video, audio)
            }
            is Playable.VideoOnly -> earliestDeadlineEpochSec(playable.videoUrlCandidates.ifEmpty { listOf(playable.videoUrl) })
            is Playable.Progressive -> earliestDeadlineEpochSec(playable.urlCandidates.ifEmpty { listOf(playable.url) })
        }
    }

    private fun findHttpResponseCode(t: Throwable?): Int? {
        var cur = t ?: return null
        repeat(12) {
            val code = (cur as? HttpDataSource.InvalidResponseCodeException)?.responseCode
            if (code != null) return code
            cur = cur.cause ?: return null
        }
        return null
    }

    private fun effectiveTargetQnForLog(): Int = session.targetQn.takeIf { it > 0 } ?: session.preferredQn

    private fun effectiveTargetAudioIdForLog(): Int = session.targetAudioId.takeIf { it > 0 } ?: session.preferAudioId

    private fun selectCdnUrls(urls: List<String>, preference: String): List<String> {
        val candidates = urls.map { it.trim() }.filter { it.isNotBlank() }.distinct()
        if (candidates.isEmpty()) return emptyList()

        fun hostOf(url: String): String =
            runCatching { Uri.parse(url).host.orEmpty() }.getOrDefault("").lowercase(Locale.US)

        fun isMcdn(url: String): Boolean {
            val host = hostOf(url)
            return host.contains("mcdn") && host.contains("bilivideo")
        }

        fun isBilivideo(url: String): Boolean {
            val host = hostOf(url)
            return host.contains("bilivideo") && !isMcdn(url)
        }

        val preferred =
            when (preference) {
                AppPrefs.PLAYER_CDN_MCDN -> candidates.filter(::isMcdn)
                AppPrefs.PLAYER_CDN_BILIVIDEO -> candidates.filter(::isBilivideo)
                else -> emptyList()
            }
        if (preferred.isEmpty()) return candidates
        val rest = candidates.filterNot { preferred.contains(it) }
        return preferred + rest
    }

    private fun dashTrackInfoOf(info: VideoTrackInfo): DashTrackInfo =
        DashTrackInfo(
            mimeType = info.mimeType,
            codecs = info.codecs,
            bandwidth = info.bandwidth,
            width = info.width,
            height = info.height,
            frameRate = info.frameRate,
            segmentBase =
                info.segmentBase?.let { segment ->
                    DashSegmentBase(
                        initialization = segment.initialization,
                        indexRange = segment.indexRange,
                    )
                },
        )

    private fun dashAudioKindOf(kind: VideoAudioKind): DashAudioKind =
        when (kind) {
            VideoAudioKind.NORMAL -> DashAudioKind.NORMAL
            VideoAudioKind.DOLBY -> DashAudioKind.DOLBY
            VideoAudioKind.FLAC -> DashAudioKind.FLAC
        }

    private data class ProgressivePlayableCandidate(
        val urlCandidates: List<String>,
        val mediaRequestProfile: VideoMediaRequestProfile,
    )

    private fun firstProgressiveCandidate(stream: VideoPlayStream): ProgressivePlayableCandidate? {
        for (progressive in stream.progressive) {
            val candidates = selectCdnUrls(progressive.urls, preference = BiliClient.prefs.playerCdnPreference)
            if (candidates.isNotEmpty()) {
                return ProgressivePlayableCandidate(
                    urlCandidates = candidates,
                    mediaRequestProfile = progressive.mediaRequestProfile,
                )
            }
        }
        return null
    }

    private suspend fun pickPlayable(stream: VideoPlayStream, constraints: PlaybackConstraints): Playable {
        stream.vVoucher?.let { recordVVoucher(it) }
        val dash = stream.dash
        var dashVideoMetaForFallback: Playable.VideoOnly? = null
        if (dash != null) {
            val preferCodecid = when (session.preferCodec) {
                "HEVC" -> 12
                "AV1" -> 13
                else -> 7
            }

            val rawVideoItems = dash.videos.filter { it.urls.isNotEmpty() && it.qn > 0 }

            val videoItems =
                rawVideoItems.filterNot { v ->
                    v.isDolbyVision && !constraints.allowDolbyVision
                }

            val rawQns = rawVideoItems.map { it.qn }.filter { it > 0 }.distinct()
            val availableQns = videoItems.map { it.qn }.filter { it > 0 }.distinct()

            val desiredQn = session.targetQn.takeIf { it > 0 } ?: session.preferredQn
            val pickedQn = pickQnByQualityOrder(availableQns, desiredQn)

            val candidatesByQn = if (pickedQn > 0) videoItems.filter { it.qn == pickedQn } else videoItems
            val candidates =
                when {
                    candidatesByQn.isNotEmpty() -> candidatesByQn
                    videoItems.isNotEmpty() -> {
                        if (pickedQn > 0) {
                            AppLog.w("Player", "wanted qn=$pickedQn but no DASH track matched; fallback to best available")
                        }
                        videoItems
                    }
                    else -> emptyList()
                }

            var bestVideo: VideoTrack? = null
            var bestScore = -1L
            for (v in candidates) {
                val codecid = v.codecid
                val qn = v.qn
                val bandwidth = v.info.bandwidth ?: 0L
                val okCodec = (codecid == preferCodecid)
                val score =
                    (qnRank(qn).toLong() * 1_000_000_000_000L) +
                        bandwidth +
                        (if (okCodec) 10_000_000_000L else 0L)
                if (score > bestScore) {
                    bestScore = score
                    bestVideo = v
                }
            }
            val picked = bestVideo
            if (picked == null) {
                AppLog.w("Player", "no DASH video track picked; fallback to durl if possible")
            } else {
                val videoUrlCandidates = selectCdnUrls(picked.urls, preference = BiliClient.prefs.playerCdnPreference)
                val videoUrl = videoUrlCandidates.firstOrNull().orEmpty()
                val pickedQnFinal = picked.qn
                val pickedCodecid = picked.codecid
                val pickedIsDolbyVision = picked.isDolbyVision
                dashVideoMetaForFallback =
                    Playable.VideoOnly(
                        videoUrl = videoUrl,
                        videoUrlCandidates = videoUrlCandidates,
                        videoMediaRequestProfile = picked.mediaRequestProfile,
                        qn = pickedQnFinal,
                        codecid = pickedCodecid,
                        isDolbyVision = pickedIsDolbyVision,
                    )

                data class AudioCandidate(val track: AudioTrack, val kind: DashAudioKind, val id: Int, val bandwidth: Long)

                val rawAudioCandidates = buildList<AudioCandidate> {
                    for (audio in dash.audios) {
                        if (audio.urls.isEmpty()) continue
                        add(
                            AudioCandidate(
                                track = audio,
                                kind = dashAudioKindOf(audio.kind),
                                id = audio.id,
                                bandwidth = audio.info.bandwidth ?: 0L,
                            ),
                        )
                    }
                }

                val allAudioCandidates =
                    rawAudioCandidates.filterNot { candidate ->
                        (candidate.kind == DashAudioKind.DOLBY && !constraints.allowDolbyAudio) ||
                            (candidate.kind == DashAudioKind.FLAC && !constraints.allowFlacAudio)
                    }

                val desiredAudioId = session.targetAudioId.takeIf { it > 0 } ?: session.preferAudioId
                val rawAudioIds = rawAudioCandidates.map { it.id }.filter { it > 0 }.distinct()
                val availableAudioIds = allAudioCandidates.map { it.id }.filter { it > 0 }.distinct()
                AppLog.i(
                    "Player",
                    "pickPlayable targetQn=$desiredQn targetAudioId=$desiredAudioId constraints=$constraints " +
                        "rawQns=$rawQns selectableQns=$availableQns rawAudioIds=$rawAudioIds selectableAudioIds=$availableAudioIds",
                )
                val pickedAudioId = pickAudioIdByPreference(allAudioCandidates.map { it.id }, desiredAudioId)
                if (pickedAudioId > 0 && pickedAudioId != desiredAudioId) {
                    AppLog.w("Player", "wanted audioId=$desiredAudioId but fallback to audioId=$pickedAudioId")
                }
                val audioPool =
                    if (pickedAudioId > 0) {
                        allAudioCandidates.filter { it.id == pickedAudioId }
                    } else {
                        allAudioCandidates
                    }

                val audioPicked =
                    audioPool.maxByOrNull { it.bandwidth }
                        ?: allAudioCandidates.maxWithOrNull(
                    compareBy<AudioCandidate> { it.bandwidth }.thenBy { if (it.id == desiredAudioId) 1 else 0 },
                        )
                if (audioPicked == null) {
                    AppLog.w("Player", "no DASH audio track picked; fallback to durl if possible (or video-only if durl missing)")
                } else {
                    val audioUrlCandidates = selectCdnUrls(audioPicked.track.urls, preference = BiliClient.prefs.playerCdnPreference)
                    val audioUrl = audioUrlCandidates.firstOrNull().orEmpty()
                    val videoTrackInfo = dashTrackInfoOf(picked.info)
                    val audioTrackInfo = dashTrackInfoOf(audioPicked.track.info)
                    val orderedVideoItems = listOf(picked) + videoItems.filterNot { it == picked }
                    val videoRepresentations =
                        orderedVideoItems.mapNotNull { video ->
                            val representationUrls = selectCdnUrls(video.urls, preference = BiliClient.prefs.playerCdnPreference)
                            val primaryUrl = representationUrls.firstOrNull() ?: return@mapNotNull null
                            Playable.DashVideoRepresentation(
                                videoUrl = primaryUrl,
                                videoUrlCandidates = representationUrls,
                                videoMediaRequestProfile = video.mediaRequestProfile,
                                videoTrackInfo = dashTrackInfoOf(video.info),
                                qn = video.qn,
                                codecid = video.codecid,
                                isDolbyVision = video.isDolbyVision,
                            )
                        }
                    val playable = Playable.Dash(
                        videoUrl = videoUrl,
                        audioUrl = audioUrl,
                        videoUrlCandidates = videoUrlCandidates,
                        audioUrlCandidates = audioUrlCandidates,
                        videoMediaRequestProfile = picked.mediaRequestProfile,
                        audioMediaRequestProfile = audioPicked.track.mediaRequestProfile,
                        videoTrackInfo = videoTrackInfo,
                        audioTrackInfo = audioTrackInfo,
                        qn = pickedQnFinal,
                        codecid = pickedCodecid,
                        audioId = audioPicked.id,
                        audioKind = audioPicked.kind,
                        isDolbyVision = pickedIsDolbyVision,
                        videoRepresentations = videoRepresentations,
                    )
                    return if (session.seamlessQualitySwitchEnabled) {
                        DashPlaybackCatalogResolver.resolve(playable)
                    } else {
                        playable
                    }
                }
            }
        }

        
        val progressiveCandidate = firstProgressiveCandidate(stream)
        val urlCandidates = progressiveCandidate?.urlCandidates.orEmpty()
        val url = urlCandidates.firstOrNull().orEmpty()
        if (url.isNotBlank()) {
            return Playable.Progressive(
                url = url,
                urlCandidates = urlCandidates,
                mediaRequestProfile = progressiveCandidate?.mediaRequestProfile ?: VideoMediaRequestProfile.WEB,
            )
        }

        val cid = currentCid.takeIf { it > 0 }
            ?: intent.getLongExtra(EXTRA_CID, -1L).takeIf { it > 0 }
            ?: error("cid missing for fallback")
        val bvid = currentBvid.ifBlank { intent.getStringExtra(EXTRA_BVID).orEmpty() }
        
        val fallbackStream =
            requestPlayStream(
                bvid = bvid,
                aid = currentAid,
                cid = cid,
                epId = currentEpId,
                qn = 127,
                fnval = 1,
                tryLook = false,
            )
        fallbackStream.vVoucher?.let { recordVVoucher(it) }
        val fallbackProgressiveCandidate = firstProgressiveCandidate(fallbackStream)
        val fallbackUrlCandidates = fallbackProgressiveCandidate?.urlCandidates.orEmpty()
        val fallbackUrl = fallbackUrlCandidates.firstOrNull().orEmpty()
        if (fallbackUrl.isNotBlank()) {
            return Playable.Progressive(
                url = fallbackUrl,
                urlCandidates = fallbackUrlCandidates,
                mediaRequestProfile = fallbackProgressiveCandidate?.mediaRequestProfile ?: VideoMediaRequestProfile.WEB,
            )
        }

        
        
        val dashVideoOnly = dashVideoMetaForFallback
        if (dashVideoOnly != null && dashVideoOnly.videoUrl.isNotBlank()) {
            return dashVideoOnly
        }

        error("No playable url in playurl response")
    }

    internal fun createCdnFactory(kind: DebugStreamKind, urlCandidates: List<String>? = null): DataSource.Factory {
        val listener =
            object : TransferListener {
                override fun onTransferInitializing(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}

                override fun onTransferStart(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {
                    val host = dataSpec.uri.host?.trim().orEmpty()
                    if (host.isBlank()) return
                    when (kind) {
                        DebugStreamKind.VIDEO -> debug.videoTransferHost = host
                        DebugStreamKind.AUDIO -> debug.audioTransferHost = host
                        DebugStreamKind.MAIN -> debug.videoTransferHost = host
                    }
                }

                override fun onBytesTransferred(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean, bytesTransferred: Int) {}

                override fun onTransferEnd(source: DataSource, dataSpec: DataSpec, isNetwork: Boolean) {}
            }

        val upstream = OkHttpDataSource.Factory(BiliClient.cdnOkHttp).setTransferListener(listener)
        val uris =
            urlCandidates
                .orEmpty()
                .map { it.trim() }
                .filter { it.isNotBlank() }
                .distinct()
                .map { Uri.parse(it) }
        if (uris.size <= 1) return upstream
        return CdnFailoverDataSourceFactory(upstreamFactory = upstream, state = CdnFailoverState(kind = kind, candidates = uris))
    }

    internal fun buildMerged(
        videoFactory: DataSource.Factory,
        audioFactory: DataSource.Factory,
        videoUrl: String,
        audioUrl: String,
        subtitle: MediaItem.SubtitleConfiguration?,
    ): MediaSource {
        val subs = listOfNotNull(subtitle)
        val videoSource =
            DefaultMediaSourceFactory(DefaultDataSource.Factory(this, videoFactory))
                .createMediaSource(
                    MediaItem.Builder().setUri(Uri.parse(videoUrl)).setSubtitleConfigurations(subs).build(),
                )
        val audioSource =
            DefaultMediaSourceFactory(DefaultDataSource.Factory(this, audioFactory))
                .createMediaSource(
                    MediaItem.Builder().setUri(Uri.parse(audioUrl)).build(),
                )
        return MergingMediaSource(videoSource, audioSource)
    }

    internal fun buildProgressive(factory: DataSource.Factory, url: String, subtitle: MediaItem.SubtitleConfiguration?): MediaSource {
        val subs = listOfNotNull(subtitle)
        val item =
            MediaItem.Builder()
                .setUri(Uri.parse(url))
                .setSubtitleConfigurations(subs)
                .build()
        return DefaultMediaSourceFactory(DefaultDataSource.Factory(this, factory)).createMediaSource(item)
    }

    internal fun reloadStream(
        keepPosition: Boolean,
        resetConstraints: Boolean = true,
        autoPlay: Boolean = true,
        reason: String = "unspecified",
    ) {
        
        if (Thread.currentThread() !== Looper.getMainLooper().thread) {
            lifecycleScope.launch(Dispatchers.Main.immediate) {
                reloadStream(keepPosition = keepPosition, resetConstraints = resetConstraints, autoPlay = autoPlay, reason = reason)
            }
            return
        }
        val engine = player ?: return
        val cid = currentCid
        val bvid = currentBvid
        if (cid <= 0 || bvid.isBlank()) return
        val pos = engine.currentPosition
        val reloadStartedAtMs = SystemClock.elapsedRealtime()
        AppLog.i(
            "QualitySwitch",
            "reload start reason=$reason keepPosition=$keepPosition resetConstraints=$resetConstraints autoPlay=$autoPlay " +
                "savedPos=$pos currentQn=${session.actualQn} targetQn=${session.targetQn} seamlessSource=${engine.isSeamlessQualitySource}",
        )
        lifecycleScope.launch {
            try {
                val (qn, fnval) = playUrlParamsForSession()
                if (resetConstraints) {
                    playbackConstraints = PlaybackConstraints()
                    decodeFallbackAttemptCount = 0
                    lastPickedDash = null
                }
                val (playStream, playable) =
                    loadPlayableWithTryLookFallback(
                        bvid = bvid,
                        aid = currentAid,
                        cid = cid,
                        epId = currentEpId,
                        qn = qn,
                        fnval = fnval,
                        constraints = playbackConstraints,
                    )
                val positionBeforeCommit = engine.currentPosition
                AppLog.i(
                    "QualitySwitch",
                    "reload fetched reason=$reason costMs=${SystemClock.elapsedRealtime() - reloadStartedAtMs} " +
                        "savedPos=$pos positionBeforeCommit=$positionBeforeCommit driftMs=${positionBeforeCommit - pos} " +
                        "picked=${playable.javaClass.simpleName} pickedQn=${when (playable) { is Playable.Dash -> playable.qn; is Playable.VideoOnly -> playable.qn; is Playable.Progressive -> -1 }}",
                )
                playStream.durationMs?.let { currentViewDurationMs = it }
                showRiskControlBypassHintIfNeeded(playStream)
                lastAvailableQns = parseDashVideoQnList(playStream)
                lastAvailableAudioIds = parseDashAudioIdList(playStream, constraints = playbackConstraints)
                logPlayUrlTrackSummary(source = "reload", stream = playStream, constraints = playbackConstraints)
                if (engine.kind == PlayerEngineKind.IjkPlayer && playable !is Playable.Dash) {
                    AppToast.showLong(this@PlayerActivity, "IjkPlayer 内核仅支持 DASH（音视频分离）流，请切回 ExoPlayer")
                    return@launch
                }
                when (playable) {
                    is Playable.Dash -> {
                        lastPickedDash = playable
                        debug.cdnHost = runCatching { Uri.parse(playable.videoUrl).host }.getOrNull()
                        logPickedPlayable(source = "reload", playable = playable)
                        engine.setSource(
                            PlaybackSource.Vod(
                                playable = playable,
                                subtitle = subtitleConfig,
                                durationMs = currentViewDurationMs,
                                initialPositionMs = pos.takeIf { keepPosition },
                                seamlessQualitySwitchEnabled = session.seamlessQualitySwitchEnabled && !seamlessQualitySwitchDisabledForPlayback,
                            ),
                        )
                        applyResolutionFallbackIfNeeded(requestedQn = session.targetQn, actualQn = playable.qn)
                        applyAudioFallbackIfNeeded(requestedAudioId = session.targetAudioId, actualAudioId = playable.audioId)
                    }
                    is Playable.VideoOnly -> {
                        lastPickedDash = null
                        session = session.copy(actualAudioId = 0)
                        (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.let { refreshSettings(it) }
                        debug.cdnHost = runCatching { Uri.parse(playable.videoUrl).host }.getOrNull()
                        logPickedPlayable(source = "reload", playable = playable)
                        engine.setSource(
                            PlaybackSource.Vod(
                                playable = playable,
                                subtitle = subtitleConfig,
                                durationMs = currentViewDurationMs,
                                initialPositionMs = pos.takeIf { keepPosition },
                                seamlessQualitySwitchEnabled = session.seamlessQualitySwitchEnabled && !seamlessQualitySwitchDisabledForPlayback,
                            ),
                        )
                        applyResolutionFallbackIfNeeded(requestedQn = session.targetQn, actualQn = playable.qn)
                    }
                    is Playable.Progressive -> {
                        lastPickedDash = null
                        session = session.copy(actualAudioId = 0)
                        (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.let { refreshSettings(it) }
                        debug.cdnHost = runCatching { Uri.parse(playable.url).host }.getOrNull()
                        logPickedPlayable(source = "reload", playable = playable)
                        engine.setSource(
                            PlaybackSource.Vod(
                                playable = playable,
                                subtitle = subtitleConfig,
                                durationMs = currentViewDurationMs,
                                initialPositionMs = pos.takeIf { keepPosition },
                                seamlessQualitySwitchEnabled = session.seamlessQualitySwitchEnabled && !seamlessQualitySwitchDisabledForPlayback,
                            ),
                        )
                    }
                }
                schedulePlayUrlAutoRefresh(playable, reason = "reload_stream")
                AppLog.i(
                    "QualitySwitch",
                    "reload commit reason=$reason seekTarget=${if (keepPosition) pos else -1L} positionBeforePrepare=${engine.currentPosition} " +
                        "seamlessSource=${engine.isSeamlessQualitySource}",
                )
                engine.prepare()
                (engine as? ExoPlayerEngine)?.exoPlayer?.let { applySubtitleEnabled(it) }
                engine.playWhenReady = autoPlay
            } catch (t: Throwable) {
                AppLog.e("Player", "reloadStream failed", t)
                if (!handlePlayUrlErrorIfNeeded(t)) {
                    AppToast.show(this@PlayerActivity, "切换失败：${t.message}")
                }
            }
        }
    }

    internal suspend fun prepareSubtitleConfig(
        detail: VideoDetail,
        bvid: String,
        cid: Long,
        aid: Long?,
        trace: PlaybackTrace?,
    ): MediaItem.SubtitleConfiguration? {
        trace?.log("subtitle:items:start")
        val items = fetchSubtitleItems(detail, bvid, cid, aid, trace)
        trace?.log("subtitle:items:done", "count=${items.size}")
        subtitleItems = items
        val chosen = pickSubtitleItem(items) ?: return null
        trace?.log("subtitle:download:start", "lan=${chosen.lan}")
        return buildSubtitleConfigFromItem(chosen, bvid, cid, trace)
    }

    private suspend fun buildSubtitleConfigFromItem(
        item: SubtitleItem,
        bvid: String,
        cid: Long,
        trace: PlaybackTrace? = null,
    ): MediaItem.SubtitleConfiguration? {
        val subtitleJson = runCatching { BiliClient.getJson(item.url) }.getOrNull() ?: return null
        val body = subtitleJson.optJSONArray("body") ?: subtitleJson.optJSONObject("data")?.optJSONArray("body") ?: return null

        val vtt = buildWebVtt(body)
        if (vtt.isBlank()) return null

        val safeLan = item.lan.replace(Regex("[^a-zA-Z0-9_-]"), "_")
        val file = File(cacheDir, "sub_${bvid}_${cid}_${safeLan}.vtt")
        runCatching { file.writeText(vtt, Charsets.UTF_8) }.getOrElse { return null }
        trace?.log("subtitle:download:done", "vttBytes=${vtt.toByteArray(Charsets.UTF_8).size}")

        return MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(file))
            .setMimeType(MimeTypes.TEXT_VTT)
            .setLanguage(item.lan)
            .setSelectionFlags(C.SELECTION_FLAG_DEFAULT)
            .build()
    }

    private suspend fun fetchSubtitleItems(
        detail: VideoDetail,
        bvid: String,
        cid: Long,
        aid: Long?,
        trace: PlaybackTrace?,
    ): List<SubtitleItem> {
        trace?.log("subtitle:videoPlayerInfo:start")
        val playerInfo = runCatching { BiliApi.videoPlayerInfo(bvid = bvid, cid = cid) }.getOrNull()
        trace?.log("subtitle:videoPlayerInfo:done", "ok=${playerInfo != null}")
        val playerSubtitles = playerInfo?.subtitles.orEmpty()
        if (playerSubtitles.isEmpty()) {
            val safeAid = aid?.takeIf { it > 0L } ?: detail.aid?.takeIf { it > 0L }
            if (safeAid != null) {
                trace?.log("subtitle:dmView:start", "aid=$safeAid cid=$cid")
                val dmSubtitles =
                    runCatching { BiliApi.dmViewSubtitles(aid = safeAid, cid = cid) }
                        .onFailure { AppLog.w("Player", "dmView subtitle failed aid=$safeAid cid=$cid", it) }
                        .getOrDefault(emptyList())
                trace?.log("subtitle:dmView:done", "count=${dmSubtitles.size}")
                if (dmSubtitles.isNotEmpty()) {
                    return dmSubtitles.map { subtitle ->
                        SubtitleItem(
                            lan = subtitle.language.ifBlank { "unknown" },
                            lanDoc = subtitle.languageDoc.ifBlank { subtitle.language },
                            url = normalizeUrl(subtitle.url),
                        )
                    }
                }
            }
            
            if (detail.subtitles.isEmpty()) return emptyList()
            return detail.subtitles.map { subtitle ->
                SubtitleItem(
                    lan = subtitle.language.ifBlank { "unknown" },
                    lanDoc = subtitle.languageDoc.ifBlank { subtitle.language },
                    url = normalizeUrl(subtitle.url),
                )
            }
        }
        return playerSubtitles.mapNotNull { subtitle ->
            val url = subtitle.url.trim()
            val lan = subtitle.language.trim()
            if (url.isBlank() || lan.isBlank()) return@mapNotNull null
            SubtitleItem(lan = lan, lanDoc = subtitle.languageDoc.ifBlank { lan }, url = normalizeUrl(url))
        }
    }

    internal suspend fun buildSubtitleConfigFromCurrentSelection(bvid: String, cid: Long): MediaItem.SubtitleConfiguration? {
        if (bvid.isBlank() || cid <= 0) return null
        val chosen = pickSubtitleItem(subtitleItems) ?: return null
        return buildSubtitleConfigFromItem(chosen, bvid, cid)
    }

    internal data class DanmakuMeta(
        val shield: DanmakuShield,
        val segmentTotal: Int,
        val segmentSizeMs: Int,
    )

    internal suspend fun prepareDanmakuMeta(cid: Long, aid: Long?, trace: PlaybackTrace? = null): DanmakuMeta {
        trace?.log("danmakuMeta:prepare:start", "cid=$cid aid=${aid ?: -1}")
        val danmakuSession = session.danmaku
        return withContext(Dispatchers.IO) {
            val followBili = danmakuSession.followBiliShield
            val hasSess = BiliClient.cookies.hasSessData()
            if (session.debugEnabled) {
                AppLog.d("Player", "danmakuMeta cid=$cid aid=${aid ?: -1} followBili=$followBili hasSess=$hasSess")
            }
            val dmView = if (followBili && hasSess) {
                val t0 = SystemClock.elapsedRealtime()
                runCatching { BiliApi.dmWebView(cid, aid) }
                    .onFailure { AppLog.w("Player", "dmWebView failed", it) }
                    .getOrNull()
                    .also {
                        val cost = SystemClock.elapsedRealtime() - t0
                        trace?.log("danmakuMeta:dmWebView", "ok=${it != null} cost=${cost}ms")
                    }
            } else {
                null
            }
            val userFilter = if (followBili && hasSess) {
                val t0 = SystemClock.elapsedRealtime()
                runCatching { BiliApi.dmFilterUser() }
                    .onFailure { AppLog.w("Player", "dmFilterUser failed", it) }
                    .getOrNull()
                    .also {
                        val cost = SystemClock.elapsedRealtime() - t0
                        val kw = it?.keywords?.size ?: 0
                        val re = it?.regexes?.size ?: 0
                        val user = it?.blockedUserMidHashes?.size ?: 0
                        trace?.log("danmakuMeta:dmFilterUser", "ok=${it != null} kw=$kw re=$re user=$user cost=${cost}ms")
                    }
            } else {
                null
            }
            val setting = dmView?.setting
            val shield = DanmakuShield(
                allowScroll = danmakuSession.allowScroll && (setting?.allowScroll ?: true),
                allowTop = danmakuSession.allowTop && (setting?.allowTop ?: true),
                allowBottom = danmakuSession.allowBottom && (setting?.allowBottom ?: true),
                allowColor = danmakuSession.allowColor && (setting?.allowColor ?: true),
                allowSpecial = danmakuSession.allowSpecial && (setting?.allowSpecial ?: true),
                aiEnabled = danmakuSession.aiShieldEnabled || (setting?.aiEnabled ?: false),
                aiLevel = maxOf(danmakuSession.aiShieldLevel, setting?.aiLevel ?: 0),
                keywords = userFilter?.keywords.orEmpty(),
                regexes = userFilter?.regexes.orEmpty(),
                blockedUserMidHashes = userFilter?.blockedUserMidHashes.orEmpty(),
            )
            val segmentTotal = dmView?.segmentTotal?.takeIf { it > 0 } ?: 0
            val segmentSizeMs = dmView?.segmentPageSizeMs?.takeIf { it > 0 }?.toInt() ?: DANMAKU_DEFAULT_SEGMENT_MS
            AppLog.i(
                "Player",
                "danmaku cid=$cid segTotal=$segmentTotal segSizeMs=$segmentSizeMs followBili=$followBili hasSess=$hasSess hasDmSetting=${setting != null} filters=kw${userFilter?.keywords?.size ?: 0},re${userFilter?.regexes?.size ?: 0},user${userFilter?.blockedUserMidHashes?.size ?: 0}",
            )
            DanmakuMeta(
                shield = shield,
                segmentTotal = segmentTotal,
                segmentSizeMs = segmentSizeMs,
            ).also {
                trace?.log("danmakuMeta:prepare:done")
            }
        }
    }

    internal fun applyDanmakuMeta(meta: DanmakuMeta) {
        cancelDanmakuLoading(reason = "meta_update")
        danmakuShield = meta.shield
        danmakuSegmentTotal = meta.segmentTotal
        danmakuSegmentSizeMs = meta.segmentSizeMs.coerceAtLeast(1)
        danmakuLoadedSegments.clear()
        danmakuSegmentItems.clear()
    }

    internal fun reloadDanmakuForCurrentSession() {
        val positionMs = player?.currentPosition?.coerceAtLeast(0L) ?: 0L
        val cid = currentCid.takeIf { it > 0L }
        if (cid == null) {
            cancelDanmakuLoading(reason = "settings_change_no_cid")
            danmakuShield = null
            danmakuLoadedSegments.clear()
            danmakuSegmentItems.clear()
            binding.danmakuView.setDanmakus(emptyList())
            binding.danmakuView.notifySeek(positionMs)
            return
        }

        lifecycleScope.launch {
            runCatching {
                val meta = prepareDanmakuMeta(cid = cid, aid = currentAid)
                applyDanmakuMeta(meta)
                binding.danmakuView.setDanmakus(emptyList())
                binding.danmakuView.notifySeek(positionMs)
                requestDanmakuSegmentsForPosition(positionMs, immediate = true)
            }.onFailure { throwable ->
                if (throwable is CancellationException) throw throwable
                AppLog.w("Player", "reloadDanmakuForCurrentSession failed", throwable)
            }
        }
    }

    internal fun requestDanmakuSegmentsForPosition(positionMs: Long, immediate: Boolean) {
        val debug = session.debugEnabled
        if (danmakuShield == null) {
            if (debug) AppLog.d("Player", "danmaku prefetch skipped: shield=null")
            return
        }
        if (!session.danmaku.enabled) {
            if (debug) AppLog.d("Player", "danmaku prefetch skipped: disabled")
            return
        }
        val now = SystemClock.uptimeMillis()
        if (!immediate && now - lastDanmakuPrefetchAtMs < DANMAKU_PREFETCH_INTERVAL_MS) {

            return
        }
        lastDanmakuPrefetchAtMs = now

        val cid = currentCid.takeIf { it > 0 } ?: return
        val segSize = danmakuSegmentSizeMs.coerceAtLeast(1)
        val targetSeg = (positionMs / segSize).toInt() + 1
        if (targetSeg <= 0) return

        val toLoad = buildList {
            add(targetSeg)
            for (i in 1..DANMAKU_PREFETCH_SEGMENTS) add(targetSeg + i)
        }.filter { canLoadSegment(it) }

        if (toLoad.isEmpty()) return

        if (debug) {
            AppLog.d(
                "Player",
                "danmaku prefetch cid=$cid pos=${positionMs}ms segSizeMs=$segSize targetSeg=$targetSeg toLoad=${toLoad.joinToString()} segTotal=$danmakuSegmentTotal",
            )
        }

        val loadGeneration = danmakuLoadGeneration
        val requestPositionMs = positionMs
        val requestCid = cid
        val requestSegments = toLoad.toList()
        val debugEnabled = debug

        danmakuLoadJob?.cancel()
        danmakuLoadJob =
            lifecycleScope.launch(Dispatchers.IO) {
                val shield = danmakuShield
                val loadedSegmentItems = LinkedHashMap<Int, List<blbl.cat3399.core.model.Danmaku>>()
                val loaded = ArrayList<Int>(requestSegments.size)
                try {
                    for (seg in requestSegments) {
                        val t0 = SystemClock.elapsedRealtime()
                        val list = runCatching { BiliApi.dmSeg(requestCid, seg) }.getOrNull()
                        val cost = SystemClock.elapsedRealtime() - t0
                        if (list == null) {
                            if (debugEnabled) AppLog.d("Player", "danmaku seg=$seg fetch failed cost=${cost}ms")
                            continue
                        }
                        val before = list.size
                        val filtered = if (shield != null) list.filter(shield::allow) else list
                        val sorted = if (filtered.size <= 1) filtered else filtered.sortedBy { it.timeMs }
                        val after = sorted.size
                        if (debugEnabled) {
                            val minMs = sorted.firstOrNull()?.timeMs ?: -1
                            val maxMs = sorted.lastOrNull()?.timeMs ?: -1
                            AppLog.d(
                                "Player",
                                "danmaku seg=$seg items=$before kept=$after range=${minMs}..${maxMs}ms pos=${requestPositionMs}ms cost=${cost}ms",
                            )
                        }
                        if (before > 0 && after == 0 && debugEnabled) {
                            AppLog.d("Player", "danmaku seg=$seg filteredAll (shield)")
                        }
                        loadedSegmentItems[seg] = sorted
                        loaded.add(seg)
                    }
                } finally {
                    withContext(NonCancellable + Dispatchers.Main) {
                        if (loadGeneration != danmakuLoadGeneration || currentCid != requestCid) {
                            danmakuLoadingSegments.removeAll(requestSegments)
                            return@withContext
                        }
                        danmakuLoadingSegments.removeAll(requestSegments)
                        danmakuLoadedSegments.addAll(loaded)
                        if (loaded.isEmpty()) return@withContext

                        var appendedAny = false
                        for ((seg, items) in loadedSegmentItems) {
                            danmakuSegmentItems[seg] = items
                            if (items.isEmpty()) continue
                            if (debugEnabled) {
                                AppLog.d("Player", "danmaku append seg=$seg count=${items.size}")
                            }
                            binding.danmakuView.appendDanmakus(items, alreadySorted = true)
                            appendedAny = true
                        }

                        trimDanmakuCacheIfNeeded(requestPositionMs)

                        if (!appendedAny && debugEnabled) {
                            AppLog.d("Player", "danmaku loadedSegs=${loaded.joinToString()} but no new items (after filter)")
                        }
                    }
                }
            }
    }

    internal fun cancelDanmakuLoading(reason: String) {
        danmakuLoadGeneration++
        danmakuLoadJob?.cancel()
        danmakuLoadJob = null
        danmakuLoadingSegments.clear()
        if (::session.isInitialized && session.debugEnabled) {
            AppLog.d("Player", "danmaku loading canceled reason=$reason generation=$danmakuLoadGeneration")
        }
    }

    private fun canLoadSegment(segmentIndex: Int): Boolean {
        if (segmentIndex <= 0) return false
        if (danmakuSegmentTotal > 0 && segmentIndex > danmakuSegmentTotal) return false
        if (danmakuLoadedSegments.contains(segmentIndex)) return false
        if (danmakuLoadingSegments.contains(segmentIndex)) return false
        danmakuLoadingSegments.add(segmentIndex)
        return true
    }

    private fun trimDanmakuCacheIfNeeded(positionMs: Long) {
        if (danmakuLoadedSegments.size <= DANMAKU_CACHE_SEGMENTS) return
        val segSize = danmakuSegmentSizeMs.coerceAtLeast(1)
        val currentSeg = (positionMs / segSize).toInt() + 1
        val minSeg = (currentSeg - DANMAKU_CACHE_SEGMENTS / 2).coerceAtLeast(1)
        val maxSeg = minSeg + DANMAKU_CACHE_SEGMENTS - 1
        val keepSegs = danmakuLoadedSegments.filter { it in minSeg..maxSeg }.toSet()
        if (keepSegs.size == danmakuLoadedSegments.size) return
        danmakuLoadedSegments.retainAll(keepSegs)
        val it = danmakuSegmentItems.entries.iterator()
        while (it.hasNext()) {
            val seg = it.next().key
            if (seg !in keepSegs) it.remove()
        }

        
        val minTimeMs = (minSeg - 1L) * segSize.toLong()
        val maxTimeMs = maxSeg.toLong() * segSize.toLong()
        binding.danmakuView.trimToTimeRange(minTimeMs = minTimeMs, maxTimeMs = maxTimeMs)
    }

    internal fun resolutionSubtitle(): String {
        val qn =
            session.actualQn.takeIf { it > 0 }
                ?: session.targetQn.takeIf { it > 0 }
                ?: session.preferredQn
        return qnLabel(qn)
    }

    internal fun audioSubtitle(): String {
        val id =
            session.actualAudioId.takeIf { it > 0 }
                ?: session.targetAudioId.takeIf { it > 0 }
                ?: session.preferAudioId
        return audioLabel(id)
    }

    internal fun playUrlParamsForSession(): Pair<Int, Int> {
        
        val qn = 127
        var fnval = 4048 
        fnval = fnval or 128 
        fnval = fnval or 1024 
        fnval = fnval or 64 
        fnval = fnval or 512 
        return qn to fnval
    }

    internal fun applyResolutionFallbackIfNeeded(requestedQn: Int, actualQn: Int) {
        var changed = false
        if (actualQn > 0 && session.actualQn != actualQn) {
            session = session.copy(actualQn = actualQn)
            changed = true
        }

        if (requestedQn > 0 && actualQn > 0 && requestedQn != actualQn) {
            val fallbackQn = pickQnByQualityOrder(lastAvailableQns, requestedQn).takeIf { it > 0 } ?: actualQn
            if (session.targetQn != fallbackQn) {
                session = session.copy(targetQn = fallbackQn)
                changed = true
            }
        }

        if (changed) {
            refreshSettings(binding.recyclerSettings.adapter as PlayerSettingsAdapter)
        }
    }

    internal fun applyAudioFallbackIfNeeded(requestedAudioId: Int, actualAudioId: Int) {
        var changed = false
        if (actualAudioId > 0 && session.actualAudioId != actualAudioId) {
            session = session.copy(actualAudioId = actualAudioId)
            changed = true
        }

        if (requestedAudioId > 0 && actualAudioId > 0 && requestedAudioId != actualAudioId) {
            if (session.targetAudioId != actualAudioId) {
                session = session.copy(targetAudioId = actualAudioId)
                changed = true
            }
        }

        if (changed) {
            refreshSettings(binding.recyclerSettings.adapter as PlayerSettingsAdapter)
        }
    }

    internal fun parseDashVideoQnList(stream: VideoPlayStream): List<Int> =
        stream.dash
            ?.videos
            .orEmpty()
            .filter { it.urls.isNotEmpty() && it.qn > 0 }
            .map { it.qn }
            .distinct()
            .sortedBy { qnRank(it) }

    internal fun parseSelectableDashVideoQnList(stream: VideoPlayStream, constraints: PlaybackConstraints): List<Int> =
        stream.dash
            ?.videos
            .orEmpty()
            .filter { it.urls.isNotEmpty() && it.qn > 0 }
            .filterNot { it.isDolbyVision && !constraints.allowDolbyVision }
            .map { it.qn }
            .distinct()
            .sortedBy { qnRank(it) }

    internal fun parseDashAudioIdList(stream: VideoPlayStream, constraints: PlaybackConstraints): List<Int> =
        stream.dash
            ?.audios
            .orEmpty()
            .filter { it.urls.isNotEmpty() && it.id > 0 }
            .filterNot { audio ->
                (audio.kind == VideoAudioKind.DOLBY && !constraints.allowDolbyAudio) ||
                    (audio.kind == VideoAudioKind.FLAC && !constraints.allowFlacAudio)
            }
            .map { it.id }
            .distinct()

    internal fun logPlayUrlTrackSummary(source: String, stream: VideoPlayStream, constraints: PlaybackConstraints) {
        val rawQns = parseDashVideoQnList(stream)
        val selectableQns = parseSelectableDashVideoQnList(stream, constraints)
        val rawAudioIds = parseDashAudioIdList(stream, constraints = PlaybackConstraints())
        val selectableAudioIds = parseDashAudioIdList(stream, constraints = constraints)
        val targetQn = effectiveTargetQnForLog()
        val targetAudioId = effectiveTargetAudioIdForLog()
        AppLog.i(
            "Player",
            "playurl summary source=$source targetQn=$targetQn targetAudioId=$targetAudioId constraints=$constraints " +
                "rawQns=$rawQns selectableQns=$selectableQns rawAudioIds=$rawAudioIds selectableAudioIds=$selectableAudioIds",
        )
        trace?.log(
            "playurl:summary",
            "src=$source targetQn=$targetQn targetAudioId=$targetAudioId rawQns=$rawQns selectableQns=$selectableQns rawAudioIds=$rawAudioIds selectableAudioIds=$selectableAudioIds",
        )
    }

    internal fun logPickedPlayable(source: String, playable: Playable) {
        val targetQn = effectiveTargetQnForLog()
        val targetAudioId = effectiveTargetAudioIdForLog()
        when (playable) {
            is Playable.Dash -> {
                AppLog.i(
                    "Player",
                    "selected source=$source targetQn=$targetQn targetAudioId=$targetAudioId actualQn=${playable.qn} " +
                        "codecid=${playable.codecid} dv=${playable.isDolbyVision} audio=${playable.audioKind}(${playable.audioId}) " +
                        "video=${playable.videoUrl}",
                )
            }

            is Playable.VideoOnly -> {
                AppLog.i(
                    "Player",
                    "selected source=$source targetQn=$targetQn targetAudioId=$targetAudioId actualQn=${playable.qn} " +
                        "codecid=${playable.codecid} dv=${playable.isDolbyVision} videoOnly=${playable.videoUrl}",
                )
            }

            is Playable.Progressive -> {
                AppLog.i(
                    "Player",
                    "selected source=$source targetQn=$targetQn targetAudioId=$targetAudioId progressive=${playable.url}",
                )
            }
        }
    }

    companion object {
        private const val HIGH_SPEC_FALLBACK_MAX_ATTEMPTS = 3
        private const val EXIT_TRACE_PREFIX = "EXIT_TRACE"
        const val EXTRA_BVID = "bvid"
        const val EXTRA_CID = "cid"
        const val EXTRA_EP_ID = "ep_id"
        const val EXTRA_AID = "aid"
        const val EXTRA_SEASON_ID = "season_id"
        const val EXTRA_START_POSITION_MS = "start_position_ms"
        const val EXTRA_AUDIO_ONLY = "audio_only"
        const val EXTRA_SHUFFLE = "shuffle_enabled"
        const val EXTRA_PLAYLIST_TOKEN = "playlist_token"
        const val EXTRA_PLAYLIST_INDEX = "playlist_index"
        internal const val EXTRA_ENGINE_SWITCH_RESUME_POSITION_MS = "engine_switch_resume_position_ms"
        internal const val EXTRA_ENGINE_SWITCH_RESUME_PLAY_WHEN_READY = "engine_switch_resume_play_when_ready"
        internal const val EXTRA_ENGINE_SWITCH_SESSION_JSON = "engine_switch_session_json"
        private const val ACTIVITY_STACK_GROUP: String = "player_up_flow"
        private const val ACTIVITY_STACK_MAX_DEPTH: Int = 3
        internal const val SEEK_MAX = 10_000
        internal const val AUTO_HIDE_MS = 4_000L
        internal const val EDGE_TAP_THRESHOLD = 0.4f
        private const val TAP_SEEK_ACTIVE_MS = 1_200L
        internal const val SMART_SEEK_WINDOW_MS = 900L
        internal const val HOLD_SCRUB_TICK_MS = 40L
        internal const val HOLD_SCRUB_FIXED_STEP_BASE_TICK_MS = 120L
        private const val BACK_DOUBLE_PRESS_WINDOW_MS = 2_500L
        internal const val TOUCH_LOCK_UI_HIDE_DELAY_MS = 2_500L
        internal const val TOUCH_GESTURE_EXCLUDED_EDGE_RATIO = 0.03f
        internal const val TOUCH_GESTURE_EDGE_LONG_PRESS_THRESHOLD = 0.18f
        internal const val TOUCH_GESTURE_SIDE_VERTICAL_THRESHOLD = 0.32f
        internal const val TOUCH_GESTURE_DIRECTION_RATIO = 1.2f
        internal const val TOUCH_GESTURE_SEEK_START_THRESHOLD_MULTIPLIER = 2.5f
        internal const val TOUCH_GESTURE_SEEK_START_MIN_DP = 20f
        internal const val TOUCH_GESTURE_VERTICAL_START_THRESHOLD_MULTIPLIER = 3f
        internal const val TOUCH_GESTURE_VERTICAL_START_MIN_DP = 25f
        internal const val TOUCH_GESTURE_BLOCK_THRESHOLD_MULTIPLIER = 3f
        internal const val TOUCH_GESTURE_SEEK_RATIO = 0.18f
        internal const val TOUCH_GESTURE_SEEK_MIN_FULL_WIDTH_MS = 20_000L
        internal const val TOUCH_GESTURE_SEEK_MAX_FULL_WIDTH_MS = 4 * 60_000L
        internal const val TOUCH_GESTURE_MIN_BRIGHTNESS = 0.02f
        internal const val SEEK_HINT_HIDE_DELAY_MS = 900L
        internal const val PLAYBACK_TITLE_HINT_HIDE_DELAY_MS = 2_500L
        internal const val AUTO_NEXT_PREVIEW_WINDOW_MS = 5_000L
        internal const val AUTO_NEXT_TITLE_MAX_CHARS = 18
        internal const val SEEK_OSD_HIDE_DELAY_MS = 1_500L
        internal const val VIDEOSHOT_PREVIEW_HIDE_AFTER_SEEK_MS = 500L
        internal const val AUTO_SKIP_START_WINDOW_MS = 1_000L
        internal const val AUTO_SKIP_DELAY_MS = 2_000L
        internal const val AUTO_RESUME_BACK_RESTART_WINDOW_MS = 3_000L
        internal const val KEY_STEP_SEEK_COMMIT_DELAY_MS = 450L
        internal const val KEY_SCRUB_END_DELAY_MS = 800L
        internal const val KEY_SEEK_BUFFERING_POST_COMMIT_GRACE_MS = 250L
        private const val DANMAKU_DEFAULT_SEGMENT_MS = 6 * 60 * 1000
        private const val DANMAKU_PREFETCH_SEGMENTS = 2
        private const val DANMAKU_PREFETCH_INTERVAL_MS = 1_000L
        private const val DANMAKU_CACHE_SEGMENTS = 20
        private const val PLAYURL_RISK_LOG_FULL_JSON_MAX_CHARS = 8_192
        private const val PLAYURL_AUTO_REFRESH_LEAD_MS = 3 * 60_000L
        private const val PLAYURL_AUTO_REFRESH_FALLBACK_DELAY_MS = 55 * 60_000L
        private const val PLAYURL_AUTO_REFRESH_FALLBACK_MIN_DURATION_MS = 60 * 60_000L
        private const val PLAYURL_AUTO_REFRESH_MIN_RELOAD_INTERVAL_MS = 30_000L
    }

    internal fun applyRenderForEngine(engine: BlblPlayerEngine, prefs: AppPrefs) {
        
        binding.ijkAspect.visibility = View.GONE
        binding.ijkContainer.removeAllViews()
        ijkRenderView = null
        ijkTextureSurface?.release()
        ijkTextureSurface = null
        engine.setVideoSurface(null)
        applyPlayerRotation()

        
        if (audioOnlyMode) {
            binding.playerView.visibility = View.GONE
            binding.danmakuView.visibility = View.GONE
            if (binding.fmPanel.visibility != View.VISIBLE) {
                binding.fmPanel.visibility = View.VISIBLE
                startFmMode()
            }
            val exoOnly = (engine as? ExoPlayerEngine)?.exoPlayer
            if (exoOnly != null) {
                runCatching {
                    exoOnly.trackSelectionParameters =
                        exoOnly.trackSelectionParameters
                            .buildUpon()
                            .setTrackTypeDisabled(androidx.media3.common.C.TRACK_TYPE_VIDEO, true)
                            .build()
                }
            }
            return
        }

        val exo = (engine as? ExoPlayerEngine)?.exoPlayer
        if (engine.kind == PlayerEngineKind.ExoPlayer) {
            binding.playerView.player = exo
            return
        }

        
        binding.playerView.player = null
        binding.ijkAspect.visibility = View.VISIBLE
        binding.ijkAspect.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT)
        binding.ijkAspect.setAspectRatio(0f)

        val renderView: View =
            if (prefs.playerRenderViewType == AppPrefs.PLAYER_RENDER_VIEW_TEXTURE_VIEW) {
                TextureView(this).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    isClickable = false
                    isLongClickable = false
                }
            } else {
                SurfaceView(this).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    isClickable = false
                    isLongClickable = false
                }
            }

        binding.ijkContainer.addView(
            renderView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
                android.view.Gravity.CENTER,
            ),
        )
        ijkRenderView = renderView

        when (renderView) {
            is SurfaceView -> {
                val callback =
                    object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {
                            engine.setVideoSurface(holder.surface)
                        }

                        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                            engine.setVideoSurface(holder.surface)
                        }

                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                            engine.setVideoSurface(null)
                        }
                    }
                renderView.holder.addCallback(callback)
            }

            is TextureView -> {
                fun setSurface(surfaceTexture: SurfaceTexture?) {
                    ijkTextureSurface?.release()
                    ijkTextureSurface = null
                    if (surfaceTexture == null) {
                        engine.setVideoSurface(null)
                        return
                    }
                    val surface = Surface(surfaceTexture)
                    ijkTextureSurface = surface
                    engine.setVideoSurface(surface)
                }

                renderView.surfaceTextureListener =
                    object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            setSurface(surface)
                        }

                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            setSurface(null)
                            return true
                        }

                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                if (renderView.isAvailable) {
                    setSurface(renderView.surfaceTexture)
                }
            }
        }
    }
}
