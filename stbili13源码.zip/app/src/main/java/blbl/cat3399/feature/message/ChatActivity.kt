package blbl.cat3399.feature.message

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.text.InputType
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.GridLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.feature.following.UpDetailActivity
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.cloneInUserScale
import blbl.cat3399.databinding.ActivityChatBinding
import blbl.cat3399.databinding.ItemFileManagerBinding
import blbl.cat3399.feature.login.QrLoginActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class ChatActivity : BaseActivity() {
    private var _binding: ActivityChatBinding? = null
    private val binding get() = _binding!!
    private val adapter = MessageAdapter()

    private val talkerId: Long by lazy { intent.getLongExtra(EXTRA_TALKER_ID, 0L) }
    private val talkerName: String by lazy { intent.getStringExtra(EXTRA_TALKER_NAME).orEmpty() }

    private var myUid: Long = 0L
    private var emoticons: List<BiliApi.MessageEmoticon> = emptyList()
    private var talkerFace: String? = null
    private var myFace: String? = null

    
    private val builtinEmoticons: List<BiliApi.MessageEmoticon> =
        listOf("[滑稽]", "[doge]", "[捂脸]", "[开心]", "[点赞]", "[大哭]", "[抠鼻]", "[星星眼]")
            .map { BiliApi.MessageEmoticon(text = it, url = "") }

    
    private var fmDir: java.io.File? = null
    private val fmRoot: java.io.File = Environment.getExternalStorageDirectory()
    private val fmAdapter = FmAdapter()
    private val imageExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {}

    private fun neededPermissions(): Array<String> {
        val perms = ArrayList<String>()
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
        }
        return perms.toTypedArray()
    }

    private fun hasPermissions(): Boolean =
        neededPermissions().all {
            ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityChatBinding.inflate(layoutInflater.cloneInUserScale(this))
        setContentView(binding.root)
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)

        binding.tvTitle.text = talkerName.ifBlank { "用户$talkerId" }
        binding.btnBack.setOnClickListener { finish() }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter
        
        binding.recycler.isFocusable = true
        binding.recycler.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS)

        binding.btnSend.setOnClickListener {
            val text = binding.etInput.text?.toString()?.trim().orEmpty()
            if (text.isBlank()) {
                AppToast.show(this, "输入内容不能为空")
                return@setOnClickListener
            }
            sendText(text)
        }
        binding.btnEmoji.setOnClickListener { toggleEmojiPanel() }
        binding.btnImage.setOnClickListener {
            if (!hasPermissions()) {
                permissionLauncher.launch(neededPermissions())
                return@setOnClickListener
            }
            openFileManager()
        }
        binding.fmRecycler.layoutManager = LinearLayoutManager(this)
        binding.fmRecycler.adapter = fmAdapter

        binding.root.post { binding.etInput.requestFocus() }
        loadHistory()
        loadEmoticons()
        loadTalkerProfiles()
    }

    override fun onKeyDown(keyCode: Int, event: android.view.KeyEvent): Boolean {
        when (keyCode) {
            
            android.view.KeyEvent.KEYCODE_DPAD_UP -> {
                if (currentFocus === binding.etInput || currentFocus == null) {
                    binding.recycler.requestFocus()
                    binding.recycler.scrollToPosition(adapter.itemCount - 1)
                    return true
                }
            }
            
            android.view.KeyEvent.KEYCODE_DPAD_DOWN -> {
                if (currentFocus === binding.recycler) {
                    binding.etInput.requestFocus()
                    return true
                }
            }
            
            android.view.KeyEvent.KEYCODE_ENTER,
            android.view.KeyEvent.KEYCODE_NUMPAD_ENTER,
            android.view.KeyEvent.KEYCODE_DPAD_CENTER,
            -> {
                if (currentFocus === binding.btnSend) {
                    binding.btnSend.performClick()
                    return true
                }
                if (currentFocus === binding.etInput) {
                    binding.btnSend.performClick()
                    return true
                }
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onBackPressed() {
        
        if (binding.emojiScroll.visibility == View.VISIBLE) {
            binding.emojiScroll.visibility = View.GONE
            binding.etInput.requestFocus()
            return
        }
        super.onBackPressed()
    }

    override fun onResume() {
        super.onResume()
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(this, getString(R.string.message_need_login))
            startActivity(Intent(this, QrLoginActivity::class.java))
            return
        }
        myUid = BiliClient.cookies.getCookieValue("DedeUserID")?.trim()?.toLongOrNull() ?: 0L
        loadHistory()
        loadTalkerProfiles()
    }

    private fun loadHistory() {
        if (talkerId <= 0L) {
            AppToast.show(this, "缺少会话对象")
            finish()
            return
        }
        lifecycleScope.launch {
            try {
                val items =
                    withContext(Dispatchers.IO) {
                        BiliApi.messageHistory(talkerId = talkerId, size = 50)
                    }
                if (isFinishing || isDestroyed) return@launch
                adapter.submit(items)
                if (items.isNotEmpty()) binding.recycler.scrollToPosition(items.lastIndex)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "加载失败")
                AppToast.show(this@ChatActivity, msg.take(60))
            }
        }
    }

    private fun loadEmoticons() {
        lifecycleScope.launch {
            val list =
                runCatching {
                    withContext(Dispatchers.IO) { BiliApi.messageEmoticons() }
                }.getOrDefault(emptyList())
            emoticons = list
            renderEmojiPanel()
        }
    }

    private fun sendText(text: String) {
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(this, getString(R.string.message_need_login))
            return
        }
        lifecycleScope.launch {
            try {
                withContext(Dispatchers.IO) {
                    BiliApi.messageSendText(receiverId = talkerId, text = text)
                }
                if (isFinishing || isDestroyed) return@launch
                
                binding.etInput.setText("")
                adapter.appendLocal(text = text, senderUid = myUid)
                binding.recycler.scrollToPosition(adapter.itemCount - 1)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "发送失败")
                AppToast.show(this@ChatActivity, msg.take(60))
            }
        }
    }

    private fun sendImage(uri: Uri) {
        val fileName = "chat_${System.currentTimeMillis()}.jpg"
        val cacheFile = java.io.File(cacheDir, fileName)
        lifecycleScope.launch {
            try {
                val url =
                    withContext(Dispatchers.IO) {
                        runCatching {
                            contentResolver.openInputStream(uri)?.use { input ->
                                cacheFile.outputStream().use { out -> input.copyTo(out) }
                            }
                        }
                        if (!cacheFile.exists() || cacheFile.length() <= 0L) {
                            error("无法读取所选图片")
                        }
                        BiliApi.messageUploadImage(cacheFile)
                    }
                if (url.isBlank()) {
                    AppToast.show(this@ChatActivity, "图片上传失败")
                    return@launch
                }
                withContext(Dispatchers.IO) {
                    BiliApi.messageSendImage(receiverId = talkerId, imageUrl = url)
                }
                if (isFinishing || isDestroyed) return@launch
                adapter.appendLocal(imageUrl = url, senderUid = myUid)
                binding.recycler.scrollToPosition(adapter.itemCount - 1)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "发送失败")
                AppToast.show(this@ChatActivity, msg.take(60))
            }
        }
    }

    

    private fun openFileManager() {
        fmDir = null
        binding.recycler.visibility = View.GONE
        binding.emojiScroll.visibility = View.GONE
        binding.inputBar.visibility = View.GONE
        binding.fmPanel.visibility = View.VISIBLE
        binding.tvTitle.text = "选择图片"
        loadFmRoot()
        binding.fmRecycler.requestFocus()
    }

    private fun closeFileManager() {
        binding.fmPanel.visibility = View.GONE
        binding.recycler.visibility = View.VISIBLE
        binding.inputBar.visibility = View.VISIBLE
        binding.tvTitle.text = talkerName.ifBlank { "用户$talkerId" }
        binding.root.post { binding.etInput.requestFocus() }
    }

    private fun loadFmRoot() {
        binding.tvPath.text = fmRoot.absolutePath
        val items = ArrayList<FmEntry>()
        items.add(FmEntry("全部图片", "", isDir = false, file = null, shortcutImages = true))
        items.addAll(listFmDir(fmRoot, level = 0))
        fmAdapter.submit(items)
    }

    private fun openFmDir(dir: java.io.File) {
        fmDir = dir
        binding.tvPath.text = dir.absolutePath
        val items = ArrayList<FmEntry>()
        items.add(FmEntry("返回上级", "..", isDir = true, file = dir.parentFile, shortcutImages = false))
        items.addAll(listFmDir(dir, level = 1))
        fmAdapter.submit(items)
    }

    private fun listFmDir(dir: java.io.File, level: Int): List<FmEntry> {
        val out = ArrayList<FmEntry>()
        val children = runCatching { dir.listFiles() }.getOrNull() ?: return out
        val dirs = ArrayList<java.io.File>()
        val images = ArrayList<java.io.File>()
        for (child in children) {
            if (!child.exists()) continue
            val name = child.name
            if (name.startsWith(".")) continue
            if (child.isDirectory) {
                if (level == 0 && name == "Android") continue
                dirs.add(child)
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                if (ext in imageExtensions) images.add(child)
            }
        }
        for (d in dirs.sortedBy { it.name.lowercase() }) {
            out.add(FmEntry(d.name + "/", "文件夹", isDir = true, file = d, shortcutImages = false))
        }
        for (f in images.sortedBy { it.name.lowercase() }) {
            out.add(FmEntry(f.name, "图片 · " + humanSize(f.length()), isDir = false, file = f, shortcutImages = false))
        }
        return out
    }

    private fun queryAllImages() {
        val wanted = imageExtensions
        lifecycleScope.launch(Dispatchers.IO) {
            val found = ArrayList<java.io.File>()
            val cursor =
                runCatching {
                    contentResolver.query(
                        android.provider.MediaStore.Images.Media.EXTERNAL_CONTENT_URI,
                        arrayOf(android.provider.MediaStore.Images.Media.DATA),
                        null,
                        null,
                        android.provider.MediaStore.Images.Media.DATE_ADDED + " DESC",
                    )
                }.getOrNull()
            cursor?.use { c ->
                val idx = c.getColumnIndexOrThrow(android.provider.MediaStore.Images.Media.DATA)
                while (c.moveToNext() && found.size < 200) {
                    val path = c.getString(idx) ?: continue
                    val f = java.io.File(path)
                    if (f.exists() && f.extension.lowercase() in wanted) found.add(f)
                }
            }
            withContext(kotlinx.coroutines.Dispatchers.Main) {
                if (isFinishing || isDestroyed) return@withContext
                binding.tvPath.text = "全部图片"
                val entries =
                    found.map { FmEntry(it.name, "图片 · " + humanSize(it.length()), isDir = false, file = it, shortcutImages = false) }
                if (entries.isEmpty()) {
                    AppToast.show(this@ChatActivity, "未找到图片")
                    return@withContext
                }
                fmAdapter.submit(entries)
                binding.fmRecycler.requestFocus()
            }
        }
    }

    private fun humanSize(bytes: Long): String {
        if (bytes <= 0L) return "0B"
        val units = arrayOf("B", "KB", "MB", "GB")
        var v = bytes.toDouble()
        var i = 0
        while (v >= 1024 && i < units.size - 1) {
            v /= 1024
            i++
        }
        return "%.1f%s".format(v, units[i])
    }

    private data class FmEntry(
        val name: String,
        val meta: String,
        val isDir: Boolean,
        val file: java.io.File?,
        val shortcutImages: Boolean,
    )

    private inner class FmAdapter : RecyclerView.Adapter<FmAdapter.Vh>() {
        private val entries = ArrayList<FmEntry>()

        fun submit(list: List<FmEntry>) {
            entries.clear()
            entries.addAll(list)
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = entries.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh =
            Vh(ItemFileManagerBinding.inflate(layoutInflater.cloneInUserScale(this@ChatActivity), parent, false))

        override fun onBindViewHolder(holder: Vh, position: Int) {
            val e = entries.getOrNull(position) ?: return
            holder.binding.tvName.text = e.name
            holder.binding.tvMeta.text = e.meta
            holder.binding.ivIcon.setImageResource(if (e.isDir) R.drawable.ic_nav_upload else R.drawable.ic_fm_image)
            holder.binding.root.setOnClickListener {
                when {
                    e.shortcutImages -> queryAllImages()
                    e.isDir && e.file != null -> openFmDir(e.file)
                    e.file != null -> {
                        sendImage(e.file)
                        closeFileManager()
                    }
                }
            }
        }

        inner class Vh(val binding: ItemFileManagerBinding) : RecyclerView.ViewHolder(binding.root)
    }

    
    private fun sendImage(file: java.io.File) {
        if (!file.exists() || file.length() <= 0L) {
            AppToast.show(this, "图片文件无效")
            return
        }
        lifecycleScope.launch {
            try {
                val url =
                    withContext(Dispatchers.IO) {
                        BiliApi.messageUploadImage(file)
                    }
                if (url.isBlank()) {
                    AppToast.show(this@ChatActivity, "图片上传失败")
                    return@launch
                }
                withContext(Dispatchers.IO) {
                    BiliApi.messageSendImage(receiverId = talkerId, imageUrl = url)
                }
                if (isFinishing || isDestroyed) return@launch
                adapter.appendLocal(imageUrl = url, senderUid = myUid)
                binding.recycler.scrollToPosition(adapter.itemCount - 1)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "发送失败")
                AppToast.show(this@ChatActivity, msg.take(60))
            }
        }
    }

    
    private fun loadTalkerProfiles() {
        if (!BiliClient.cookies.hasSessData()) return
        lifecycleScope.launch {
            if (talkerId > 0L) {
                runCatching {
                    withContext(Dispatchers.IO) { BiliApi.spaceAccInfo(talkerId) }
                }.onSuccess { info ->
                    if (isFinishing || isDestroyed) return@onSuccess
                    if (info.name.isNotBlank()) binding.tvTitle.text = info.name
                    talkerFace = info.faceUrl
                    adapter.notifyDataSetChanged()
                }
            }
            val self = BiliClient.cookies.getCookieValue("DedeUserID")?.trim()?.toLongOrNull() ?: return@launch
            runCatching {
                withContext(Dispatchers.IO) { BiliApi.spaceAccInfo(self) }
            }.onSuccess { info ->
                if (isFinishing || isDestroyed) return@onSuccess
                myFace = info.faceUrl
                adapter.notifyDataSetChanged()
            }
        }
    }

    private fun toggleEmojiPanel() {
        if (binding.emojiScroll.visibility == View.VISIBLE) {
            binding.emojiScroll.visibility = View.GONE
        } else {
            binding.emojiScroll.visibility = View.VISIBLE
            renderEmojiPanel()
        }
    }

    private fun renderEmojiPanel() {
        val grid = binding.emojiGrid
        grid.removeAllViews()
        
        val source = if (emoticons.isEmpty()) builtinEmoticons else emoticons
        val cols = 4
        val density = resources.displayMetrics.density
        var col = 0
        var row = 0
        for (emo in source.take(60)) {
            val cell =
                ImageView(this).apply {
                    contentDescription = emo.text
                    isFocusable = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    setPadding(dp(4))
                    background = androidx.core.content.ContextCompat.getDrawable(this@ChatActivity, R.drawable.blbl_focus_bg_round)
                    setOnClickListener {
                        binding.etInput.setText((binding.etInput.text?.toString().orEmpty()) + emo.text)
                        binding.etInput.setSelection(binding.etInput.text?.length ?: 0)
                    }
                }
            val lp = GridLayout.LayoutParams()
            lp.width = (72 * density).toInt()
            lp.height = (72 * density).toInt()
            lp.columnSpec = GridLayout.spec(col)
            lp.rowSpec = GridLayout.spec(row)
            lp.setMargins(dp(2), dp(2), dp(2), dp(2))
            grid.addView(cell, lp)
            if (emo.url.isNotBlank()) {
                ImageLoader.loadInto(cell, emo.url)
            } else {
                
                cell.setImageBitmap(renderEmojiText(emo.text))
            }
            col++
            if (col >= cols) {
                col = 0
                row++
            }
        }
    }


    private fun renderEmojiText(text: String): android.graphics.Bitmap? {
        val w = (72 * resources.displayMetrics.density).toInt()
        val h = w
        val tv =
            TextView(this).apply {
                this.text = text
                textSize = 11f
                setTextColor(0xFFDDDDDD.toInt())
                gravity = android.view.Gravity.CENTER
                includeFontPadding = false
            }
        tv.measure(
            android.view.View.MeasureSpec.makeMeasureSpec(w, android.view.View.MeasureSpec.EXACTLY),
            android.view.View.MeasureSpec.makeMeasureSpec(h, android.view.View.MeasureSpec.EXACTLY),
        )
        tv.layout(0, 0, w, h)
        val bmp = android.graphics.Bitmap.createBitmap(w, h, android.graphics.Bitmap.Config.ARGB_8888)
        tv.draw(android.graphics.Canvas(bmp))
        return bmp
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_TALKER_ID = "talker_id"
        const val EXTRA_TALKER_NAME = "talker_name"
    }

    private inner class MessageAdapter : RecyclerView.Adapter<MessageAdapter.Vh>() {
        private val items = ArrayList<BiliApi.MessageItem>()

        fun submit(list: List<BiliApi.MessageItem>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        fun appendLocal(
            text: String? = null,
            imageUrl: String? = null,
            senderUid: Long,
        ) {
            val content =
                if (imageUrl != null) {
                    "{\"url\":\"$imageUrl\"}"
                } else {
                    "{\"content\":\"${text.orEmpty()}\"}"
                }
            items.add(
                BiliApi.MessageItem(
                    senderUid = senderUid,
                    msgType = if (imageUrl != null) 2 else 1,
                    content = content,
                    timestampSec = System.currentTimeMillis() / 1000L,
                ),
            )
            notifyItemInserted(items.lastIndex)
        }

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
            val density = resources.displayMetrics.density
            
            val row = LinearLayout(parent.context).apply {
                orientation = LinearLayout.HORIZONTAL
                gravity = android.view.Gravity.CENTER_VERTICAL
                
                layoutParams =
                    RecyclerView.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                    )
                setPadding(dp(12), dp(6), dp(12), dp(6))
            }
            val avatar = ImageView(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams((44 * density).toInt(), (44 * density).toInt())
                background = parent.context.getDrawable(R.drawable.bg_circle_avatar)
                scaleType = ImageView.ScaleType.CENTER_CROP
                clipToOutline = true
                visibility = View.GONE
            }
            val inner = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    setMargins(dp(8), 0, dp(8), 0)
                }
            }
            val name = TextView(parent.context).apply {
                textSize = 11f
                setTextColor(0xFF9A9A9A.toInt())
                visibility = View.GONE
            }
            val bubble = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                setPadding(dp(12), dp(8), dp(12), dp(8))
            }
            val tv = TextView(parent.context).apply {
                textSize = 15f
                setTextColor(0xFFFFFFFF.toInt())
                maxWidth = (320 * density).toInt()
            }
            val iv = ImageView(parent.context).apply {
                maxWidth = (240 * density).toInt()
                adjustViewBounds = true
                visibility = View.GONE
            }
            bubble.addView(tv)
            bubble.addView(iv)
            inner.addView(name)
            inner.addView(bubble)
            row.addView(avatar)
            row.addView(inner)
            return Vh(row, avatar, inner, name, bubble, tv, iv)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            val item = items.getOrNull(position) ?: return
            runCatching {
                bindItem(holder, item)
            }.onFailure { t ->
                holder.tv.text = "[消息解析失败]"
                holder.iv.visibility = View.GONE
                holder.tv.visibility = View.VISIBLE
                AppLog.w("Chat", "bind item failed", t)
            }
        }

        private fun bindItem(holder: Vh, item: BiliApi.MessageItem) {
            
            val myUidNow = BiliClient.cookies.getCookieValue("DedeUserID")?.trim()?.toLongOrNull() ?: myUid
            val mine = item.senderUid == myUidNow
            holder.bubble.removeAllViews()
            holder.bubble.background =
                android.graphics.drawable.GradientDrawable().apply {
                    cornerRadii =
                        if (mine) {
                            floatArrayOf(dp(12).toFloat(), dp(12).toFloat(), dp(2).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat())
                        } else {
                            floatArrayOf(dp(2).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat(), dp(12).toFloat())
                        }
                    setColor(if (mine) 0xFFFB7299.toInt() else 0xFF3A3A3A.toInt())
                }
            if (item.msgType == 2) {
                holder.tv.visibility = View.GONE
                holder.iv.visibility = View.VISIBLE
                val url =
                    runCatching {
                        org.json.JSONObject(item.content).optString("url", "")
                    }.getOrDefault("")
                holder.iv.setImageResource(R.drawable.ic_fm_image)
                if (url.isNotBlank()) ImageLoader.loadInto(holder.iv, url)
                holder.bubble.removeAllViews()
                holder.bubble.addView(holder.iv)
            } else {
                holder.iv.visibility = View.GONE
                holder.tv.visibility = View.VISIBLE
                holder.tv.text = decodeTextContent(item.content)
                holder.bubble.removeAllViews()
                holder.bubble.addView(holder.tv)
            }
            
            holder.name.text = if (mine) "我" else (talkerName.ifBlank { "用户$talkerId" })
            holder.name.visibility = View.VISIBLE
            val face = if (mine) myFace else talkerFace
            
            holder.avatar.visibility = View.VISIBLE
            holder.avatar.setImageResource(R.drawable.ic_fm_image)
            if (!face.isNullOrBlank()) {
                ImageLoader.loadInto(holder.avatar, face)
            }
            
            holder.avatar.setOnClickListener {
                val uid = if (mine) myUid else talkerId
                if (uid <= 0L) return@setOnClickListener
                runCatching {
                    val nm = if (mine) "我" else talkerName
                    val fc = if (mine) myFace else talkerFace
                    startActivity(
                        Intent(this@ChatActivity, UpDetailActivity::class.java)
                            .putExtra(UpDetailActivity.EXTRA_MID, uid)
                            .apply {
                                if (nm.isNotBlank()) putExtra(UpDetailActivity.EXTRA_NAME, nm)
                                if (!fc.isNullOrBlank()) putExtra(UpDetailActivity.EXTRA_AVATAR, fc)
                            },
                    )
                }
            }
            
            holder.row.removeAllViews()
            holder.row.gravity = if (mine) android.view.Gravity.END else android.view.Gravity.START
            if (mine) {
                holder.row.addView(holder.inner)
                holder.row.addView(holder.avatar)
            } else {
                holder.row.addView(holder.avatar)
                holder.row.addView(holder.inner)
            }
            holder.inner.removeAllViews()
            holder.inner.gravity = if (mine) android.view.Gravity.END else android.view.Gravity.START
            holder.inner.addView(holder.name)
            holder.inner.addView(holder.bubble)
        }

        
        private fun decodeTextContent(content: String): String {
            val trimmed = content.trim()
            if (trimmed.startsWith("{")) {
                val parsed =
                    runCatching {
                        val obj = org.json.JSONObject(trimmed)
                        obj.optString("content").takeIf { it.isNotBlank() }
                            ?: obj.optString("text")
                    }.getOrNull()
                if (!parsed.isNullOrBlank()) return parsed
            }
            return trimmed.ifEmpty { "[空消息]" }
        }

        inner class Vh(
            val row: LinearLayout,
            val avatar: ImageView,
            val inner: LinearLayout,
            val name: TextView,
            val bubble: LinearLayout,
            val tv: TextView,
            val iv: ImageView,
        ) : RecyclerView.ViewHolder(row)
    }
}
