package blbl.cat3399.feature.following

import android.content.Intent
import android.os.Bundle
import android.view.KeyEvent
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.model.Following
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.paging.PagedGridStateMachine
import blbl.cat3399.core.paging.appliedOrNull
import blbl.cat3399.core.tv.RemoteKeys
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.DpadGridController
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.cloneInUserScale
import blbl.cat3399.databinding.ActivityFollowingListBinding
import blbl.cat3399.feature.login.QrLoginActivity
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class FansListActivity : BaseActivity() {
    private lateinit var binding: ActivityFollowingListBinding
    private lateinit var adapter: FollowingGridAdapter

    private var vmid: Long = 0L
    private var fallbackSelfMid: Long = 0L
    private var total: Int = 0
    private val loadedMids = HashSet<Long>()
    private val paging = PagedGridStateMachine(initialKey = 1)

    private var dpadGridController: DpadGridController? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFollowingListBinding.inflate(layoutInflater.cloneInUserScale(this))
        setContentView(binding.root)
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)

        binding.tvTitle.text = getString(R.string.fans_list_title)
        binding.btnBack.setOnClickListener { finish() }
        binding.btnLogin.setOnClickListener { startActivity(Intent(this, QrLoginActivity::class.java)) }

        vmid = intent.getLongExtra(EXTRA_MID, 0L)

        adapter =
            FollowingGridAdapter { following ->
                startActivity(
                    Intent(this, UpDetailActivity::class.java)
                        .putExtra(UpDetailActivity.EXTRA_MID, following.mid)
                        .putExtra(UpDetailActivity.EXTRA_NAME, following.name)
                        .putExtra(UpDetailActivity.EXTRA_AVATAR, following.avatarUrl)
                        .putExtra(UpDetailActivity.EXTRA_SIGN, following.sign),
                )
            }

        binding.recycler.setHasFixedSize(true)
        binding.recycler.layoutManager = GridLayoutManager(this, spanCountForWidth())
        binding.recycler.adapter = adapter
        (binding.recycler.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false

        binding.recycler.clearOnScrollListeners()
        binding.recycler.addOnScrollListener(
            object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    if (dy <= 0) return
                    val s = paging.snapshot()
                    if (s.isLoading || s.endReached) return
                    val lm = recyclerView.layoutManager as? GridLayoutManager ?: return
                    val lastVisible = lm.findLastVisibleItemPosition()
                    val totalCount = adapter.itemCount
                    if (totalCount <= 0) return
                    if (totalCount - lastVisible - 1 <= 12) loadNextPage()
                }
            },
        )
        dpadGridController?.release()
        dpadGridController =
            DpadGridController(
                recyclerView = binding.recycler,
                callbacks =
                    object : DpadGridController.Callbacks {
                        override fun onTopEdge(): Boolean {
                            binding.btnBack.requestFocus()
                            return true
                        }

                        override fun onLeftEdge(): Boolean = false

                        override fun onRightEdge() = Unit

                        override fun canLoadMore(): Boolean = !paging.snapshot().endReached

                        override fun loadMore() {
                            loadNextPage()
                        }
                    },
                config =
                    DpadGridController.Config(
                        isEnabled = { !isFinishing && !isDestroyed },
                    ),
            ).also { it.install() }

        binding.swipeRefresh.setOnRefreshListener { resetAndLoad() }

        refreshLoginUi()
        if (binding.loginContainer.isVisible) {
            binding.btnLogin.requestFocus()
        } else {
            binding.swipeRefresh.isRefreshing = true
            resetAndLoad()
        }
    }

    override fun onResume() {
        super.onResume()
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)
        adapter.invalidateSizing()
        (binding.recycler.layoutManager as? GridLayoutManager)?.spanCount = spanCountForWidth()
        refreshLoginUi()
        if (!binding.loginContainer.isVisible && adapter.itemCount == 0 && !binding.swipeRefresh.isRefreshing) {
            binding.swipeRefresh.isRefreshing = true
            resetAndLoad()
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount == 0 && RemoteKeys.isRefreshKey(event.keyCode)) {
            if (binding.loginContainer.isVisible) {
                AppToast.show(this, "请先登录")
                binding.btnLogin.requestFocus()
                return true
            }
            if (binding.swipeRefresh.isRefreshing) return true
            binding.swipeRefresh.isRefreshing = true
            resetAndLoad()
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun refreshLoginUi() {
        val loggedIn = blbl.cat3399.core.net.BiliClient.cookies.hasSessData()
        binding.loginContainer.isVisible = !loggedIn
        binding.recycler.isVisible = loggedIn
    }

    private fun resetAndLoad() {
        paging.reset()
        loadedMids.clear()
        total = 0
        dpadGridController?.clearPendingFocusAfterLoadMore()
        adapter.submit(emptyList())
        loadNextPage(isRefresh = true)
    }

    private data class FetchedPage(
        val items: List<Following>,
        val total: Int,
        val hasMore: Boolean,
    )

    private fun loadNextPage(isRefresh: Boolean = false) {
        val startSnap = paging.snapshot()
        if (startSnap.isLoading || startSnap.endReached) return
        val startGen = startSnap.generation
        val startPage = startSnap.nextKey
        lifecycleScope.launch {
            try {
                var latestFetched: FetchedPage? = null
                val result =
                    paging.loadNextPage(
                        isRefresh = isRefresh,
                        fetch = { page ->
                            val mid = ensureTargetMid()
                            if (mid == null) {
                                null
                            } else {
                                val res = BiliApi.followersPage(vmid = mid, pn = page, ps = 50)
                                FetchedPage(items = res.items, total = res.total, hasMore = res.hasMore).also { latestFetched = it }
                            }
                        },
                        reduce = { page, fetched ->
                            if (fetched.items.isEmpty()) {
                                PagedGridStateMachine.Update(
                                    items = emptyList<Following>(),
                                    nextKey = page,
                                    endReached = true,
                                )
                            } else {
                                val seen = HashSet<Long>(fetched.items.size)
                                val unique = ArrayList<Following>(fetched.items.size)
                                for (item in fetched.items) {
                                    if (seen.add(item.mid)) unique.add(item)
                                }
                                PagedGridStateMachine.Update(
                                    items = unique,
                                    nextKey = page + 1,
                                    endReached = !fetched.hasMore,
                                )
                            }
                        },
                    )
                if (result == null) {
                    if (isRefresh) {
                        binding.swipeRefresh.isRefreshing = false
                        AppToast.show(this@FansListActivity, "请先登录")
                        refreshLoginUi()
                        binding.btnLogin.requestFocus()
                    }
                    return@launch
                }
                val applied = result.appliedOrNull() ?: return@launch
                val fetched = latestFetched ?: return@launch
                total = fetched.total
                if (fetched.items.isEmpty()) {
                    if (applied.isRefresh) AppToast.show(this@FansListActivity, "暂无粉丝")
                    return@launch
                }
                applied.items.forEach { loadedMids.add(it.mid) }
                if (applied.isRefresh) {
                    adapter.submit(applied.items)
                    binding.recycler.requestFocus()
                } else {
                    adapter.append(applied.items)
                }
                binding.swipeRefresh.isRefreshing = false
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                binding.swipeRefresh.isRefreshing = false
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "加载失败")
                AppToast.show(this@FansListActivity, msg.take(60))
            }
        }
    }

    
    private suspend fun ensureTargetMid(): Long? {
        if (vmid > 0L) return vmid
        if (fallbackSelfMid > 0L) return fallbackSelfMid
        val selfMid = withContext(Dispatchers.IO) {
            blbl.cat3399.core.net.BiliClient.cookies.getCookieValue("DedeUserID")?.trim()?.toLongOrNull()?.takeIf { it > 0L }
        }
        if (selfMid != null) {
            fallbackSelfMid = selfMid
            vmid = selfMid
        }
        return selfMid
    }

    private fun spanCountForWidth(): Int {
        val w = resources.configuration.screenWidthDp.coerceAtLeast(320)
        return when {
            w >= 1200 -> 6
            w >= 900 -> 5
            w >= 700 -> 4
            w >= 500 -> 3
            else -> 2
        }
    }

    override fun onDestroy() {
        dpadGridController?.release()
        dpadGridController = null
        super.onDestroy()
    }

    companion object {
        const val EXTRA_MID = "extra_mid"
    }
}
