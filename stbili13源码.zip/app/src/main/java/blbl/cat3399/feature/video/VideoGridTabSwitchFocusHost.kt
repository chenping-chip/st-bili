package blbl.cat3399.feature.video

import blbl.cat3399.core.ui.TabContentSwitchFocusHost


interface VideoGridTabSwitchFocusHost : TabContentSwitchFocusHost {
    fun requestFocusCurrentPageFirstCardFromContentSwitch(): Boolean

    override fun requestFocusCurrentPagePrimaryItemFromContentSwitch(): Boolean = requestFocusCurrentPageFirstCardFromContentSwitch()
}
