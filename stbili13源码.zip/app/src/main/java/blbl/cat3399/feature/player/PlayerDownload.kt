package blbl.cat3399.feature.player

import android.Manifest
import android.content.ContentValues
import android.content.pm.PackageManager
import android.media.MediaScannerConnection
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.core.download.VideoDownloader
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.popup.AppPopup
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.io.IOException


internal fun PlayerActivity.startCurrentVideoDownload() {
    val activity = this
    val cid = currentCid
    val bvid = currentBvid.trim().takeIf { it.isNotBlank() }
    if (cid <= 0L || bvid == null) {
        AppToast.show(this, "当前视频暂不支持下载")
        return
    }
    if (downloadingVideo != null) {
        AppToast.show(this, "已有下载任务进行中")
        return
    }

    
    if (Build.VERSION.SDK_INT <= 28) {
        val hasWrite =
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) ==
                PackageManager.PERMISSION_GRANTED
        if (!hasWrite) {
            AppToast.show(this, "需要存储权限才能保存到相册")
            return
        }
    }

    val title = currentMediaTitle().takeIf { it.isNotBlank() } ?: bvid

    val handle =
        AppPopup.progress(
            context = activity,
            title = "下载中",
            status = "正在获取视频流…",
            negativeText = "取消",
            cancelable = false,
        )
    if (handle == null) return
    downloadingVideo = DownloadingState(cid = cid, handle = handle)

    lifecycleScope.launch {
        try {
            val stream =
                withContext(Dispatchers.IO) {
                    VideoDownloader.resolveStream(bvid = bvid, aid = currentAid, cid = cid)
                }
            handle.updateStatus("正在下载…")

            val safeName = sanitizeFileName(title) + ".mp4"
            val appContext = applicationContext
            val savedPath =
                withContext(Dispatchers.IO) {
                    downloadAndSaveToGallery(
                        appContext = appContext,
                        url = stream.url,
                        displayName = safeName,
                        onProgress = { percent ->
                            percent?.let { handle.updateProgress(it) }
                        },
                        onBytes = { bytes, total ->
                            handle.updateStatus("已下载 ${formatBytes(bytes)} / ${total?.let(::formatBytes) ?: "-"}")
                        },
                    )
                }
            handle.updateStatus("完成：${formatBytes(savedPath.second)}")
            handle.dismiss()
            AppToast.show(activity, "已保存到相册：${savedPath.first}")
        } catch (e: Throwable) {
            AppLog.w("Download", "download failed bvid=$bvid cid=$cid", e)
            if (e is kotlinx.coroutines.CancellationException) throw e
            handle.updateStatus("下载失败")
            handle.dismiss()
            AppToast.show(activity, "下载失败：${e.message.orEmpty().take(80)}")
        } finally {
            downloadingVideo = null
        }
    }
}


private suspend fun downloadAndSaveToGallery(
    appContext: android.content.Context,
    url: String,
    displayName: String,
    onProgress: (Int?) -> Unit,
    onBytes: (Long, Long?) -> Unit,
): Pair<String, Long> {
    val tmpDir = File(appContext.cacheDir, "stbili_download")
    tmpDir.mkdirs()
    val tmp = File(tmpDir, "download_${System.currentTimeMillis()}_$displayName")
    val bytes =
        try {
            VideoDownloader.downloadToFile(url = url, target = tmp) { progress ->
                progress.percent?.let(onProgress)
                onBytes(progress.bytesDone, progress.totalBytes)
            }
        } catch (t: Throwable) {
            tmp.delete()
            throw t
        }
    if (!tmp.exists() || tmp.length() <= 0L) {
        tmp.delete()
        throw IOException("下载文件为空")
    }

    return try {
        if (Build.VERSION.SDK_INT >= 29) {
            saveViaMediaStore(appContext, tmp, displayName)
        } else {
            saveViaLegacyPublicDir(appContext, tmp, displayName)
        }
    } finally {
        tmp.delete()
    }
}

private fun saveViaMediaStore(appContext: android.content.Context, tmp: File, displayName: String): Pair<String, Long> {
    val resolver = appContext.contentResolver
    val values =
        ContentValues().apply {
            put(MediaStore.Video.Media.DISPLAY_NAME, displayName)
            put(MediaStore.Video.Media.MIME_TYPE, "video/mp4")
            put(MediaStore.Video.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/stbili")
            put(MediaStore.Video.Media.IS_PENDING, 1)
        }
    val collection =
        if (Build.VERSION.SDK_INT >= 29) {
            MediaStore.Video.Media.getContentUri(MediaStore.VOLUME_EXTERNAL_PRIMARY)
        } else {
            MediaStore.Video.Media.EXTERNAL_CONTENT_URI
        }
    val uri: Uri? = resolver.insert(collection, values)
    if (uri == null) throw IOException("无法写入相册")
    try {
        resolver.openOutputStream(uri)?.use { out ->
            tmp.inputStream().use { input -> input.copyTo(out) }
        } ?: throw IOException("无法打开相册输出流")
        values.clear()
        values.put(MediaStore.Video.Media.IS_PENDING, 0)
        resolver.update(uri, values, null, null)
    } catch (t: Throwable) {
        runCatching { resolver.delete(uri, null, null) }
        throw t
    }
    val display = "相册/Pictures/stbili/$displayName"
    return display to tmp.length()
}

private fun saveViaLegacyPublicDir(appContext: android.content.Context, tmp: File, displayName: String): Pair<String, Long> {
    val dir = File(Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES), "stbili")
    dir.mkdirs()
    val target = uniqueTarget(dir, displayName)
    tmp.inputStream().use { input ->
        target.outputStream().use { output -> input.copyTo(output) }
    }
    
    MediaScannerConnection.scanFile(appContext, arrayOf(target.absolutePath), arrayOf("video/mp4"), null)
    return "相册/Pictures/stbili/${target.name}" to target.length()
}

private fun uniqueTarget(dir: File, displayName: String): File {
    var target = File(dir, displayName)
    var index = 1
    while (target.exists()) {
        val name = displayName.substringBeforeLast('.') + "_$index.mp4"
        target = File(dir, name)
        index++
    }
    return target
}

internal data class DownloadingState(
    val cid: Long,
    val handle: AppPopup.ProgressHandle,
)

private fun PlayerActivity.currentMediaTitle(): String =
    runCatching { binding.tvTitle.text?.toString().orEmpty() }.getOrNull().orEmpty()

private fun sanitizeFileName(name: String): String {
    val cleaned =
        name
            .replace(Regex("""[\\/:*?"<>|\n\r\t]"""), "_")
            .trim()
            .take(60)
    return cleaned.ifBlank { "video" }
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024) return String.format(java.util.Locale.US, "%.1f KB", kb)
    val mb = kb / 1024.0
    if (mb < 1024) return String.format(java.util.Locale.US, "%.1f MB", mb)
    val gb = mb / 1024.0
    return String.format(java.util.Locale.US, "%.2f GB", gb)
}
