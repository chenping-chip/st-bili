package blbl.cat3399.feature.message

import android.content.Intent
import android.os.Bundle
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.image.ImageUrl
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.databinding.ActivityMessageListBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MessageFragment : Fragment() {
    private var _binding: ActivityMessageListBinding? = null
    private val binding get() = _binding!!
    private val adapter = SessionAdapter()
    private var loading = false

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = ActivityMessageListBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.btnBack.visibility = View.GONE
        binding.recycler.layoutManager = LinearLayoutManager(requireContext())
        binding.recycler.adapter = adapter
        binding.swipeRefresh.setOnRefreshListener { load(initial = true) }
        binding.swipeRefresh.post { load(initial = true) }
    }

    override fun onResume() {
        super.onResume()
        if (adapter.itemCount == 0 && !loading) load(initial = true)
    }

    private fun load(initial: Boolean = false) {
        if (loading) return
        val activity = requireActivity()
        if (!BiliClient.cookies.hasSessData()) {
            binding.swipeRefresh.isRefreshing = false
            binding.tvEmpty.text = getString(R.string.message_need_login)
            binding.tvEmpty.visibility = View.VISIBLE
            return
        }
        loading = true
        if (initial) {
            binding.tvEmpty.visibility = View.GONE
            binding.swipeRefresh.isRefreshing = true
        }
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val sessions =
                    withContext(Dispatchers.IO) {
                        BiliApi.messageSessions()
                    }
                if (!isAdded || activity.isFinishing || activity.isDestroyed) return@launch
                if (sessions.isEmpty()) {
                    adapter.submit(emptyList())
                    binding.tvEmpty.visibility = View.VISIBLE
                } else {
                    adapter.submit(sessions)
                    binding.tvEmpty.visibility = View.GONE
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "加载失败")
                AppToast.show(activity, msg.take(60))
            } finally {
                loading = false
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    private inner class SessionAdapter : RecyclerView.Adapter<SessionAdapter.Vh>() {
        private val items = ArrayList<BiliApi.MessageSession>()

        fun submit(list: List<BiliApi.MessageSession>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
            val ctx = parent.context
            val density = ctx.resources.displayMetrics.density
            fun dp(v: Int): Int = (v * density).toInt()
            val root =
                LinearLayout(ctx).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = androidx.core.content.ContextCompat.getDrawable(ctx, R.drawable.blbl_focus_bg_round)
                    isFocusable = true
                    isClickable = true
                }
            val row = LinearLayout(ctx).apply { orientation = LinearLayout.HORIZONTAL }
            val avatar = ImageView(ctx).apply {
                layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            val col = LinearLayout(ctx).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(12)
                }
            }
            val name = TextView(ctx).apply {
                textSize = 16f
                setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.blbl_text))
                maxLines = 1
            }
            val last = TextView(ctx).apply {
                textSize = 13f
                setTextColor(androidx.core.content.ContextCompat.getColor(ctx, R.color.blbl_text_secondary))
                maxLines = 1
                setPadding(0, dp(4), 0, 0)
            }
            val badge = TextView(ctx).apply {
                textSize = 11f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(8), dp(2), dp(8), dp(2))
                gravity = Gravity.CENTER
                visibility = View.GONE
            }
            col.addView(name)
            col.addView(last)
            row.addView(avatar)
            row.addView(col)
            root.addView(row)
            return Vh(root, avatar, name, last, badge)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            val session = items[position]
            holder.name.text = session.talkerName.ifBlank { "用户${session.talkerId}" }
            holder.last.text = session.lastMsgText.ifBlank { if (session.lastMsgType == 2) "[图片]" else "" }
            holder.badge.visibility = if (session.unreadCount > 0) View.VISIBLE else View.GONE
            holder.badge.text = if (session.unreadCount > 99) "99+" else session.unreadCount.toString()
            holder.badge.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFFB7299.toInt())
            }
            holder.avatar.setImageResource(R.drawable.ic_nav_msg)
            session.talkerFace?.let { face ->
                ImageLoader.loadInto(holder.avatar, ImageUrl.avatar(face))
            }
            holder.root.setOnClickListener {
                startActivity(
                    Intent(requireContext(), ChatActivity::class.java)
                        .putExtra(ChatActivity.EXTRA_TALKER_ID, session.talkerId)
                        .putExtra(ChatActivity.EXTRA_TALKER_NAME, session.talkerName.ifBlank { "用户${session.talkerId}" }),
                )
            }
        }

        inner class Vh(
            val root: View,
            val avatar: ImageView,
            val name: TextView,
            val last: TextView,
            val badge: TextView,
        ) : RecyclerView.ViewHolder(root)
    }
}
