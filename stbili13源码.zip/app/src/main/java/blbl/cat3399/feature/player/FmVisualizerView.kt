package blbl.cat3399.feature.player

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.util.AttributeSet
import android.view.View
import kotlin.math.abs
import kotlin.math.sin


class FmVisualizerView @JvmOverloads constructor(
    context: Context,
    attrs: AttributeSet? = null,
) : View(context, attrs) {

    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var barCount = 48
    private val levels = FloatArray(barCount)
    private val targets = FloatArray(barCount)
    private var playing = false
    private var seed = 0L

    fun setPlaying(playing: Boolean) {
        if (this.playing == playing) return
        this.playing = playing
        if (playing) {
            seed = System.currentTimeMillis()
            postInvalidateOnAnimation()
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 1f || h <= 1f) return
        val gap = w * 0.010f
        val barW = (w - gap * (barCount - 1)) / barCount
        val midY = h * 0.5f
        val maxH = h * 0.92f
        val t = System.currentTimeMillis()

        if (playing) {
            
            for (i in 0 until barCount) {
                if (i % 7 == 0 || (t - seed) / 240L % 3L == (i % 3).toLong()) {
                    val wave = (sin(t / 180.0 + i * 1.7) * 0.5 + 0.5).toFloat()
                    targets[i] = (0.18f + wave * 0.82f) * (0.55f + 0.45f * ((i * 7919L % 17L) / 16f))
                }
                levels[i] += (targets[i] - levels[i]) * 0.18f
                if (abs(levels[i] - targets[i]) < 0.02f) levels[i] = targets[i]
            }
        } else {
            for (i in 0 until barCount) {
                levels[i] *= 0.88f
            }
        }

        for (i in 0 until barCount) {
            val barH = levels[i].coerceIn(0.05f, 1f) * maxH
            val x = i * (barW + gap)
            paint.color = accentColor
            val top = midY - barH / 2f
            canvas.drawRoundRect(x, top, x + barW, top + barH, barW / 2f, barW / 2f, paint)
        }
        if (playing) postInvalidateOnAnimation()
    }

    private var accentColor: Int = 0xFFFF7299.toInt()

    fun setAccentColor(color: Int) {
        if (accentColor == color) return
        accentColor = color
        invalidate()
    }
}
