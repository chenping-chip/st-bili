package blbl.cat3399.feature.player

import android.content.Intent
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.model.VideoCard
import blbl.cat3399.core.ui.AppToast
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


internal fun PlayerActivity.openShareSheet() {
    val bvid = currentBvid.trim().takeIf { it.isNotBlank() }
    if (bvid == null) {
        AppToast.show(this, "当前视频暂不支持分享")
        return
    }
    val title = currentMediaTitleForShare().takeIf { it.isNotBlank() } ?: bvid
    val url = "https://www.bilibili.com/video/$bvid"
    val text = "$title $url"

    val sendIntent =
        Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
    runCatching {
        startActivity(Intent.createChooser(sendIntent, "分享视频"))
    }.onFailure {
        AppToast.show(this, "未找到可用的分享应用")
    }
}


internal fun PlayerActivity.onDislikeCurrentVideo() {
    val bvid = currentBvid.trim().takeIf { it.isNotBlank() }
    val aid = currentAid?.takeIf { it > 0L }
    if (bvid == null && aid == null) {
        AppToast.show(this, "当前视频暂不支持该操作")
        return
    }
    val ownerMid = currentUpMid?.takeIf { it > 0L }
    if (aid == null || ownerMid == null) {
        AppToast.show(this, "暂未获取到视频信息")
        return
    }
    val requestBvid = bvid.orEmpty()

    val card =
        VideoCard(
            bvid = requestBvid,
            cid = currentCid?.takeIf { it > 0L },
            aid = aid,
            title = currentMediaTitleForShare(),
            coverUrl = "",
            durationSec = 0,
            ownerName = "",
            ownerFace = null,
            ownerMid = ownerMid,
            view = null,
            danmaku = null,
            pubDate = null,
            pubDateText = null,
        )

    lifecycleScope.launch {
        try {
            withContext(Dispatchers.IO) {
                BiliApi.videoFeedbackDislike(card = card)
            }
            AppToast.show(this@onDislikeCurrentVideo, "已标记不感兴趣")
            
            playRecommendedNext(userInitiated = false)
        } catch (t: Throwable) {
            if (t is CancellationException) throw t
            AppToast.show(this@onDislikeCurrentVideo, "操作失败：${t.message.orEmpty().take(60)}")
        }
    }
}

internal fun PlayerActivity.currentMediaTitleForShare(): String =
    runCatching { binding.tvTitle.text?.toString().orEmpty() }.getOrNull().orEmpty()
