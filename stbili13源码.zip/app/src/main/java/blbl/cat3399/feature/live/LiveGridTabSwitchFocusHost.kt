package blbl.cat3399.feature.live

import blbl.cat3399.core.ui.TabContentSwitchFocusHost


interface LiveGridTabSwitchFocusHost : TabContentSwitchFocusHost {
    fun requestFocusCurrentPageFirstCardFromContentSwitch(): Boolean

    override fun requestFocusCurrentPagePrimaryItemFromContentSwitch(): Boolean = requestFocusCurrentPageFirstCardFromContentSwitch()
}
