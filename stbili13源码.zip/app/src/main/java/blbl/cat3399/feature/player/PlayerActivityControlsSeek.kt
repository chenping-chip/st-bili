package blbl.cat3399.feature.player

import android.os.SystemClock
import android.view.KeyEvent
import android.view.View
import android.view.ViewConfiguration
import androidx.constraintlayout.widget.ConstraintSet
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.R
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import blbl.cat3399.feature.player.engine.BlblPlayerEngine
import blbl.cat3399.feature.player.engine.PlayerEngineKind
import java.util.Locale
import kotlin.math.roundToInt
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

internal fun shouldShowPlayerOsd(
    requestedVisible: Boolean,
    hasOverlayPanel: Boolean,
    touchLocked: Boolean,
): Boolean = requestedVisible && !hasOverlayPanel && !touchLocked

internal fun PlayerActivity.seekRelative(deltaMs: Long) {
    seekRelative(deltaMs, danmakuImmediate = true)
}

internal fun PlayerActivity.seekRelative(deltaMs: Long, danmakuImmediate: Boolean) {
    val exo = player ?: return
    val duration = exo.duration.takeIf { it > 0 } ?: Long.MAX_VALUE
    val next = (exo.currentPosition + deltaMs).coerceIn(0L, duration)
    exo.seekTo(next)
    requestDanmakuSegmentsForPosition(next, immediate = danmakuImmediate)
}

internal fun PlayerActivity.startProgressLoop() {
    progressJob?.cancel()
    progressJob = lifecycleScope.launch {
        while (isActive) {
            updateProgressUi()
            delay(250)
        }
    }
}

internal fun PlayerActivity.toggleControls() {
    if (isTouchLocked()) return
    val willShow = osdMode == PlayerActivity.OsdMode.Hidden
    if (!willShow) {
        binding.settingsPanel.visibility = View.GONE
        binding.commentsPanel.visibility = View.GONE
    }
    setControlsVisible(willShow)
}

internal fun PlayerActivity.setControlsVisible(visible: Boolean) {
    val show =
        shouldShowPlayerOsd(
            requestedVisible = visible,
            hasOverlayPanel = isOverlayPanelVisible(),
            touchLocked = isTouchLocked(),
        )
    if (!show && osdMode == PlayerActivity.OsdMode.Full) {
        rememberOsdFocusBeforeHide()
    }
    if (!show) PlayerOsdHoverLabel.hide(binding)
    seekOsdHideJob?.cancel()
    seekOsdHideJob = null
    seekOsdToken = 0L
    transientSeekOsdVisible = false
    osdMode = if (show) PlayerActivity.OsdMode.Full else PlayerActivity.OsdMode.Hidden

    binding.controlsRow.visibility = if (show) View.VISIBLE else View.GONE
    binding.tvTime.visibility = if (show) View.VISIBLE else View.GONE
    updateTopBarUi()
    updateUpQuickCardUi()
    binding.bottomBar.visibility = if (show) View.VISIBLE else View.GONE
    if (show) {
        applyBottomBarFullLayout()
    } else {
        hideVideoShotPreviewNow()
    }
    syncPlayerInfoPanelVisibility()
    updatePersistentBottomProgressBarVisibility()
    onTouchOverlayStateChanged()
    if (show) noteUserInteraction() else autoHideJob?.cancel()
}

internal fun PlayerActivity.isTopBarContentVisible(): Boolean = osdMode != PlayerActivity.OsdMode.Hidden

internal fun PlayerActivity.updateClockVisibility() {
    val showClock = isTopBarContentVisible() || BiliClient.prefs.playerPersistentClockEnabled
    binding.tvClock.visibility = if (showClock) View.VISIBLE else View.GONE
}

internal fun PlayerActivity.updateTopBarUi() {
    val showContent = isTopBarContentVisible()
    binding.topBar.visibility = View.VISIBLE
    if (showContent) {
        binding.topBar.setBackgroundResource(R.drawable.bg_player_top_scrim_strong)
    } else {
        binding.topBar.background = null
    }
    val contentVisibility = if (showContent) View.VISIBLE else View.INVISIBLE
    binding.btnBack.visibility = contentVisibility
    binding.titleRow.visibility = contentVisibility
    updateClockVisibility()
}

internal fun PlayerActivity.showSeekOsd() {
    if (isOverlayPanelVisible()) return
    if (osdMode == PlayerActivity.OsdMode.Full) {
        
        noteUserInteraction()
        return
    }

    val exo = player
    if (exo != null) {
        val duration = exo.duration.takeIf { it > 0 } ?: currentViewDurationMs ?: 0L
        val pos = resolvePlayerUiPositionMs(exo.currentPosition, holdScrubPreviewPosMs, keySeekPreviewPosMs)
        val bufPos = resolveSeekUiBufferedPositionMs(exo.bufferedPosition, pos)
        showSeekOsd(posMs = pos, durationMs = duration, bufferedPosMs = bufPos)
        return
    }

    transientSeekOsdVisible = true
    updatePersistentBottomProgressBarVisibility()
    scheduleHideSeekOsd()
}

internal fun PlayerActivity.showSeekOsd(posMs: Long, durationMs: Long, bufferedPosMs: Long) {
    if (isOverlayPanelVisible()) return
    val duration = durationMs.coerceAtLeast(0L)
    val pos = posMs.coerceAtLeast(0L)
    val bufPos = bufferedPosMs.coerceAtLeast(0L)

    val hasVideoShot =
        currentVideoShot != null &&
            BiliClient.prefs.playerVideoShotPreviewSize != AppPrefs.PLAYER_VIDEOSHOT_PREVIEW_SIZE_OFF

    if (osdMode == PlayerActivity.OsdMode.Full) {
        
        binding.tvTime.text = "${formatHms(pos)} / ${formatHms(duration)}"
        val enabled = duration > 0L
        binding.seekProgress.isEnabled = enabled
        if (enabled) {
            val bufferedProgress =
                ((bufPos.toDouble() / duration.toDouble()) * PlayerActivity.SEEK_MAX)
                    .toInt()
                    .coerceIn(0, PlayerActivity.SEEK_MAX)
            val pNow = ((pos.toDouble() / duration.toDouble()) * PlayerActivity.SEEK_MAX).toInt().coerceIn(0, PlayerActivity.SEEK_MAX)
            binding.seekProgress.secondaryProgress = bufferedProgress
            binding.seekProgress.progress = pNow

            
            if (hasVideoShot) {
                showVideoShotPreviewForSeek(pNow, PlayerActivity.SEEK_MAX, pos, binding.seekProgress)
            }
        }
        noteUserInteraction()
        return
    }

    binding.tvSeekOsdTime.text = "${formatHms(pos)} / ${formatHms(duration)}"

    val enabled = duration > 0L
    binding.progressSeekOsd.isEnabled = enabled
    if (enabled) {
        val bufferedProgress =
            ((bufPos.toDouble() / duration.toDouble()) * PlayerActivity.SEEK_MAX)
                .toInt()
                .coerceIn(0, PlayerActivity.SEEK_MAX)
        val pNow = ((pos.toDouble() / duration.toDouble()) * PlayerActivity.SEEK_MAX).toInt().coerceIn(0, PlayerActivity.SEEK_MAX)
        binding.progressSeekOsd.secondaryProgress = bufferedProgress
        binding.progressSeekOsd.progress = pNow

        
        if (hasVideoShot) {
            showVideoShotPreviewForSeek(pNow, PlayerActivity.SEEK_MAX, pos, binding.progressSeekOsd)
        }
    } else {
        binding.progressSeekOsd.secondaryProgress = 0
        binding.progressSeekOsd.progress = 0
        hideVideoShotPreviewNow()
    }

    transientSeekOsdVisible = true
    updatePersistentBottomProgressBarVisibility()
    scheduleHideSeekOsd()
}

internal fun PlayerActivity.ensureBottomBarConstraintSets() {
    if (bottomBarFullConstraints != null) return
    bottomBarFullConstraints =
        ConstraintSet().also { set ->
            set.clone(binding.bottomBar)
            set.setVisibility(R.id.controls_row, View.VISIBLE)
            set.setVisibility(R.id.tv_time, View.VISIBLE)
        }
}

internal fun PlayerActivity.applyBottomBarFullLayout() {
    ensureBottomBarConstraintSets()
    bottomBarFullConstraints?.applyTo(binding.bottomBar)
}

internal fun PlayerActivity.scheduleHideSeekOsd() {
    seekOsdHideJob?.cancel()
    val token = SystemClock.uptimeMillis()
    seekOsdToken = token
    seekOsdHideJob =
        lifecycleScope.launch {
            delay(PlayerActivity.SEEK_OSD_HIDE_DELAY_MS)
            if (seekOsdToken != token) return@launch
            transientSeekOsdVisible = false

            hideVideoShotPreviewNow()

            updatePersistentBottomProgressBarVisibility()
        }
}

internal fun PlayerActivity.cancelVideoShotPreviewHide() {
    videoShotPreviewHideJob?.cancel()
    videoShotPreviewHideJob = null
}

internal fun PlayerActivity.hideVideoShotPreviewNow() {
    cancelVideoShotPreviewHide()
    videoShotPreviewRequestId += 1L
    binding.videoShotPreview.visibility = View.GONE
    videoShotFetchJob?.cancel()
}

internal fun PlayerActivity.scheduleHideVideoShotPreviewAfterSeek() {
    videoShotPreviewHideJob?.cancel()
    videoShotPreviewHideJob =
        lifecycleScope.launch {
            delay(PlayerActivity.VIDEOSHOT_PREVIEW_HIDE_AFTER_SEEK_MS)
            videoShotPreviewRequestId += 1L
            binding.videoShotPreview.visibility = View.GONE
            videoShotFetchJob?.cancel()
            videoShotPreviewHideJob = null
        }
}

internal fun PlayerActivity.showVideoShotPreviewForSeek(
    progress: Int,
    max: Int,
    positionMs: Long,
    trackView: View,
) {
    cancelVideoShotPreviewHide()
    updateVideoShotPreview(progress, max, positionMs, trackView)
}

internal fun PlayerActivity.updatePersistentBottomProgressBarVisibility() {
    val enabled = session.persistentBottomProgressEnabled
    val showControls = osdMode != PlayerActivity.OsdMode.Hidden || isOverlayPanelVisible()
    val persistentV = if (enabled && !showControls && !transientSeekOsdVisible) View.VISIBLE else View.GONE
    if (binding.progressPersistentBottom.visibility != persistentV) binding.progressPersistentBottom.visibility = persistentV

    val seekOsdV = if (!showControls && transientSeekOsdVisible) View.VISIBLE else View.GONE
    if (binding.seekOsdContainer.visibility != seekOsdV) binding.seekOsdContainer.visibility = seekOsdV
}

internal fun PlayerActivity.restartAutoHideTimer() {
    autoHideJob?.cancel()
    val exo = player ?: return
    if (isTouchLocked()) return
    if (osdMode != PlayerActivity.OsdMode.Full) return
    if (isOverlayPanelVisible()) return
    if (scrubbing) return
    if (!exo.isPlaying) return
    val token = lastInteractionAtMs
    autoHideJob = lifecycleScope.launch {
        delay(PlayerActivity.AUTO_HIDE_MS)
        if (token != lastInteractionAtMs) return@launch
        setControlsVisible(false)
    }
}

internal fun PlayerActivity.noteUserInteraction() {
    lastInteractionAtMs = SystemClock.uptimeMillis()
    restartAutoHideTimer()
}

internal fun PlayerActivity.cancelDeferredKeySeekPreview(resetScrubbing: Boolean = true) {
    keyScrubEndJob?.cancel()
    keyScrubEndJob = null
    keyScrubPendingSeekToMs = null
    keySeekPreviewPosMs = null
    if (resetScrubbing) scrubbing = false
    clearKeySeekBufferingOverlaySuppression()
    updateBufferingOverlay()
}

private fun PlayerActivity.commitDeferredKeySeekPreview() {
    val pendingSeekTo = keyScrubPendingSeekToMs
    keyScrubEndJob?.cancel()
    keyScrubEndJob = null
    keyScrubPendingSeekToMs = null
    keySeekPreviewPosMs = null
    scrubbing = false

    val engine = player
    if (pendingSeekTo != null && engine != null) {
        engine.seekTo(pendingSeekTo)
        requestDanmakuSegmentsForPosition(pendingSeekTo, immediate = true)
        requestReportProgressOnce(reason = "user_seek_end")
        val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs ?: 0L
        if (duration > 0L) {
            showSeekOsd(posMs = pendingSeekTo, durationMs = duration, bufferedPosMs = engine.bufferedPosition)
            scheduleHideVideoShotPreviewAfterSeek()
        }
    }

    updateBufferingOverlay()
    restartAutoHideTimer()
}

internal fun PlayerActivity.scheduleKeyScrubEnd(delayMs: Long = PlayerActivity.KEY_SCRUB_END_DELAY_MS) {
    keyScrubEndJob?.cancel()
    keyScrubEndJob =
        lifecycleScope.launch {
            delay(delayMs)
            commitDeferredKeySeekPreview()
        }
}

internal fun PlayerActivity.hasControlsFocus(): Boolean =
    binding.topBar.hasFocus() ||
        binding.cardUpQuick.hasFocus() ||
        binding.bottomBar.hasFocus() ||
        binding.sponsorSubmitPanel.hasFocus() ||
        binding.playerInfoPanel.hasFocus() ||
        binding.settingsPanel.hasFocus() ||
        binding.commentsPanel.hasFocus()

internal fun PlayerActivity.hasControlsFocusOutsideSeekBar(): Boolean {
    if (osdMode != PlayerActivity.OsdMode.Full) return false
    return binding.topBar.hasFocus() ||
        binding.cardUpQuick.hasFocus() ||
        (binding.bottomBar.hasFocus() && !binding.seekProgress.isFocused)
}

private fun PlayerActivity.rememberOsdFocusBeforeHide() {
    val focused = currentFocus ?: return
    val focusIsInOsd =
        binding.topBar.hasFocus() ||
            binding.cardUpQuick.hasFocus() ||
            binding.bottomBar.hasFocus()
    if (focusIsInOsd) osdFocusReturn.capture(focused)
}

internal fun PlayerActivity.restoreLastOsdFocusOr(fallback: () -> Unit) {
    binding.root.post {
        if (!osdFocusReturn.restoreAndClear(postOnFail = false)) fallback()
    }
}

internal fun PlayerActivity.focusFirstControl() {
    binding.btnPlayPause.post { binding.btnPlayPause.requestFocus() }
}

private fun PlayerActivity.requestFocusControlNow(view: View?): Boolean {
    val target = view ?: return false
    if (target.visibility != View.VISIBLE) return false
    if (!target.isEnabled) return false
    if (!target.isFocusable) return false
    return target.requestFocus()
}

internal fun PlayerActivity.focusDownKeyOsdTargetControl() {
    val target =
        when (BiliClient.prefs.playerDownKeyOsdFocusTarget) {
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_PREV -> binding.btnPrev
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_NEXT -> binding.btnNext
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_SUBTITLE -> binding.btnSubtitle
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_DANMAKU -> binding.btnDanmaku
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_COMMENTS -> binding.btnComments
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_DETAIL -> binding.btnDetail
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_UP -> binding.btnUp
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_LIKE -> binding.btnLike
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_COIN -> binding.btnCoin
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_FAV -> binding.btnFav
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_LIST_PANEL -> binding.btnListPanel
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_SPONSOR_SUBMIT -> binding.btnSponsorSubmit
            AppPrefs.PLAYER_DOWN_KEY_OSD_FOCUS_ADVANCED -> binding.btnAdvanced
            else -> binding.btnPlayPause
        }

    binding.controlsRow.post {
        if (osdFocusReturn.restoreAndClear(postOnFail = false)) return@post
        if (requestFocusControlNow(target)) return@post
        if (requestFocusControlNow(binding.btnPlayPause)) return@post
        focusFirstControl()
    }
}

internal fun PlayerActivity.focusSeekBar() {
    binding.seekProgress.post { binding.seekProgress.requestFocus() }
}

internal fun PlayerActivity.focusAdvancedControl() {
    binding.btnAdvanced.post { binding.btnAdvanced.requestFocus() }
}

internal fun PlayerActivity.focusSettingsPanel() {
    binding.recyclerSettings.post {
        val child = binding.recyclerSettings.getChildAt(0)
        if (child != null) {
            child.requestFocus()
            return@post
        }

        binding.recyclerSettings.scrollToPosition(0)
        binding.recyclerSettings.post {
            val first = binding.recyclerSettings.getChildAt(0)
            (first ?: binding.recyclerSettings).requestFocus()
        }
    }
}

internal fun PlayerActivity.smartSeek(direction: Int) {
    smartSeek(direction, showControls = true, hintKind = SeekHintKind.Step)
}

internal enum class SeekHintKind {
    Step,
    Hold,
}

internal fun PlayerActivity.isSeekKey(keyCode: Int): Boolean {
    return when (keyCode) {
        KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_MEDIA_REWIND,
        KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        KeyEvent.KEYCODE_BUTTON_L1,
        KeyEvent.KEYCODE_BUTTON_L2,
        KeyEvent.KEYCODE_BUTTON_R1,
        KeyEvent.KEYCODE_BUTTON_R2,
        -> true

        else -> false
    }
}

internal fun PlayerActivity.clearKeySeekPending() {
    keySeekHoldDetectJob?.cancel()
    keySeekHoldDetectJob = null
    keySeekPendingKeyCode = 0
    keySeekPendingDirection = 0
}

internal fun PlayerActivity.beginKeySeekPending(keyCode: Int, direction: Int, showControls: Boolean) {
    clearKeySeekPending()
    keySeekPendingKeyCode = keyCode
    keySeekPendingDirection = direction

    
    
    
    val timeoutMs = ViewConfiguration.getLongPressTimeout().toLong()
    keySeekHoldDetectJob =
        lifecycleScope.launch {
            delay(timeoutMs)
            if (keySeekPendingKeyCode != keyCode || keySeekPendingDirection != direction) return@launch
            if (holdSeekJob != null) return@launch
            if (direction < 0) {
                
                startHoldScrub(direction = direction, showControls = showControls)
            } else if (binding.seekProgress.isFocused) {
                
                
                startHoldScrub(direction = direction, showControls = showControls)
            } else {
                startHoldSeek(direction = direction, showControls = showControls)
            }
            
            clearKeySeekPending()
        }
}

internal fun PlayerActivity.holdSeekUsesProgressPreview(direction: Int): Boolean {
    if (direction < 0) return true
    return when (BiliClient.prefs.playerHoldSeekMode) {
        AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB,
        AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB_FIXED_TIME,
        -> true

        else -> false
    }
}

internal fun PlayerActivity.smartSeek(direction: Int, showControls: Boolean, hintKind: SeekHintKind) {
    val now = SystemClock.uptimeMillis()
    val sameDir = direction == smartSeekDirection
    val within = now - smartSeekLastAtMs <= PlayerActivity.SMART_SEEK_WINDOW_MS
    val continued = sameDir && within
    smartSeekDirection = direction
    smartSeekLastAtMs = now

    if (showControls) {
        if (osdMode != PlayerActivity.OsdMode.Full && !isSidePanelVisible()) setControlsVisible(true) else noteUserInteraction()
    } else {
        noteUserInteraction()
    }

    val step = smartSeekStepMs()
    val engine = player ?: return
    val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs
    if (duration == null || duration <= 0L) {
        seekRelative(step * direction)
        smartSeekTotalMs = if (continued) (smartSeekTotalMs + step) else step
        if (hintKind == SeekHintKind.Step) showSeekStepHint(direction, smartSeekTotalMs)
        return
    }

    val target =
        accumulateDeferredSeekPreviewPositionMs(
            committedPositionMs = engine.currentPosition,
            activePreviewPositionMs = keySeekPreviewPosMs,
            deltaMs = step * direction.toLong(),
            durationMs = duration,
        )
    scrubbing = true
    keySeekPreviewPosMs = target
    keyScrubPendingSeekToMs = target
    suppressBufferingOverlayDuringKeySeek(PlayerActivity.KEY_STEP_SEEK_COMMIT_DELAY_MS)
    showSeekOsd(
        posMs = target,
        durationMs = duration,
        bufferedPosMs = resolveSeekUiBufferedPositionMs(engine.bufferedPosition, target),
    )
    updateBufferingOverlay()
    scheduleKeyScrubEnd(delayMs = PlayerActivity.KEY_STEP_SEEK_COMMIT_DELAY_MS)
    smartSeekTotalMs = if (continued) (smartSeekTotalMs + step) else step
    if (hintKind == SeekHintKind.Step) showSeekStepHint(direction, smartSeekTotalMs)
}

internal fun PlayerActivity.smartSeekStepMs(): Long {
    return BiliClient.prefs.playerShortSeekStepSeconds * 1_000L
}

internal fun PlayerActivity.startHoldSeek(direction: Int, showControls: Boolean) {
    
    if (direction <= 0) return
    if (holdSeekJob?.isActive == true) return
    val engine = player ?: return

    if (showControls) {
        if (osdMode != PlayerActivity.OsdMode.Full && !isSidePanelVisible()) setControlsVisible(true) else noteUserInteraction()
    } else {
        noteUserInteraction()
    }

    val holdSpeed = holdSeekSpeed()
    val holdMode = BiliClient.prefs.playerHoldSeekMode
    if (holdMode == AppPrefs.PLAYER_HOLD_SEEK_MODE_SPEED && keyScrubPendingSeekToMs != null) {
        commitDeferredKeySeekPreview()
    }
    holdPrevSpeed = engine.playbackSpeed
    holdPrevPlayWhenReady = engine.playWhenReady
    holdScrubPreviewPosMs = null
    if (holdMode == AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB || holdMode == AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB_FIXED_TIME) {
        val fixedStepMs =
            if (holdMode == AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB_FIXED_TIME) {
                holdScrubFixedStepMs()
            } else {
                null
            }
        startHoldScrubSeek(engine = engine, direction = direction, speed = holdSpeed, fixedStepMs = fixedStepMs)
        return
    }
    showSeekHoldHint(direction, holdSpeed)
    engine.setPlaybackSpeed(holdSpeed)
    engine.playWhenReady = true
    holdSeekJob = lifecycleScope.launch { kotlinx.coroutines.awaitCancellation() }
}

internal fun PlayerActivity.startHoldScrub(direction: Int, showControls: Boolean) {
    if (holdSeekJob?.isActive == true) return
    val engine = player ?: return

    if (showControls) {
        if (osdMode != PlayerActivity.OsdMode.Full && !isSidePanelVisible()) setControlsVisible(true) else noteUserInteraction()
    } else {
        noteUserInteraction()
    }

    val holdSpeed = holdSeekSpeed()
    val holdMode = BiliClient.prefs.playerHoldSeekMode
    holdPrevSpeed = engine.playbackSpeed
    holdPrevPlayWhenReady = engine.playWhenReady
    holdScrubPreviewPosMs = null
    val fixedStepMs =
        if (holdMode == AppPrefs.PLAYER_HOLD_SEEK_MODE_SCRUB_FIXED_TIME) {
            holdScrubFixedStepMs()
        } else {
            null
        }
    startHoldScrubSeek(engine = engine, direction = direction, speed = holdSpeed, fixedStepMs = fixedStepMs)
}

internal fun PlayerActivity.startHoldScrubSeek(engine: BlblPlayerEngine, direction: Int, speed: Float, fixedStepMs: Long?) {
    val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs ?: 0L
    if (duration <= 0L) {
        
        if (direction <= 0) return
        showSeekHoldHint(direction, speed)
        engine.setPlaybackSpeed(speed)
        engine.playWhenReady = true
        holdSeekJob = lifecycleScope.launch { kotlinx.coroutines.awaitCancellation() }
        return
    }

    val initial = resolvePlayerUiPositionMs(engine.currentPosition, holdScrubPreviewPosMs, keySeekPreviewPosMs).coerceIn(0L, duration)
    cancelDeferredKeySeekPreview(resetScrubbing = false)
    scrubbing = true

    engine.pause()

    holdScrubPreviewPosMs = initial
    showSeekOsd(
        posMs = initial,
        durationMs = duration,
        bufferedPosMs = resolveSeekUiBufferedPositionMs(engine.bufferedPosition, initial),
    )

    val tickMs = PlayerActivity.HOLD_SCRUB_TICK_MS
    val stepMs =
        fixedStepMs
            ?.let {
                (it.coerceAtLeast(1L).toDouble() * tickMs.toDouble() / PlayerActivity.HOLD_SCRUB_FIXED_STEP_BASE_TICK_MS)
                    .roundToInt()
                    .toLong()
            }
            ?: holdScrubStepMs(durationMs = duration, tickMs = tickMs)
    val deltaMs = stepMs.coerceAtLeast(1L) * direction.toLong()
    holdSeekJob =
        lifecycleScope.launch {
            while (isActive) {
                val current = holdScrubPreviewPosMs ?: initial
                val next = (current + deltaMs).coerceIn(0L, duration)
                holdScrubPreviewPosMs = next
                showSeekOsd(
                    posMs = next,
                    durationMs = duration,
                    bufferedPosMs = resolveSeekUiBufferedPositionMs(engine.bufferedPosition, next),
                )
                delay(tickMs)
            }
        }
}

internal fun PlayerActivity.stopHoldSeek() {
    val engine = player
    val scrubTarget = holdScrubPreviewPosMs
    holdScrubPreviewPosMs = null
    if (scrubTarget != null) {
        scrubbing = false
        keyScrubEndJob?.cancel()
        keyScrubEndJob = null
    }
    holdSeekJob?.cancel()
    holdSeekJob = null
    if (engine != null) {
        engine.setPlaybackSpeed(holdPrevSpeed)
        if (scrubTarget != null) {
            engine.seekTo(scrubTarget)
            val duration = engine.duration.takeIf { it > 0 } ?: currentViewDurationMs ?: 0L
            if (duration > 0L) {
                showSeekOsd(posMs = scrubTarget, durationMs = duration, bufferedPosMs = engine.bufferedPosition)
                scheduleHideVideoShotPreviewAfterSeek()
            }
        }
        engine.playWhenReady = holdPrevPlayWhenReady
        val pos = (scrubTarget ?: engine.currentPosition).coerceAtLeast(0L)
        requestDanmakuSegmentsForPosition(pos, immediate = true)
    }
    scheduleHideSeekHint()
}

internal fun PlayerActivity.showSeekStepHint(direction: Int, totalMs: Long) {
    val sec = (kotlin.math.abs(totalMs) / 1000L).coerceAtLeast(1L)
    val text = if (direction > 0) "快进 ${sec}s" else "后退 ${sec}s"
    showSeekHint(text, hold = false)
}

internal fun PlayerActivity.showSeekHoldHint(direction: Int, speed: Float) {
    val s = holdSeekSpeedText(speed)
    val text = if (direction > 0) "快进 x$s" else "后退 x$s"
    showSeekHint(text, hold = true)
}

internal fun PlayerActivity.holdSeekSpeed(): Float {
    val v = BiliClient.prefs.playerHoldSeekSpeed
    val fallback = AppPrefs.PLAYER_HOLD_SEEK_SPEED_DEFAULT
    if (!v.isFinite()) return fallback
    return v.coerceIn(1.5f, 4.0f)
}

internal fun PlayerActivity.holdSeekSpeedText(speed: Float): String {
    val v = speed.takeIf { it.isFinite() } ?: AppPrefs.PLAYER_HOLD_SEEK_SPEED_DEFAULT
    val fixed = String.format(Locale.US, "%.2f", v)
    return fixed.trimEnd('0').trimEnd('.')
}

internal fun PlayerActivity.holdScrubFixedStepMs(): Long {
    return BiliClient.prefs.playerHoldScrubFixedStepSeconds * 1_000L
}

internal fun PlayerActivity.holdScrubStepMs(durationMs: Long, tickMs: Long): Long {
    val duration = durationMs.coerceAtLeast(0L)
    if (duration <= 0L) return 0L
    val tick = tickMs.coerceAtLeast(1L)
    val traverseMs = (BiliClient.prefs.playerHoldScrubTraverseSeconds * 1_000L).coerceAtLeast(tick)
    val step = (duration.toDouble() * tick.toDouble() / traverseMs.toDouble()).roundToInt().toLong()
    return step.coerceAtLeast(1L)
}

internal fun accumulateDeferredSeekPreviewPositionMs(
    committedPositionMs: Long,
    activePreviewPositionMs: Long?,
    deltaMs: Long,
    durationMs: Long,
): Long {
    val duration = durationMs.coerceAtLeast(0L)
    val base = (activePreviewPositionMs ?: committedPositionMs).coerceAtLeast(0L)
    return (base + deltaMs).coerceIn(0L, duration)
}

internal fun resolvePlayerUiPositionMs(
    committedPositionMs: Long,
    holdPreviewPositionMs: Long?,
    deferredPreviewPositionMs: Long?,
): Long {
    return (holdPreviewPositionMs ?: deferredPreviewPositionMs ?: committedPositionMs).coerceAtLeast(0L)
}

internal fun PlayerActivity.resolveSeekUiBufferedPositionMs(
    committedBufferedPositionMs: Long,
    uiPositionMs: Long,
): Long {
    val buffered = committedBufferedPositionMs.coerceAtLeast(0L)
    val hasPreview = holdScrubPreviewPosMs != null || keySeekPreviewPosMs != null
    if (hasPreview && player?.kind == PlayerEngineKind.IjkPlayer) {
        return uiPositionMs.coerceAtLeast(0L)
    }
    return buffered
}

internal fun PlayerActivity.showSeekHint(
    text: String,
    hold: Boolean,
    hideDelayMs: Long = PlayerActivity.SEEK_HINT_HIDE_DELAY_MS,
) {
    
    
    if (autoNextHintVisible) {
        val locked = autoNextHintText
        if (!locked.isNullOrEmpty() && text != locked) return
    }
    binding.tvSeekHint.text = text
    binding.tvSeekHint.visibility = View.VISIBLE
    seekHintJob?.cancel()
    if (!hold) scheduleHideSeekHint(hideDelayMs)
}

internal fun PlayerActivity.scheduleHideSeekHint(hideDelayMs: Long = PlayerActivity.SEEK_HINT_HIDE_DELAY_MS) {
    
    
    
    if (autoNextHintVisible) return
    seekHintJob?.cancel()
    seekHintJob =
        lifecycleScope.launch {
            delay(hideDelayMs)
            binding.tvSeekHint.visibility = View.GONE
        }
}

internal fun PlayerActivity.edgeDirection(x: Float, width: Float): Int {
    return when {
        x < width * PlayerActivity.EDGE_TAP_THRESHOLD -> -1
        x > width * (1f - PlayerActivity.EDGE_TAP_THRESHOLD) -> +1
        else -> 0
    }
}

internal fun PlayerActivity.isInteractionKey(keyCode: Int): Boolean {
    return when (keyCode) {
        KeyEvent.KEYCODE_DPAD_UP,
        KeyEvent.KEYCODE_DPAD_DOWN,
        KeyEvent.KEYCODE_DPAD_LEFT,
        KeyEvent.KEYCODE_DPAD_RIGHT,
        KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_NUMPAD_ENTER,
        KeyEvent.KEYCODE_SPACE,
        KeyEvent.KEYCODE_BACK,
        KeyEvent.KEYCODE_ESCAPE,
        KeyEvent.KEYCODE_BUTTON_A,
        KeyEvent.KEYCODE_BUTTON_B,
        KeyEvent.KEYCODE_BUTTON_L1,
        KeyEvent.KEYCODE_BUTTON_L2,
        KeyEvent.KEYCODE_BUTTON_R1,
        KeyEvent.KEYCODE_BUTTON_R2,
        KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
        KeyEvent.KEYCODE_MEDIA_PLAY,
        KeyEvent.KEYCODE_MEDIA_PAUSE,
        KeyEvent.KEYCODE_MEDIA_REWIND,
        KeyEvent.KEYCODE_MEDIA_FAST_FORWARD,
        KeyEvent.KEYCODE_MENU,
        KeyEvent.KEYCODE_SETTINGS,
        KeyEvent.KEYCODE_INFO,
        KeyEvent.KEYCODE_GUIDE,
        -> true

        else -> false
    }
}

internal fun PlayerActivity.updatePlayPauseIcon(isPlaying: Boolean) {
    binding.btnPlayPause.setImageResource(
        if (isPlaying) blbl.cat3399.R.drawable.ic_player_pause else blbl.cat3399.R.drawable.ic_player_play,
    )
}

internal fun PlayerActivity.updateVideoShotPreview(
    progress: Int,
    max: Int,
    positionMs: Long,
    trackView: View 
) {
    if (BiliClient.prefs.playerVideoShotPreviewSize == AppPrefs.PLAYER_VIDEOSHOT_PREVIEW_SIZE_OFF) {
        hideVideoShotPreviewNow()
        return
    }

    val previewView = binding.videoShotPreview
    val shot = currentVideoShot
    val cache = videoShotImageCache
    if (shot == null || cache == null) {
        hideVideoShotPreviewNow()
        return
    }
    previewView.setContentAspectRatio(
        width = currentVideoContentWidth ?: shot.fallbackAspectWidth,
        height = currentVideoContentHeight ?: shot.fallbackAspectHeight,
    )
    previewView.onFrameDrawFailure = { t ->
        disableVideoShotPreviewForCurrentVideo(reason = "draw", throwable = t)
    }

    val requestId = videoShotPreviewRequestId + 1L
    videoShotPreviewRequestId = requestId
    videoShotFetchJob?.cancel()
    previewView.visibility = if (previewView.spriteFrame == null) View.INVISIBLE else View.VISIBLE
    videoShotFetchJob = lifecycleScope.launch {
        delay(16) 
        val frame =
            try {
                shot.getSpriteFrame((positionMs / 1000).toInt(), cache)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                disableVideoShotPreviewForCurrentVideo(reason = "decode", throwable = t)
                return@launch
            }

        if (
            videoShotPreviewRequestId != requestId ||
            currentVideoShot !== shot ||
            videoShotImageCache !== cache
        ) {
            return@launch
        }

        previewView.spriteFrame = frame
        positionVideoShotPreviewX(previewView, trackView, progress, max)
        previewView.visibility = View.VISIBLE
        previewView.post {
            if (videoShotPreviewRequestId == requestId && previewView.spriteFrame === frame) {
                positionVideoShotPreviewX(previewView, trackView, progress, max)
            }
        }
    }
}

internal fun PlayerActivity.disableVideoShotPreviewForCurrentVideo(reason: String, throwable: Throwable? = null) {
    AppLog.w("Player", "disable videoShot preview reason=$reason bvid=$currentBvid cid=$currentCid", throwable)
    videoShotPreviewRequestId += 1L
    videoShotFetchJob?.cancel()
    videoShotFetchJob = null
    videoShotImageCache?.clear()
    videoShotImageCache = null
    currentVideoShot = null
    binding.videoShotPreview.spriteFrame = null
    binding.videoShotPreview.visibility = View.GONE
}

private fun positionVideoShotPreviewX(
    previewView: View,
    trackView: View,
    progress: Int,
    max: Int,
) {
    val containerWidth = trackView.width
    val previewWidth = previewView.width
    if (containerWidth <= 0 || previewWidth <= 0 || max <= 0) return

    val progressRatio = progress.toDouble() / max.toDouble()
    var rawOffset = (containerWidth * progressRatio) - (previewWidth / 2.0)
    rawOffset += trackView.left

    val minOffset = 0.0
    val parentWidth = (previewView.parent as? View)?.width ?: containerWidth
    val maxOffset = (parentWidth - previewWidth).toDouble()

    previewView.translationX = rawOffset.coerceIn(minOffset, maxOffset).toFloat()
}
