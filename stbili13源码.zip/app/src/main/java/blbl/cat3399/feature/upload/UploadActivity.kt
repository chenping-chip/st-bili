package blbl.cat3399.feature.upload

import blbl.cat3399.R
import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.KeyEvent
import android.view.View
import android.widget.TextView
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.api.UploadApi
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.popup.AppPopup
import blbl.cat3399.databinding.ActivityUploadBinding
import blbl.cat3399.databinding.ItemFileManagerBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale


class UploadActivity : AppCompatActivity() {
    private var _binding: ActivityUploadBinding? = null
    private val binding get() = _binding!!

    private enum class Mode { VIDEO, REPOST, DRAW, ARTICLE }

    private var mode = Mode.VIDEO
    private var selectedVideoPath: String? = null
    private val selectedImages = ArrayList<String>()

    private var selectedTid = 0
    private var selectedArticleCover: String? = null
    private var selectedTidName = ""

    
    private lateinit var fmAdapter: FmAdapter
    private var currentDir: File? = null
    private val rootDir: File = Environment.getExternalStorageDirectory()

    private val videoExtensions =
        setOf(
            "mp4", "mkv", "webm", "avi", "mov", "flv", "wmv", "m4v", "3gp", "ts", "rmvb", "rm", "mpeg", "mpg",
        )
    private val imageExtensions = setOf("jpg", "jpeg", "png", "gif", "webp", "bmp")

    private val captureLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode != Activity.RESULT_OK) return@registerForActivityResult
            val uri = result.data?.data
            if (uri == null) {
                AppToast.show(this, "未获取到拍摄的视频")
                return@registerForActivityResult
            }
            lifecycleScope.launch {
                val path = copyUriToCache(uri, "captured_video_${System.currentTimeMillis()}.mp4")
                if (path != null) {
                    selectedVideoPath = path
                    binding.tvVideoFile.text = path
                }
            }
        }

    private val permissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    private fun neededPermissions(): Array<String> {
        val perms = ArrayList<String>()
        perms.add(Manifest.permission.CAMERA)
        if (Build.VERSION.SDK_INT >= 33) {
            perms.add(Manifest.permission.READ_MEDIA_VIDEO)
            perms.add(Manifest.permission.READ_MEDIA_IMAGES)
        } else {
            perms.add(Manifest.permission.READ_EXTERNAL_STORAGE)
            if (Build.VERSION.SDK_INT <= 28) perms.add(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        }
        return perms.distinct().toTypedArray()
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityUploadBinding.inflate(layoutInflater)
        setContentView(binding.root)

        fmAdapter = FmAdapter(onClick = ::onFmItemClicked)
        binding.fmRecycler.layoutManager = LinearLayoutManager(this)
        binding.fmRecycler.adapter = fmAdapter

        binding.btnBack.setOnClickListener {
            if (binding.fmPanel.visibility == View.VISIBLE) closeFileManager() else finish()
        }

        binding.btnModeVideo.setOnClickListener { setMode(Mode.VIDEO) }
        binding.btnModeDraw.setOnClickListener { setMode(Mode.DRAW) }
        binding.btnModeRepost.setOnClickListener { setMode(Mode.REPOST) }
        binding.btnModeArticle.setOnClickListener { setMode(Mode.ARTICLE) }
        binding.btnArtCover.setOnClickListener { openFileManager() }

        binding.fmFilterAll.setOnClickListener { setFmFilter(0) }
        binding.fmFilterVideo.setOnClickListener { setFmFilter(1) }
        binding.fmFilterImage.setOnClickListener { setFmFilter(2) }

        binding.tvVideoFile.setOnClickListener { openFileManager() }
        binding.btnCapture.setOnClickListener { captureVideo() }
        binding.btnPickVideo.setOnClickListener { openFileManager() }
        binding.btnTid.setOnClickListener { pickTid() }
        binding.btnPickImages.setOnClickListener { openFileManager() }
        binding.btnSubmit.setOnClickListener { submit() }

        setMode(Mode.VIDEO)

        if (!hasPermissions()) {
            permissionLauncher.launch(neededPermissions())
        }

        if (intent.getBooleanExtra(EXTRA_START_CAPTURE, false)) {
            binding.root.post { captureVideo() }
        }
    }

    companion object {
        const val EXTRA_START_CAPTURE = "start_capture"
    }

    private fun hasPermissions(): Boolean =
        neededPermissions().all { ContextCompat.checkSelfPermission(this, it) == PackageManager.PERMISSION_GRANTED }

    private fun setMode(m: Mode) {
        mode = m
        binding.btnModeVideo.alpha = if (m == Mode.VIDEO) 1f else 0.45f
        binding.btnModeDraw.alpha = if (m == Mode.DRAW) 1f else 0.45f
        binding.btnModeRepost.alpha = if (m == Mode.REPOST) 1f else 0.45f
        binding.btnModeArticle.alpha = if (m == Mode.ARTICLE) 1f else 0.45f
        val videoLike = m == Mode.VIDEO || m == Mode.REPOST
        binding.videoPanel.visibility = if (videoLike) View.VISIBLE else View.GONE
        binding.drawPanel.visibility = if (m == Mode.DRAW) View.VISIBLE else View.GONE
        binding.articlePanel.visibility = if (m == Mode.ARTICLE) View.VISIBLE else View.GONE
        binding.etSource.visibility = if (m == Mode.REPOST) View.VISIBLE else View.GONE
        binding.btnTid.visibility = if (videoLike) View.VISIBLE else View.GONE
    }

    private fun captureVideo() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            permissionLauncher.launch(arrayOf(Manifest.permission.CAMERA))
            return
        }
        runCatching {
            val intent = Intent(MediaStore.ACTION_VIDEO_CAPTURE).apply {
                putExtra(MediaStore.EXTRA_VIDEO_QUALITY, 1)
            }
            captureLauncher.launch(intent)
        }.onFailure { AppToast.show(this, "无法启动相机") }
    }

    

    
    private var fmFilter = 0

    private fun setFmFilter(filter: Int) {
        fmFilter = filter
        binding.fmFilterAll.alpha = if (filter == 0) 1f else 0.45f
        binding.fmFilterVideo.alpha = if (filter == 1) 1f else 0.45f
        binding.fmFilterImage.alpha = if (filter == 2) 1f else 0.45f
        
        if (currentDir == null && binding.fmPanel.visibility == View.VISIBLE && binding.tvPath.text?.toString()?.contains(rootDir.absolutePath) == true) {
            loadFmRoot()
        } else if (currentDir != null) {
            openDir(currentDir!!)
        }
    }

    private fun openFileManager() {
        if (!hasPermissions()) {
            permissionLauncher.launch(neededPermissions())
        }
        currentDir = null
        binding.formScroll.visibility = View.GONE
        binding.fmPanel.visibility = View.VISIBLE
        binding.tvTitle.text = getString(blbl.cat3399.R.string.upload_fm_root)
        loadFmRoot()
        binding.fmRecycler.requestFocus()
    }

    private fun closeFileManager() {
        binding.fmPanel.visibility = View.GONE
        binding.formScroll.visibility = View.VISIBLE
        binding.tvTitle.text = getString(blbl.cat3399.R.string.upload_title)
    }

    private data class FmItem(
        val name: String,
        val meta: String,
        val isDir: Boolean,
        val file: File?,
        val mediaKind: Int, 
        val shortcutKind: Int, 
        val uri: android.net.Uri? = null,
    )

    private fun loadFmRoot() {
        binding.tvPath.text = rootDir.absolutePath
        val items = ArrayList<FmItem>()
        if (fmFilter != 1) {
            items.add(FmItem(getString(blbl.cat3399.R.string.upload_fm_all_videos), "", isDir = false, file = null, mediaKind = 1, shortcutKind = 1))
        }
        if (fmFilter != 2) {
            items.add(FmItem(getString(blbl.cat3399.R.string.upload_fm_all_images), "", isDir = false, file = null, mediaKind = 2, shortcutKind = 2))
        }
        items.addAll(listDirEntries(rootDir, level = 0))
        fmAdapter.submit(items)
    }

    private fun openDir(dir: File) {
        currentDir = dir
        binding.tvPath.text = dir.absolutePath
        val items = ArrayList<FmItem>()
        items.add(FmItem(getString(blbl.cat3399.R.string.upload_fm_up), "..", isDir = true, file = dir.parentFile, mediaKind = 0, shortcutKind = 0))
        items.addAll(listDirEntries(dir, level = 1))
        fmAdapter.submit(items)
    }

    private fun listDirEntries(dir: File, level: Int): List<FmItem> {
        val out = ArrayList<FmItem>()
        val children = runCatching { dir.listFiles() }.getOrNull() ?: return out
        val dirs = ArrayList<File>()
        val media = ArrayList<FmItem>()
        for (child in children.sortedWith(compareBy({ it.name.lowercase() }))) {
            if (!child.exists()) continue
            val name = child.name
            if (name.startsWith(".")) continue
            if (child.isDirectory) {
                if (level == 0 && name == "Android") continue
                dirs.add(child)
            } else {
                val ext = name.substringAfterLast('.', "").lowercase()
                val kind =
                    when {
                        ext in videoExtensions -> 1
                        ext in imageExtensions -> 2
                        else -> 0
                    }
                
                if (kind == 0 || (fmFilter != 0 && kind != fmFilter)) continue
                val sizeText =
                    if (kind == 1) "视频 · " + humanSize(child.length())
                    else "图片 · " + humanSize(child.length())
                media.add(FmItem(name = name, meta = sizeText, isDir = false, file = child, mediaKind = kind, shortcutKind = 0))
            }
        }
        for (d in dirs) {
            out.add(FmItem(name = d.name + "/", meta = "文件夹", isDir = true, file = d, mediaKind = 0, shortcutKind = 0))
        }
        out.addAll(media)
        return out
    }

    private fun queryMedia(kind: Int) {
        val wanted =
            when (kind) {
                1 -> videoExtensions
                2 -> imageExtensions
                else -> emptySet()
            }
        val uri =
            if (kind == 1) MediaStore.Video.Media.EXTERNAL_CONTENT_URI
            else MediaStore.Images.Media.EXTERNAL_CONTENT_URI
        val items = ArrayList<FmItem>()
        val projection =
            arrayOf(
                MediaStore.MediaColumns.DISPLAY_NAME,
                MediaStore.MediaColumns.SIZE,
                MediaStore.MediaColumns.DATE_ADDED,
            )
        val dataIdx = 3
        val projectionFull = projection + MediaStore.MediaColumns.DATA
        runCatching {
            contentResolver.query(uri, projectionFull, null, null, MediaStore.MediaColumns.DATE_ADDED + " DESC")?.use { cursor ->
                val nameIdx = cursor.getColumnIndex(MediaStore.MediaColumns.DISPLAY_NAME)
                val sizeIdx = cursor.getColumnIndex(MediaStore.MediaColumns.SIZE)
                val dIdx = cursor.getColumnIndex(MediaStore.MediaColumns.DATA)
                val idIdx = cursor.getColumnIndex(MediaStore.MediaColumns._ID)
                while (cursor.moveToNext() && items.size < 1500) {
                    val path = if (dIdx >= 0) cursor.getString(dIdx) else null
                    val id = if (idIdx >= 0) cursor.getLong(idIdx) else -1L
                    val contentUri =
                        if (id > 0L) {
                            android.content.ContentUris.withAppendedId(uri, id)
                        } else {
                            null
                        }
                    val name =
                        if (nameIdx >= 0 && !cursor.getString(nameIdx).isNullOrBlank()) cursor.getString(nameIdx)
                        else path?.let { File(it).name }.orEmpty()
                    val ext = name.substringAfterLast('.', "").lowercase()
                    if (ext !in wanted) continue
                    val size = if (sizeIdx >= 0) cursor.getLong(sizeIdx) else 0L
                    val kindLabel = if (kind == 1) "视频" else "图片"
                    items.add(
                        FmItem(
                            name = name,
                            meta = "$kindLabel · " + humanSize(size),
                            isDir = false,
                            file = path?.takeIf { it.isNotBlank() }?.let { File(it) },
                            mediaKind = kind,
                            shortcutKind = 0,
                            uri = contentUri,
                        ),
                    )
                }
            }
        }.onFailure { t -> AppLog.w("Upload", "media query failed", t) }
        binding.tvPath.text = getString(if (kind == 1) blbl.cat3399.R.string.upload_fm_all_videos else blbl.cat3399.R.string.upload_fm_all_images)
        fmAdapter.submit(items)
    }

    private fun onFmItemClicked(item: FmItem) {
        when {
            item.shortcutKind == 1 -> queryMedia(1)
            item.shortcutKind == 2 -> queryMedia(2)
            item.isDir -> {
                val dir = item.file
                if (dir == null) {
                    loadFmRoot()
                } else if (dir.absolutePath == rootDir.absolutePath) {
                    loadFmRoot()
                } else {
                    openDir(dir)
                }
            }
            item.file != null && (mode == Mode.VIDEO || mode == Mode.REPOST) && item.mediaKind == 1 -> {
                val target = item.file
                if (target.exists() && target.length() > 0L) {
                    selectedVideoPath = target.absolutePath
                    binding.tvVideoFile.text = target.absolutePath
                    closeFileManager()
                } else if (item.uri != null) {
                    
                    val copy = copyUriToCache(item.uri, item.name)
                    if (copy != null) {
                        selectedVideoPath = copy
                        binding.tvVideoFile.text = copy
                        closeFileManager()
                    } else {
                        AppToast.show(this, "无法读取该视频文件")
                    }
                } else {
                    AppToast.show(this, "视频文件不存在或已被移动")
                }
            }
            item.file != null && mode == Mode.ARTICLE && item.mediaKind == 2 -> {
                selectedArticleCover = item.file?.absolutePath
                binding.btnArtCover.text = "已选择封面：" + (item.file?.name ?: "图片")
                closeFileManager()
            }
            item.file != null && mode == Mode.DRAW && item.mediaKind == 2 -> {
                if (selectedImages.size >= 9) {
                    AppToast.show(this, "最多选择9张图片")
                    return
                }
                val target = item.file
                val path =
                    if (target.exists() && target.length() > 0L) {
                        target.absolutePath
                    } else if (item.uri != null) {
                        copyUriToCache(item.uri, item.name)
                    } else {
                        null
                    }
                if (path == null) {
                    AppToast.show(this, "无法读取该图片")
                    return
                }
                selectedImages.add(path)
                binding.tvImages.text = "已选择 ${selectedImages.size} 张图片"
                fmAdapter.notifyItemChanged(fmAdapter.currentPosition(item))
            }
        }
    }

    private fun copyUriToCache(uri: Uri, name: String): String? =
        runCatching {
            val out = File(cacheDir, "upload_$name")
            contentResolver.openInputStream(uri)?.use { input ->
                out.outputStream().use { output -> input.copyTo(output) }
            }
            if (out.exists() && out.length() > 0L) out.absolutePath else null
        }.getOrNull()

    

    private fun pickTid() {
        val options = UploadApi.UPLOAD_TIDS
        AppPopup.singleChoice(
            context = this,
            title = "选择分类",
            items = options.map { it.second },
            checkedIndex = options.indexOfFirst { it.first == selectedTid }.takeIf { it >= 0 } ?: -1,
            onPicked = { index, _ ->
                if (index in options.indices) {
                    val pair = options[index]
                    selectedTid = pair.first
                    selectedTidName = pair.second
                    binding.btnTid.text = "分类：${pair.second}"
                }
            },
        )
    }

    private fun submit() {
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(this, getString(blbl.cat3399.R.string.upload_login_required))
            return
        }
        when (mode) {
            Mode.VIDEO -> submitVideo(copyright = 1, source = "")
            Mode.REPOST -> submitVideo(copyright = 2, source = binding.etSource.text?.toString()?.trim().orEmpty())
            Mode.DRAW -> submitDraw()
            Mode.ARTICLE -> submitArticle()
        }
    }

    private fun submitVideo(copyright: Int, source: String) {
        val path = selectedVideoPath ?: run {
            AppToast.show(this, getString(blbl.cat3399.R.string.upload_need_video))
            return
        }
        val file = File(path)
        if (!file.exists() || file.length() <= 0L) {
            AppToast.show(this, "视频文件无效或已被移动")
            return
        }
        val title = binding.etTitle.text?.toString()?.trim().orEmpty()
        if (title.isEmpty()) {
            AppToast.show(this, getString(blbl.cat3399.R.string.upload_need_title))
            return
        }
        val tag = binding.etTag.text?.toString()?.trim().orEmpty().ifBlank { "生活" }
        val desc = binding.etDesc.text?.toString()?.trim().orEmpty()
        val dynamic = binding.etDynamic.text?.toString()?.trim().orEmpty()
        if (copyright == 2 && source.isBlank()) {
            AppToast.show(this, "转载请填写来源链接")
            return
        }

        val handle =
            AppPopup.progress(
                context = this,
                title = "投稿中",
                status = "正在准备上传…",
                negativeText = "取消",
                cancelable = false,
            )
        lifecycleScope.launch {
            try {
                val fileLen = file.length()
                val result =
                    withContext(Dispatchers.IO) {
                        val pre = UploadApi.preupload(file.name, fileLen)
                        handle?.updateStatus("正在上传视频…")
                        val filename =
                            if (fileLen <= 4L * 1024 * 1024) {
                                UploadApi.uploadWhole(pre, file)
                                pre.filename
                            } else {
                                UploadApi.uploadChunked(pre, file)
                            }
                        handle?.updateStatus("正在提交信息…")
                        UploadApi.submitVideo(
                            title = title,
                            desc = desc,
                            tag = tag,
                            tid = if (selectedTid > 0) selectedTid else 160,
                            cover = "",
                            dynamic = dynamic,
                            filename = filename,
                            copyright = copyright,
                            source = source,
                        )
                    }
                handle?.dismiss()
                AppToast.show(this@UploadActivity, "投稿成功：${result.second}")
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("Upload", "video submit failed", t)
                handle?.dismiss()
                val msg = (t as? BiliApiException)?.apiMessage?.takeIf { it.isNotBlank() } ?: t.message.orEmpty()
                AppToast.show(this@UploadActivity, "投稿失败：${msg.take(80)}")
            }
        }
    }

    private fun submitArticle() {
        val title = binding.etArtTitle.text?.toString()?.trim().orEmpty()
        if (title.isEmpty()) {
            AppToast.show(this, "请填写文章标题")
            return
        }
        val content = binding.etArtContent.text?.toString()?.trim().orEmpty()
        if (content.length < 5) {
            AppToast.show(this, "文章内容太短（至少 5 字）")
            return
        }
        val tag = binding.etArtTag.text?.toString()?.trim().orEmpty()
        val cover = selectedArticleCover.orEmpty()
        val handle =
            AppPopup.progress(
                context = this,
                title = "发布中",
                status = "正在发布专栏…",
                negativeText = "取消",
                cancelable = false,
            )
        lifecycleScope.launch {
            try {
                val id =
                    withContext(Dispatchers.IO) {
                        UploadApi.submitArticle(
                            title = title,
                            content = content.replace("\n", "\n\n"),
                            tag = tag,
                            cover = cover,
                        )
                    }
                handle?.dismiss()
                if (id > 0L) {
                    AppToast.show(this@UploadActivity, "专栏发布成功")
                } else {
                    AppToast.show(this@UploadActivity, "专栏发布成功（ID 未知）")
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                handle?.dismiss()
                val msg = (t as? BiliApiException)?.apiMessage?.takeIf { it.isNotBlank() } ?: t.message.orEmpty()
                AppToast.show(this@UploadActivity, "发布失败：${msg.take(80)}")
            }
        }
    }

    private fun submitDraw() {
        val text = binding.etDrawText.text?.toString()?.trim().orEmpty()
        if (text.isEmpty()) {
            AppToast.show(this, getString(blbl.cat3399.R.string.upload_need_draw_text))
            return
        }
        if (selectedImages.isEmpty()) {
            AppToast.show(this, getString(blbl.cat3399.R.string.upload_need_images))
            return
        }
        val handle =
            AppPopup.progress(
                context = this,
                title = "发布中",
                status = "正在上传图片…",
                negativeText = "取消",
                cancelable = false,
            )
        lifecycleScope.launch {
            try {
                val urls =
                    withContext(Dispatchers.IO) {
                        selectedImages.map { path ->
                            handle?.updateStatus("正在上传图片 ${selectedImages.indexOf(path) + 1}/${selectedImages.size}…")
                            UploadApi.uploadDynamicImage(File(path))
                        }
                    }
                handle?.updateStatus("正在发布…")
                withContext(Dispatchers.IO) { UploadApi.publishDraw(text, urls) }
                handle?.dismiss()
                AppToast.show(this@UploadActivity, "图文已发布")
                selectedImages.clear()
                binding.tvImages.text = ""
                binding.etDrawText.text = null
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("Upload", "draw submit failed", t)
                handle?.dismiss()
                val msg = (t as? BiliApiException)?.apiMessage?.takeIf { it.isNotBlank() } ?: t.message.orEmpty()
                AppToast.show(this@UploadActivity, "发布失败：${msg.take(80)}")
            }
        }
    }

    private fun humanSize(bytes: Long): String {
        if (bytes < 1024) return "$bytes B"
        val kb = bytes / 1024.0
        if (kb < 1024) return String.format(Locale.US, "%.1f KB", kb)
        val mb = kb / 1024.0
        if (mb < 1024) return String.format(Locale.US, "%.1f MB", mb)
        return String.format(Locale.US, "%.2f GB", mb / 1024.0)
    }

    override fun onKeyDown(keyCode: Int, event: KeyEvent?): Boolean {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            if (binding.fmPanel.visibility == View.VISIBLE) {
                val dir = currentDir
                if (dir != null) {
                    if (dir.absolutePath == rootDir.absolutePath) {
                        closeFileManager()
                    } else {
                        openDir(dir.parentFile ?: rootDir)
                    }
                } else {
                    loadFmRoot()
                }
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
    }

    private class FmAdapter(
        private val onClick: (FmItem) -> Unit,
    ) : RecyclerView.Adapter<FmAdapter.Vh>() {
        private val items = ArrayList<FmItem>()

        fun submit(list: List<FmItem>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        fun currentPosition(item: FmItem): Int = items.indexOf(item)

        override fun onCreateViewHolder(parent: android.view.ViewGroup, viewType: Int): Vh {
            val b = ItemFileManagerBinding.inflate(android.view.LayoutInflater.from(parent.context), parent, false)
            return Vh(b)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            holder.bind(items[position], onClick)
        }

        override fun getItemCount(): Int = items.size

        class Vh(private val binding: ItemFileManagerBinding) : RecyclerView.ViewHolder(binding.root) {
            private var thumbRequestSeq = 0

            fun bind(item: FmItem, onClick: (FmItem) -> Unit) {
                binding.tvName.text = item.name
                binding.tvMeta.text = item.meta
                binding.root.setOnClickListener { onClick(item) }
                
                val seq = ++thumbRequestSeq
                binding.ivIcon.setImageResource(R.drawable.ic_nav_upload)
                binding.ivIcon.setBackgroundResource(0)
                binding.ivIcon.scaleType = android.widget.ImageView.ScaleType.CENTER_CROP
                binding.ivIcon.alpha = 1f
                when {
                    item.isDir -> {
                        binding.ivIcon.setImageResource(R.drawable.ic_fm_folder)
                        binding.ivIcon.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
                        binding.ivIcon.alpha = 0.85f
                    }

                    item.mediaKind == 1 -> {
                        val file = item.file
                        if (file != null && file.exists()) {
                            loadThumbAsync(seq, item) { bmp ->
                                if (seq == thumbRequestSeq && bmp != null) {
                                    binding.ivIcon.setImageBitmap(bmp)
                                } else if (seq == thumbRequestSeq) {
                                    binding.ivIcon.setImageResource(R.drawable.ic_fm_video)
                                }
                            }
                        } else {
                            binding.ivIcon.setImageResource(R.drawable.ic_fm_video)
                        }
                    }

                    item.mediaKind == 2 -> {
                        val file = item.file
                        if (file != null && file.exists()) {
                            loadThumbAsync(seq, item) { bmp ->
                                if (seq == thumbRequestSeq && bmp != null) {
                                    binding.ivIcon.setImageBitmap(bmp)
                                } else if (seq == thumbRequestSeq) {
                                    binding.ivIcon.setImageResource(R.drawable.ic_fm_image)
                                }
                            }
                        } else {
                            binding.ivIcon.setImageResource(R.drawable.ic_fm_image)
                        }
                    }

                    else -> {
                        val ext = item.name.substringAfterLast('.', "").lowercase()
                        binding.ivIcon.setImageResource(fileIconForExt(ext))
                        binding.ivIcon.scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
                        binding.ivIcon.alpha = 0.85f
                    }
                }
            }

            private fun loadThumbAsync(seq: Int, item: FmItem, onReady: (android.graphics.Bitmap?) -> Unit) {
                Thread {
                    val bmp =
                        try {
                            if (item.mediaKind == 1) {
                                
                                val f = item.file
                                if (f != null && f.exists()) {
                                    android.media.ThumbnailUtils.createVideoThumbnail(
                                        f.absolutePath,
                                        android.provider.MediaStore.Video.Thumbnails.MINI_KIND,
                                    )?.let { full ->
                                        val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = 2 }
                                        android.graphics.BitmapFactory.decodeFile(f.absolutePath, opts)
                                            ?: full
                                    }
                                } else {
                                    null
                                }
                            } else {
                                val f = item.file
                                if (f != null && f.exists()) {
                                    val opts = android.graphics.BitmapFactory.Options().apply { inJustDecodeBounds = true }
                                    android.graphics.BitmapFactory.decodeFile(f.absolutePath, opts)
                                    var sample = 1
                                    while (opts.outWidth / (sample * 2) >= 512 && opts.outHeight / (sample * 2) >= 512) {
                                        sample *= 2
                                    }
                                    val dec = android.graphics.BitmapFactory.Options().apply { inSampleSize = sample }
                                    android.graphics.BitmapFactory.decodeFile(f.absolutePath, dec)
                                } else {
                                    null
                                }
                            }
                        } catch (t: Throwable) {
                            null
                        }
                    if (seq == thumbRequestSeq) {
                        binding.root.post { onReady(bmp) }
                    }
                }.start()
            }

            private fun fileIconForExt(ext: String): Int =
                when (ext) {
                    "mp3", "wav", "flac", "aac", "ogg", "m4a", "ape" -> R.drawable.ic_fm_audio
                    "zip", "rar", "7z", "tar", "gz" -> R.drawable.ic_fm_archive
                    "pdf", "doc", "docx", "txt", "md" -> R.drawable.ic_fm_doc
                    else -> R.drawable.ic_fm_file
                }
        }
    }
}
