package blbl.cat3399.feature.player

import android.text.InputType
import android.view.View
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import androidx.appcompat.widget.AppCompatButton
import androidx.core.view.setPadding
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.core.api.DanmakuPostApi
import blbl.cat3399.core.model.Danmaku
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.popup.AppPopup
import blbl.cat3399.core.ui.popup.PopupAction
import blbl.cat3399.core.ui.popup.PopupActionRole
import blbl.cat3399.core.ui.userScaledContext
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


internal fun PlayerActivity.openDanmakuSendDialog() {
    val activity = this
    if (!BiliClient.cookies.hasSessData()) {
        AppToast.show(this, "请先登录后再发送弹幕")
        return
    }
    val cid = currentCid
    val bvid = currentBvid.trim().takeIf { it.isNotBlank() }
    if (cid <= 0L || bvid == null) {
        AppToast.show(this, "当前视频暂不支持发送弹幕")
        return
    }

    
    val wasPlaying = player?.isPlaying == true
    if (wasPlaying) {
        runCatching { player?.pause() }
    }

    val dialogContext = userScaledContext()
    val density = dialogContext.resources.displayMetrics.density

    val content = LinearLayout(dialogContext).apply {
        orientation = LinearLayout.VERTICAL
        setPadding((18 * density).toInt())
    }

    
    val input = EditText(dialogContext).apply {
        hint = "输入弹幕内容"
        inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
        maxLines = 2
        isSingleLine = false
        setSingleLine(false)
        textSize = 15f
    }
    content.addView(input, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))

    
    val modeLabel = TextView(dialogContext).apply {
        text = "模式"
        textSize = 13f
        setPadding(0, (10 * density).toInt(), 0, (4 * density).toInt())
    }
    content.addView(modeLabel)

    val modes =
        listOf(
            "滚动" to DanmakuPostApi.MODE_SCROLL,
            "顶部" to DanmakuPostApi.MODE_TOP,
            "底部" to DanmakuPostApi.MODE_BOTTOM,
        )
    var selectedMode = DanmakuPostApi.MODE_SCROLL
    val modeButtons = ArrayList<View>(modes.size)
    val modeRow = LinearLayout(dialogContext).apply { orientation = LinearLayout.HORIZONTAL }

    fun refreshMode() {
        if (modeButtons.size != modes.size) return
        for (i in modes.indices) {
            val selected = modes[i].second == selectedMode
            val b = modeButtons[i] as? androidx.appcompat.widget.AppCompatButton ?: continue
            b.alpha = if (selected) 1f else 0.45f
            val bg = b.background as? android.graphics.drawable.GradientDrawable
            if (selected) {
                bg?.setColor(0xFFFB7299.toInt())
                b.setTextColor(0xFFFFFFFF.toInt())
            } else {
                bg?.setColor(0x22FB7299.toInt())
                b.setTextColor(0xFFFFFFFF.toInt())
            }
        }
    }

    for ((label, mode) in modes) {
        val btn =
            androidx.appcompat.widget.AppCompatButton(dialogContext).apply {
                text = label
                textSize = 14f
                isFocusable = true
                minHeight = 0
                setPadding((16 * density).toInt(), (6 * density).toInt(), (16 * density).toInt(), (6 * density).toInt())
                setOnClickListener {
                    selectedMode = mode
                    refreshMode()
                }
            }
        btn.background =
            android.graphics.drawable.GradientDrawable().apply {
                cornerRadius = (8 * density).toFloat()
                setStroke((2 * density).toInt(), 0xFFFB7299.toInt())
                setColor(0x22FB7299.toInt())
            }
        val lp =
            LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                marginEnd = (8 * density).toInt()
            }
        modeRow.addView(btn, lp)
        modeButtons.add(btn)
    }
    content.addView(modeRow)
    refreshMode()

    
    val colorLabel = TextView(dialogContext).apply {
        text = "颜色"
        textSize = 13f
        setPadding(0, (10 * density).toInt(), 0, (4 * density).toInt())
    }
    content.addView(colorLabel)

    val colors =
        listOf(
            DanmakuPostApi.COLOR_WHITE,
            DanmakuPostApi.COLOR_RED,
            DanmakuPostApi.COLOR_ORANGE,
            DanmakuPostApi.COLOR_YELLOW,
            DanmakuPostApi.COLOR_GREEN,
            DanmakuPostApi.COLOR_BLUE,
            DanmakuPostApi.COLOR_PURPLE,
            DanmakuPostApi.COLOR_PINK,
        )
    var selectedColor = DanmakuPostApi.COLOR_WHITE
    val colorViews = ArrayList<View>(colors.size)
    val colorRow = LinearLayout(dialogContext).apply { orientation = LinearLayout.HORIZONTAL }

    fun refreshColor() {
        for (i in colors.indices) {
            val selected = colors[i] == selectedColor
            val v = colorViews[i]
            val gd = v.background as? android.graphics.drawable.GradientDrawable
            if (selected) {
                v.alpha = 1f
                gd?.setStroke((3 * density).toInt(), 0xFFFFFFFF.toInt())
            } else {
                v.alpha = 0.45f
                gd?.setStroke(0, 0)
            }
        }
    }

    for (color in colors) {
        val swatch =
            View(dialogContext).apply {
                val gd =
                    android.graphics.drawable.GradientDrawable().apply {
                        shape = android.graphics.drawable.GradientDrawable.OVAL
                        setColor(color or 0xFF000000.toInt())
                    }
                background = gd
                isFocusable = true
                contentDescription = String.format("#%06X", color)
                setOnClickListener {
                    selectedColor = color
                    refreshColor()
                }
            }
        val size = (34 * density).toInt()
        val lp =
            LinearLayout.LayoutParams(size, size).apply {
                marginEnd = (10 * density).toInt()
            }
        colorRow.addView(swatch, lp)
        colorViews.add(swatch)
    }
    content.addView(colorRow)
    refreshColor()

    var sending = false

    
    fun resumeIfNeeded() {
        if (wasPlaying && !isFinishing && !isDestroyed) {
            binding.root.post {
                if (!isFinishing && !isDestroyed) {
                    runCatching { player?.play() }
                }
            }
        }
    }

    var handle: blbl.cat3399.core.ui.popup.PopupHandle? = null
    handle =
        try {
            AppPopup.custom(
                context = activity,
                title = "发送弹幕",
                cancelable = true,
                autoFocus = false,
                actions =
                    listOf(
                        PopupAction(role = PopupActionRole.NEGATIVE, text = "取消"),
                        PopupAction(
                            role = PopupActionRole.POSITIVE,
                            text = "发送",
                            dismissOnClick = false,
                        ) {
                            if (sending) return@PopupAction
                            val text = input.text?.toString().orEmpty().trim()
                            if (text.isEmpty()) {
                                AppToast.show(activity, "弹幕内容不能为空")
                                return@PopupAction
                            }
                            sending = true
                            lifecycleScope.launch {
                                
                                val progressMs = runCatching { player?.currentPosition?.coerceAtLeast(0L) }.getOrNull() ?: 0L
                                val result =
                                    withContext(Dispatchers.IO) {
                                        runCatching {
                                            DanmakuPostApi.post(
                                                bvid = bvid,
                                                cid = cid,
                                                progressMs = progressMs,
                                                text = text,
                                                mode = selectedMode,
                                                color = selectedColor,
                                            )
                                        }
                                    }
                                sending = false
                                if (isFinishing || isDestroyed) return@launch
                                result
                                    .onSuccess {
                                        
                                        runCatching {
                                            binding.danmakuView.appendDanmakus(
                                                listOf(
                                                    Danmaku(
                                                        timeMs = progressMs.toInt().coerceAtLeast(0),
                                                        mode = selectedMode,
                                                        text = text,
                                                        color = selectedColor,
                                                        fontSize = 25,
                                                        weight = 0,
                                                        midHash = "local",
                                                    ),
                                                ),
                                                alreadySorted = true,
                                            )
                                        }
                                        runCatching { handle?.dismiss() }
                                        AppToast.show(activity, "弹幕已发送")
                                    }
                                    .onFailure { e ->
                                        runCatching { handle?.dismiss() }
                                        AppToast.show(activity, "弹幕发送失败：${e.message.orEmpty().take(60)}")
                                    }
                            }
                        },
                    ),
                onModalAttached = {
                    runCatching { it.post { runCatching { input.requestFocus() } } }
                },
                onDismiss = {
                    
                    resumeIfNeeded()
                },
            ) {
                content
            }
        } catch (t: Throwable) {
            AppLog.e("PlayerDanmakuSend", "open danmaku dialog failed", t)
            resumeIfNeeded()
            AppToast.show(activity, "无法打开弹幕输入框：${t.message.orEmpty().take(40)}")
            null
        }
}
