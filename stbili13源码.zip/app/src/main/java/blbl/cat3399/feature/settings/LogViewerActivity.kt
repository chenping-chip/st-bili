package blbl.cat3399.feature.settings

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.core.view.isVisible
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.log.CrashTracker
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.cloneInUserScale
import blbl.cat3399.databinding.ActivityLogViewerBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File


class LogViewerActivity : BaseActivity() {
    private lateinit var binding: ActivityLogViewerBinding
    private lateinit var adapter: LogLineAdapter

    private val maxLines = 1500
    private val maxReadBytes = 300 * 1024L

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLogViewerBinding.inflate(layoutInflater.cloneInUserScale(this))
        setContentView(binding.root)
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)

        binding.btnBack.setOnClickListener { finish() }
        binding.btnRefresh.setOnClickListener { load() }
        binding.tvTitle.text = getString(R.string.settings_view_logs)

        adapter = LogLineAdapter()
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter

        load()
    }

    private fun load() {
        lifecycleScope.launch {
            val lines =
                withContext(Dispatchers.IO) {
                    readRecentLogLines()
                }
            if (isFinishing || isDestroyed) return@launch
            adapter.submitList(lines)
            binding.tvEmpty.isVisible = lines.isEmpty()
            binding.recycler.isVisible = lines.isNotEmpty()
        }
    }

    
    private fun readRecentLogLines(): List<String> {
        val dir = AppLog.logDir(applicationContext)
        val logFiles =
            dir.listFiles()?.asSequence()
                ?.filter { it.isFile && it.name.endsWith(".log") }
                ?.sortedByDescending { it.lastModified() }
                ?.toList()
                ?: emptyList()

        val out = ArrayList<String>()
        val seen = HashSet<String>()

        fun push(line: String) {
            val trimmed = line.trimEnd()
            if (trimmed.isBlank()) return
            if (seen.add(trimmed)) out.add(trimmed)
        }

        var budget = maxReadBytes
        for (file in logFiles.take(2)) {
            val tail = readTail(file, budget)
            if (tail.isBlank()) continue
            budget -= tail.length
            
            val lines = tail.lineSequence().toList()
            for (i in lines.size - 1 downTo 0) push(lines[i])
            if (budget <= 0L) break
        }

        
        runCatching {
            val crash = CrashTracker.loadLastCrash(applicationContext)
            if (crash != null) {
                push("========== 最近一次崩溃 ==========")
                push("崩溃时间：${crash.crashAtMs}")
                push("线程：${crash.threadName}")
                crash.stacktrace.lineSequence().take(60).forEach { push(it) }
                push("========== 崩溃记录结束 ==========")
            }
        }

        if (out.size > maxLines) {
            return out.subList(0, maxLines)
        }
        return out
    }

    private fun readTail(file: File, maxBytes: Long): String {
        return runCatching {
            val len = file.length()
            if (len <= 0L) return@runCatching ""
            val start = (len - maxBytes).coerceAtLeast(0L)
            val bytes: ByteArray =
                java.io.RandomAccessFile(file, "r").use { raf ->
                    raf.seek(start)
                    val size = (len - start).toInt().coerceAtLeast(0)
                    val buf = ByteArray(size)
                    raf.readFully(buf)
                    buf
                }
            var text = String(bytes, Charsets.UTF_8)
            if (start > 0L) {
                
                val nl = text.indexOf('\n')
                if (nl >= 0) text = text.substring(nl + 1)
            }
            text
        }.getOrNull().orEmpty()
    }

    private class LogLineDiff : DiffUtil.ItemCallback<String>() {
        override fun areItemsTheSame(oldItem: String, newItem: String): Boolean = oldItem === newItem
        override fun areContentsTheSame(oldItem: String, newItem: String): Boolean = oldItem == newItem
    }

    private class LogLineAdapter : ListAdapter<String, LogLineAdapter.Holder>(LogLineDiff()) {
        class Holder(view: View) : RecyclerView.ViewHolder(view) {
            val text: TextView = view.findViewById(R.id.tv_log_line)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Holder {
            val view =
                LayoutInflater.from(parent.context)
                    .inflate(R.layout.item_log_line, parent, false)
            return Holder(view)
        }

        override fun onBindViewHolder(holder: Holder, position: Int) {
            holder.text.text = getItem(position)
        }
    }
}
