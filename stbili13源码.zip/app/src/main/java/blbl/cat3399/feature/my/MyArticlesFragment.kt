package blbl.cat3399.feature.my

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.SimpleItemAnimator
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.GridSpanPolicy
import blbl.cat3399.core.util.Format
import blbl.cat3399.databinding.FragmentVideoGridBinding
import blbl.cat3399.databinding.ItemMyArticleBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch


class MyArticlesFragment : Fragment() {
    private var _binding: FragmentVideoGridBinding? = null
    private val binding get() = _binding!!

    private lateinit var adapter: ArticleAdapter
    private var page = 1
    private var hasMore = true
    private var loading = false
    private var initialLoadTriggered = false

    private val mid: Long
        get() =
            BiliClient.cookies
                .getCookieValue("DedeUserID")
                ?.toLongOrNull()
                ?: 0L

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentVideoGridBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        if (!::adapter.isInitialized) {
            adapter =
                ArticleAdapter(
                    onClick = { article ->
                        val url = "https://www.bilibili.com/read/cv${article.id}"
                        runCatching {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
                        }.onFailure { AppToast.show(requireContext(), "没有可用的浏览器") }
                    },
                )
        }
        binding.recycler.adapter = adapter
        binding.recycler.layoutManager =
            GridLayoutManager(
                requireContext(),
                GridSpanPolicy.fixedSpanCountForWidthDp(
                    widthDp = resources.displayMetrics.widthPixels / resources.displayMetrics.density,
                    overrideSpanCount = 0,
                ),
            )
        (binding.recycler.itemAnimator as? SimpleItemAnimator)?.supportsChangeAnimations = false
        binding.swipeRefresh.setOnRefreshListener { reload() }
        binding.recycler.addOnScrollListener(
            object : RecyclerView.OnScrollListener() {
                override fun onScrolled(recyclerView: RecyclerView, dx: Int, dy: Int) {
                    if (dy <= 0) return
                    if (loading || !hasMore) return
                    val lm = recyclerView.layoutManager as? GridLayoutManager ?: return
                    val last = lm.findLastVisibleItemPosition()
                    if (adapter.itemCount - last - 1 <= 6) loadNext()
                }
            },
        )
        if (!initialLoadTriggered) {
            initialLoadTriggered = true
            loadNext()
        }
    }

    private fun reload() {
        page = 1
        hasMore = true
        adapter.clear()
        loadNext()
    }

    private fun loadNext() {
        if (loading) return
        if (mid <= 0L) {
            AppToast.show(requireContext(), "未登录")
            binding.swipeRefresh.isRefreshing = false
            return
        }
        loading = true
        viewLifecycleOwner.lifecycleScope.launch {
            try {
                val res = BiliApi.upArticles(mid = mid, pn = page, ps = 20)
                adapter.append(res.items)
                hasMore = res.hasMore
                page += 1
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("MyArticles", "load failed", t)
                AppToast.show(requireContext(), "加载失败：${t.message.orEmpty().take(60)}")
            } finally {
                loading = false
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }

    private class ArticleAdapter(
        private val onClick: (BiliApi.UpArticle) -> Unit,
    ) : RecyclerView.Adapter<ArticleAdapter.Vh>() {
        private val items = ArrayList<BiliApi.UpArticle>()

        fun clear() {
            items.clear()
            notifyDataSetChanged()
        }

        fun append(list: List<BiliApi.UpArticle>) {
            val start = items.size
            items.addAll(list)
            if (list.isNotEmpty()) notifyItemRangeInserted(start, list.size)
        }

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
            val b = ItemMyArticleBinding.inflate(LayoutInflater.from(parent.context), parent, false)
            return Vh(b)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            holder.bind(items[position], onClick)
        }

        override fun getItemCount(): Int = items.size

        class Vh(private val binding: ItemMyArticleBinding) : RecyclerView.ViewHolder(binding.root) {
            fun bind(article: BiliApi.UpArticle, onClick: (BiliApi.UpArticle) -> Unit) {
                binding.tvTitle.text = article.title
                binding.tvMeta.text =
                    "阅读 ${Format.count(article.viewCount)} · 点赞 ${Format.count(article.likeCount)} · ${Format.timeText(article.publishTimeSec)}"
                ImageLoader.loadInto(binding.ivCover, article.cover)
                binding.root.setOnClickListener { onClick(article) }
            }
        }
    }
}
