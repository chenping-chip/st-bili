package blbl.cat3399.feature.player

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View

class HoldToTriggerController(
    private val view: View,
    private val progressHost: HoldProgressHost,
    private val durationMs: Long,
    private val onLongTrigger: () -> Unit,
) {
    private var holdAnimator: ValueAnimator? = null
    private var holdReady: Boolean = false

    fun install() {
        view.setOnTouchListener { touchedView, event ->
            when (event.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    touchedView.isPressed = true
                    startHoldGesture()
                    true
                }

                MotionEvent.ACTION_MOVE -> {
                    val inside =
                        event.x >= 0f &&
                            event.x < touchedView.width &&
                            event.y >= 0f &&
                            event.y < touchedView.height
                    touchedView.isPressed = inside
                    if (!inside) cancel(resetReady = false)
                    true
                }

                MotionEvent.ACTION_UP -> {
                    val ready = holdReady
                    val inside =
                        event.x >= 0f &&
                            event.x < touchedView.width &&
                            event.y >= 0f &&
                            event.y < touchedView.height
                    touchedView.isPressed = false
                    cancel(resetReady = false)
                    if (ready && inside) {
                        onLongTrigger()
                    } else if (inside && touchedView.isEnabled) {
                        touchedView.performClick()
                    }
                    true
                }

                MotionEvent.ACTION_CANCEL -> {
                    touchedView.isPressed = false
                    cancel(resetReady = true)
                    true
                }

                else -> false
            }
        }

        view.setOnKeyListener { keyView, keyCode, event ->
            if (!isHoldTriggerConfirmKey(keyCode)) return@setOnKeyListener false
            when (event.action) {
                KeyEvent.ACTION_DOWN -> {
                    if (event.repeatCount == 0) {
                        keyView.isPressed = true
                        startHoldGesture()
                    }
                    true
                }

                KeyEvent.ACTION_UP -> {
                    val ready = holdReady
                    keyView.isPressed = false
                    cancel(resetReady = false)
                    if (ready) {
                        onLongTrigger()
                    } else if (keyView.isEnabled) {
                        keyView.performClick()
                    }
                    true
                }

                else -> false
            }
        }

        view.setOnFocusChangeListener { focusedView, hasFocus ->
            if (hasFocus) return@setOnFocusChangeListener
            focusedView.isPressed = false
            cancel(resetReady = true)
        }
    }

    fun cancel(resetReady: Boolean = true) {
        holdAnimator?.cancel()
        holdAnimator = null
        progressHost.holdProgress = 0f
        if (resetReady) holdReady = false
    }

    private fun startHoldGesture() {
        if (!view.isEnabled || view.visibility != View.VISIBLE) return
        holdReady = false
        holdAnimator?.cancel()
        progressHost.holdProgress = 0f

        val animator =
            ValueAnimator.ofFloat(0f, 1f).apply {
                duration = durationMs
                addUpdateListener { valueAnimator ->
                    progressHost.holdProgress = (valueAnimator.animatedValue as? Float) ?: 0f
                }
                addListener(
                    object : AnimatorListenerAdapter() {
                        private var cancelled = false

                        override fun onAnimationCancel(animation: Animator) {
                            cancelled = true
                        }

                        override fun onAnimationEnd(animation: Animator) {
                            if (holdAnimator === animation) holdAnimator = null
                            if (cancelled) return
                            holdReady = true
                            progressHost.holdProgress = 1f
                        }
                    },
                )
            }
        holdAnimator = animator
        animator.start()
    }
}

private fun isHoldTriggerConfirmKey(keyCode: Int): Boolean {
    return when (keyCode) {
        KeyEvent.KEYCODE_DPAD_CENTER,
        KeyEvent.KEYCODE_ENTER,
        KeyEvent.KEYCODE_NUMPAD_ENTER,
        KeyEvent.KEYCODE_SPACE,
        KeyEvent.KEYCODE_BUTTON_A,
        -> true

        else -> false
    }
}
