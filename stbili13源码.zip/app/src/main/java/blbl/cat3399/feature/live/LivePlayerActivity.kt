@file:androidx.annotation.OptIn(markerClass = [androidx.media3.common.util.UnstableApi::class])

package blbl.cat3399.feature.live

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.SystemClock
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.graphics.SurfaceTexture
import android.view.Surface
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.TextureView
import android.view.View
import android.view.ViewConfiguration
import android.view.ViewGroup.MarginLayoutParams
import android.widget.FrameLayout
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.lifecycle.LifecycleCoroutineScope
import androidx.lifecycle.lifecycleScope
import androidx.media3.common.C
import androidx.media3.common.Format
import androidx.media3.common.MediaItem
import androidx.media3.common.PlaybackException
import androidx.media3.common.Player
import androidx.media3.datasource.okhttp.OkHttpDataSource
import androidx.media3.exoplayer.DecoderReuseEvaluation
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.exoplayer.analytics.AnalyticsListener
import androidx.media3.exoplayer.analytics.AnalyticsListener.EventTime
import androidx.media3.ui.AspectRatioFrameLayout
import blbl.cat3399.BuildConfig
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.api.LiveApi
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.model.Danmaku
import blbl.cat3399.core.model.LiveSuperChat
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import blbl.cat3399.core.prefs.PlayerCustomShortcutAction
import blbl.cat3399.core.prefs.PlayerCustomShortcutTrigger
import blbl.cat3399.core.prefs.PlayerCustomShortcutsStore
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.DoubleBackToExitHandler
import blbl.cat3399.core.ui.FocusReturn
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.popup.AppPopup
import blbl.cat3399.core.ui.popup.PopupHost
import blbl.cat3399.databinding.ActivityPlayerBinding
import blbl.cat3399.databinding.ViewLiveSuperChatOverlayBinding
import blbl.cat3399.feature.player.AudioBalanceLevel
import blbl.cat3399.feature.player.PlayerBufferingOverlayController
import blbl.cat3399.feature.player.PlayerCustomShortcutBindings
import blbl.cat3399.feature.player.PlayerCustomShortcutDispatchResult
import blbl.cat3399.feature.player.PlayerCustomShortcutInputPolicy
import blbl.cat3399.feature.player.PlayerCustomShortcutPressController
import blbl.cat3399.feature.player.PlayerDefaultShortPressDispatcher
import blbl.cat3399.feature.player.PlayerDebugMetrics
import blbl.cat3399.feature.player.PlayerOsdHoverLabel
import blbl.cat3399.feature.player.PlayerOsdSizing
import blbl.cat3399.feature.player.PlayerSettingsAdapter
import blbl.cat3399.feature.player.PlayerTouchController
import blbl.cat3399.feature.player.PlayerTouchGestureHost
import blbl.cat3399.feature.player.PlayerUpQuickCardController
import blbl.cat3399.feature.player.PlayerUiMode
import blbl.cat3399.feature.player.areaText
import blbl.cat3399.feature.player.danmaku.DanmakuSessionSettings
import blbl.cat3399.feature.player.danmaku.DanmakuFontWeight
import blbl.cat3399.feature.player.danmaku.DanmakuLaneDensity
import blbl.cat3399.feature.player.engine.BlblPlayerEngine
import blbl.cat3399.feature.player.engine.ExoPlayerEngine
import blbl.cat3399.feature.player.engine.IjkPlayerPlugin
import blbl.cat3399.feature.player.engine.IjkPlayerPluginUi
import blbl.cat3399.feature.player.engine.IjkPlayerEngine
import blbl.cat3399.feature.player.engine.LiveHlsDebugInfo
import blbl.cat3399.feature.player.engine.PlayerEngineKind
import blbl.cat3399.feature.player.engine.PlaybackSource
import blbl.cat3399.feature.player.requirePlayerTouchOverlayBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import org.json.JSONObject
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.util.Locale
import kotlin.math.abs
import kotlin.math.roundToInt

private object LivePlayerSettingKeys {
    const val QUALITY = "quality"
    const val LINE = "line"
    const val HIGH_BITRATE = "high_bitrate"
    const val AUDIO_BALANCE = "audio_balance"
    const val PLAYER_ENGINE = "player_engine"
    const val DEBUG_INFO = "debug_info"
}

class LivePlayerActivity : BaseActivity() {
    override fun shouldRecreateOnUiScaleChange(): Boolean = true

    private lateinit var binding: ActivityPlayerBinding
    private lateinit var upQuickCard: PlayerUpQuickCardController
    private lateinit var superChatOverlay: LiveSuperChatOverlayController

    private var player: BlblPlayerEngine? = null
    private var ijkRenderView: View? = null
    private var ijkTextureSurface: Surface? = null
    private val settingsPanelReturnFocus = FocusReturn()
    private val osdFocusReturn = FocusReturn()
    private var autoHideJob: Job? = null
    private var seekHintJob: Job? = null
    private var superChatLoadJob: Job? = null
    private var touchController: PlayerTouchController? = null
    private val shortcutPrevDanmakuOpacityByKey = HashMap<Int, Float>()
    private val shortcutPrevDanmakuTextSizeByKey = HashMap<Int, Float>()
    private val shortcutPrevDanmakuSpeedLevelByKey = HashMap<Int, Int>()
    private val shortcutPrevDanmakuAreaByKey = HashMap<Int, Float>()
    private val shortcutPressController by lazy {
        PlayerCustomShortcutPressController<PlayerCustomShortcutAction, KeyEvent>(
            scope = lifecycleScope,
            longPressTimeoutMillis = ViewConfiguration.getLongPressTimeout().toLong(),
            isEligibleKey = { keyCode ->
                keyCode > 0 &&
                    keyCode != KeyEvent.KEYCODE_UNKNOWN &&
                    !PlayerCustomShortcutsStore.isForbiddenKeyCode(keyCode)
            },
            bindingsForKey = { keyCode ->
                val bindings = BiliClient.prefs.playerCustomShortcuts.filter { it.keyCode == keyCode }
                PlayerCustomShortcutBindings(
                    shortAction =
                        bindings.firstOrNull { it.trigger == PlayerCustomShortcutTrigger.SHORT_PRESS }
                            ?.action
                            ?.takeIf(::isLiveCustomShortcutActionSupported),
                    longAction =
                        bindings.firstOrNull { it.trigger == PlayerCustomShortcutTrigger.LONG_PRESS }
                            ?.action
                            ?.takeIf(::isLiveCustomShortcutActionSupported),
                )
            },
            canDispatch = ::canDispatchLiveCustomShortcut,
            copyEventToken = { source -> KeyEvent(source) },
            executeAction = { keyCode, trigger, action ->
                applyLiveCustomShortcut(
                    keyCode = shortcutMemoryKey(keyCode, trigger),
                    action = action,
                )
            },
        )
    }
    private var debugJob: Job? = null
    private var autoFailoverJob: Job? = null
    private var liveEntryReportedRoomId: Long = 0L
    private var finishOnBackKeyUp: Boolean = false
    private var controlsVisible: Boolean = false
    private var lastInteractionAtMs: Long = 0L
    private var autoFailoverWindowStartAtMs: Long = 0L
    private var autoFailoverSwitchCount: Int = 0
    private var autoFailoverLastSwitchAtMs: Long = 0L
    private var autoFailoverInFlight: Boolean = false
    private var behindLiveWindowWindowStartAtMs: Long = 0L
    private var behindLiveWindowRecoverCount: Int = 0
    private var behindLiveWindowLastRecoverAtMs: Long = 0L
    private var exitRequested: Boolean = false
    private val bufferingOverlayController: PlayerBufferingOverlayController by lazy {
        PlayerBufferingOverlayController(
            context = this,
            bindingProvider = { if (::binding.isInitialized) binding else null },
            scope = lifecycleScope,
            playbackStateProvider = { player?.playbackState },
        )
    }

    private val doubleBackToExit by lazy {
        DoubleBackToExitHandler(context = this, windowMs = BACK_DOUBLE_PRESS_WINDOW_MS) {
            if (controlsVisible) setControlsVisible(false)
        }
    }

    private var roomId: Long = 0L
    private var realRoomId: Long = 0L
    private var roomUid: Long = 0L
    private var roomTitle: String = ""
    private var roomUname: String = ""
    private var roomFace: String? = null

    private var session: LiveSession = LiveSession()
    private val debug = PlayerDebugMetrics()
    @Volatile private var liveHlsDebugInfo: LiveHlsDebugInfo? = null

    private var lastPlay: BiliApi.LivePlayUrl? = null
    private var lastLiveStatus: Int = 0
    private var transientPlaybackResumeRequested: Boolean? = null

    private var messageClient: LiveMessageClient? = null
    private var liveDanmakuBaseUptimeMs: Long = 0L
    private var liveDanmakuLastAppendMs: Int = Int.MIN_VALUE
    private var temporarySuperChatPreviewStarted = false

    
    private val liveCommentEntries = ArrayList<Triple<Int, String, Int>>()

    
    private var liveHistoryOpen = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        PlayerOsdSizing.applyTheme(this)
        val prefs = BiliClient.prefs
        val playerInflater = PlayerOsdSizing.cloneInflater(this, layoutInflater)
        val root =
            playerInflater.inflate(
                if (prefs.playerRenderViewType == AppPrefs.PLAYER_RENDER_VIEW_TEXTURE_VIEW) blbl.cat3399.R.layout.activity_player_texture else blbl.cat3399.R.layout.activity_player,
                null,
            )
        binding = ActivityPlayerBinding.bind(root)
        upQuickCard =
            PlayerUpQuickCardController(
                activity = this,
                binding = binding,
                isCardVisible = { controlsVisible },
                keepControlsVisible = { setControlsVisible(true) },
                beforeOpenUpDetail = { prepareTransientPlaybackExit() },
            )
        setContentView(binding.root)
        Immersive.apply(this, prefs.fullscreenEnabled)
        PlayerUiMode.applyLive(this, binding)
        resetBufferingOverlayState()

        roomId = intent.getLongExtra(EXTRA_ROOM_ID, 0L)
        roomTitle = intent.getStringExtra(EXTRA_TITLE).orEmpty()
        roomUname = intent.getStringExtra(EXTRA_UNAME).orEmpty()
        if (roomId <= 0L) {
            AppToast.show(this, "缺少 room_id")
            finish()
            return
        }

        val sessionOverrideJson =
            intent.getStringExtra(EXTRA_ENGINE_SWITCH_SESSION_JSON)
                ?.trim()
                ?.takeIf { it.isNotBlank() }
        session =
            LiveSession(
                engineKind = PlayerEngineKind.fromPrefValue(prefs.playerEngineKind),
                highBitrateEnabled = prefs.liveHighBitrateEnabled,
                danmaku = DanmakuSessionSettings(
                    enabled = prefs.danmakuEnabled,
                    opacity = prefs.danmakuOpacity,
                    textSizeSp = prefs.danmakuTextSizeSp,
                    fontWeight = DanmakuFontWeight.fromPrefValue(prefs.danmakuFontWeight),
                    strokeWidthPx = prefs.danmakuStrokeWidthPx,
                    speedLevel = prefs.danmakuSpeed,
                    area = prefs.danmakuArea,
                    laneDensity = DanmakuLaneDensity.fromPrefValue(prefs.danmakuLaneDensity),
                ),
                debugEnabled = prefs.playerDebugEnabled,
            )
        if (sessionOverrideJson != null) {
            session = session.restoreFromEngineSwitchJsonString(sessionOverrideJson)
        }
        superChatOverlay =
            LiveSuperChatOverlayController(
                binding = ViewLiveSuperChatOverlayBinding.bind(binding.liveSuperChatStub.inflate()),
                scope = lifecycleScope,
            ).also {
                it.setEnabled(session.danmaku.enabled)
            }

        
        binding.seekProgress.visibility = View.GONE
        binding.tvTime.visibility = View.GONE
        binding.btnSubtitle.visibility = View.GONE
        binding.tvSeekHint.visibility = View.GONE
        binding.btnPrev.visibility = View.GONE
        binding.btnNext.visibility = View.GONE
        binding.tvOnline.visibility = View.GONE
        binding.llTitleMeta.visibility = View.GONE
        binding.btnUp.visibility = View.GONE
        binding.btnLike.visibility = View.GONE
        binding.btnCoin.visibility = View.GONE
        binding.btnFav.visibility = View.GONE
        binding.btnListPanel.visibility = View.GONE
        binding.btnClosePlayer.visibility = View.GONE
        binding.btnComments.visibility = View.GONE

        
        
        binding.tvOnline.visibility = View.VISIBLE
        binding.llTitleMeta.visibility = View.VISIBLE
        binding.btnLiveRank.visibility = View.VISIBLE
        binding.btnLiveCommentStyle.visibility = View.VISIBLE
        binding.tvOnline.text = "直播中"
        binding.tvViewCount.text = "观看 -"

        setupUpQuickCard()
        binding.btnBack.setOnClickListener { finish() }
        setupLiveOverlayUi()

        val desiredEngineKind = session.engineKind
        val engineKind =
            if (desiredEngineKind == PlayerEngineKind.IjkPlayer && !IjkPlayerPlugin.isInstalled(this)) {
                val status = IjkPlayerPlugin.status(this)
                val text =
                    if (status == IjkPlayerPlugin.InstallStatus.NeedsUpdate) {
                        "IjkPlayer 插件需要更新，已临时使用 ExoPlayer"
                    } else {
                        "IjkPlayer 插件未安装，已临时使用 ExoPlayer"
                    }
                AppToast.showLong(this, text)
                IjkPlayerPluginUi.ensureInstalled(this) {
                    if (!isFinishing && !isDestroyed) recreate()
                }
                PlayerEngineKind.ExoPlayer
            } else {
                desiredEngineKind
            }
        if (session.engineKind != engineKind) {
            session = session.copy(engineKind = engineKind)
        }
        val engine: BlblPlayerEngine =
            when (engineKind) {
                PlayerEngineKind.IjkPlayer -> {
                    IjkPlayerEngine(context = this)
                }
                PlayerEngineKind.ExoPlayer ->
                    ExoPlayerEngine(
                        context = this,
                        onTransferHost = { _, host ->
                            debug.videoTransferHost = host
                        },
                        onBytesTransferred = { _, bytes ->
                            recordBufferingTransferBytes(bytes)
                        },
                        onLiveHlsDebugInfo = { info ->
                            liveHlsDebugInfo = info
                        },
                        audioBalanceLevel = AudioBalanceLevel.fromPrefValue(prefs.playerAudioBalanceLevel),
                    )
            }
        player = engine
        applyRenderForEngine(engine, prefs)
        (engine as? ExoPlayerEngine)?.exoPlayer?.addAnalyticsListener(
            object : AnalyticsListener {
                override fun onVideoDecoderInitialized(
                    eventTime: EventTime,
                    decoderName: String,
                    initializedTimestampMs: Long,
                    initializationDurationMs: Long,
                ) {
                    debug.videoDecoderName = decoderName
                }

                override fun onVideoInputFormatChanged(eventTime: EventTime, format: Format, decoderReuseEvaluation: DecoderReuseEvaluation?) {
                    debug.videoInputWidth = format.width.takeIf { it > 0 }
                    debug.videoInputHeight = format.height.takeIf { it > 0 }
                    debug.videoInputFps = format.frameRate.takeIf { it > 0f }
                }

                override fun onDroppedVideoFrames(eventTime: EventTime, droppedFrames: Int, elapsedMs: Long) {
                    debug.droppedFramesTotal += droppedFrames.toLong().coerceAtLeast(0L)
                }

                override fun onVideoFrameProcessingOffset(eventTime: EventTime, totalProcessingOffsetUs: Long, frameCount: Int) {
                    val now = eventTime.realtimeMs
                    val last = debug.renderFpsLastAtMs
                    debug.renderFpsLastAtMs = now
                    if (last == null) return
                    val deltaMs = now - last
                    if (deltaMs <= 0L || deltaMs > 60_000L) return
                    val frames = frameCount.coerceAtLeast(0)
                    if (frames == 0) return
                    debug.renderFps = (frames * 1000f) / deltaMs.toFloat()
                }
            },
        )
        liveDanmakuBaseUptimeMs = SystemClock.elapsedRealtime()
        liveDanmakuLastAppendMs = Int.MIN_VALUE
        binding.danmakuView.setPositionProvider { liveDanmakuPositionMs() }
        binding.danmakuView.setIsPlayingProvider { player?.isPlaying == true }
        binding.danmakuView.setPlaybackSpeedProvider { player?.playbackSpeed ?: 1.0f }
        binding.danmakuView.setConfigProvider { session.danmaku.toConfig() }

        engine.addListener(
            object : BlblPlayerEngine.Listener {
                override fun onPlayerError(error: Throwable) {
                    if (shouldSuppressPlayerError(error)) {
                        resetBufferingOverlayState()
                        return
                    }
                    AppLog.e("LivePlayer", "onPlayerError", error)
                    val playbackException = error as? PlaybackException
                    if (playbackException != null && tryRecoverBehindLiveWindow(playbackException)) {
                        return
                    }
                    if (tryAutoFailoverOnError(error)) {
                        return
                    }
                    resetBufferingOverlayState()
                    if (playbackException != null) {
                        AppToast.show(this@LivePlayerActivity, "播放失败：${playbackException.errorCodeName}")
                        return
                    }
                    AppToast.showLong(this@LivePlayerActivity, "播放失败：${error.message ?: "未知错误"}")
                }

                override fun onIsPlayingChanged(isPlaying: Boolean) {
                    updatePlayPauseIcon(isPlaying)
                    noteUserInteraction()
                }

                override fun onPlaybackStateChanged(playbackState: Int) {
                    if (playbackState == Player.STATE_BUFFERING && debug.lastPlaybackState != Player.STATE_BUFFERING && engine.playWhenReady) {
                        debug.rebufferCount++
                    }
                    when (playbackState) {
                        Player.STATE_BUFFERING ->
                            showBufferingOverlay(
                                resetSpeedSample = debug.lastPlaybackState != Player.STATE_BUFFERING,
                            )
                        Player.STATE_READY,
                        Player.STATE_IDLE,
                        Player.STATE_ENDED -> resetBufferingOverlayState()
                    }
                    debug.lastPlaybackState = playbackState
                }

                override fun onVideoSizeChanged(width: Int, height: Int) {
                    if (engine.kind != PlayerEngineKind.IjkPlayer) return
                    if (width <= 0 || height <= 0) return
                    debug.videoInputWidth = width
                    debug.videoInputHeight = height
                    binding.ijkAspect.setAspectRatio(width.toFloat() / height.toFloat())
                }
            },
        )

        binding.btnPlayPause.setOnClickListener {
            val p = player ?: return@setOnClickListener
            if (p.isPlaying) p.pause() else p.play()
            setControlsVisible(true)
        }
        binding.btnAdvanced.setOnClickListener {
            val willShow = binding.settingsPanel.visibility != View.VISIBLE
            setControlsVisible(true)
            if (willShow) {
                settingsPanelReturnFocus.capture(currentFocus)
                binding.settingsPanel.visibility = View.VISIBLE
                onTouchOverlayStateChanged()
                focusSettingsPanel()
            } else {
                
                settingsPanelReturnFocus.restoreAndClear(fallback = binding.btnAdvanced, postOnFail = false)
                binding.settingsPanel.visibility = View.GONE
                onTouchOverlayStateChanged()
            }
        }
        binding.btnDanmaku.setOnClickListener {
            session = session.copy(danmaku = session.danmaku.copy(enabled = !session.danmaku.enabled))
            binding.danmakuView.invalidate()
            superChatOverlay.setEnabled(session.danmaku.enabled)
            updateDanmakuButton()
            
            applyLiveCommentStyle()
            setControlsVisible(true)
        }

        binding.playerView.setOnClickListener {
            if (binding.settingsPanel.visibility == View.VISIBLE) {
                setControlsVisible(true)
                settingsPanelReturnFocus.restoreAndClear(fallback = binding.btnAdvanced, postOnFail = false)
                binding.settingsPanel.visibility = View.GONE
                onTouchOverlayStateChanged()
                return@setOnClickListener
            }
            toggleControls()
        }
        initTouchGestures()

        binding.root.isFocusableInTouchMode = true
        binding.root.requestFocus()

        setupSettingsPanel()
        
        binding.settingsPanel.visibility = View.GONE
        setControlsVisible(false)
        updateDanmakuButton()
        
        PlayerOsdHoverLabel.install(binding)

        lifecycleScope.launch { loadAndPlay(initial = true) }
    }

    private fun prepareTransientPlaybackExit() {
        val engine = player ?: return
        val shouldResume = engine.isPlaying || engine.playWhenReady
        transientPlaybackResumeRequested = shouldResume
        engine.pause()
    }

    private fun consumeTransientPlaybackResumeIfNeeded() {
        val shouldResume = transientPlaybackResumeRequested ?: return
        transientPlaybackResumeRequested = null
        if (exitRequested || isFinishing || isDestroyed || isChangingConfigurations) return
        val engine = player ?: return
        if (shouldResume) {
            engine.playWhenReady = true
        }
    }

    override fun onResume() {
        super.onResume()
        PlayerOsdSizing.applyTheme(this)
        PlayerUiMode.applyLive(this, binding)
        initTouchGestures()
        consumeTransientPlaybackResumeIfNeeded()
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus) Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)
    }

    private fun setupUpQuickCard() {
        binding.btnUpQuickProfile.nextFocusDownId = R.id.btn_play_pause
        binding.btnUpQuickFollow.nextFocusDownId = R.id.btn_play_pause
        listOf(
            binding.btnPlayPause,
            binding.btnDanmaku,
            binding.btnAdvanced,
        ).forEach { it.nextFocusUpId = R.id.btn_up_quick_profile }
        upQuickCard.setupActions()
        upQuickCard.setOwner(mid = roomUid, name = roomUname, avatar = roomFace)
        upQuickCard.refreshFollowStateIfNeeded(force = false)
    }

    private fun updateLiveUpQuickCardOwner(info: BiliApi.LiveRoomInfo) {
        roomUid = info.uid.takeIf { it > 0L } ?: roomUid
        roomUname =
            info.uname
                ?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: roomUname
        roomFace =
            info.faceUrl
                ?.trim()
                ?.takeIf { it.isNotBlank() }
                ?: roomFace
        upQuickCard.setOwner(mid = roomUid, name = roomUname, avatar = roomFace)
        upQuickCard.refreshFollowStateIfNeeded(force = false)
    }

    

    private var liveInfoRefreshJob: kotlinx.coroutines.Job? = null
    private var liveLikeInFlight = false
    private var liveRankLoading = false

    private fun setupLiveOverlayUi() {
        
        
        binding.btnListPanel.visibility = View.GONE
        binding.btnLiveRank.visibility = View.VISIBLE
        binding.btnLiveRank.setOnClickListener { showLiveRankPanel() }
        binding.btnLiveCommentStyle.visibility = View.VISIBLE
        binding.btnLiveCommentStyle.setOnClickListener { toggleLiveCommentStyle() }
        binding.btnSendDanmaku.visibility = View.VISIBLE
        binding.btnSendDanmaku.setOnClickListener { openLiveDanmakuSend() }
        binding.btnLiveHistory.visibility = View.VISIBLE
        binding.btnLiveHistory.setOnClickListener { toggleLiveHistoryPanel() }
        binding.btnVideoMode.visibility = View.GONE
        binding.btnShuffle.visibility = View.GONE
        applyLiveCommentStyle()
        loadLiveRankTop5()
        liveInfoRefreshJob =
            lifecycleScope.launch {
                while (isActive) {
                    val room = realRoomId.takeIf { it > 0L } ?: roomId
                    runCatching {
                        val extra =
                            withContext(Dispatchers.IO) {
                                BiliApi.liveRoomExtraInfo(room)
                            }
                        if (isFinishing || isDestroyed) return@runCatching
                        binding.tvOnline.text = "在线 ${formatLiveCount(extra.online)}"
                        binding.tvViewCount.text = formatLiveCount(extra.watchedCount)
                    }.onFailure {
                        
                    }
                    delay(5_000L)
                }
            }
    }

    
    private fun toggleLiveCommentStyle() {
        val next = if (BiliClient.prefs.liveCommentStyle == 1) 0 else 1
        BiliClient.prefs.liveCommentStyle = next
        applyLiveCommentStyle()
        updateLiveCommentStyleButton()
        AppToast.show(this, if (next == 1) "已切换为直接显示（悬浮评论区）" else "已切换为弹幕显示（飘屏）")
    }

    private fun updateLiveCommentStyleButton() {
        binding.btnLiveCommentStyle.setImageResource(
            if (BiliClient.prefs.liveCommentStyle == 1) {
                R.drawable.ic_live_comment_style
            } else {
                R.drawable.ic_player_danmaku_on
            },
        )
    }

    private fun onLiveLikeClicked() {
        
        AppToast.show(this@LivePlayerActivity, "点赞功能已移除")
    }

    private fun showLiveRankPanel() {
        if (liveRankLoading) return
        val room = realRoomId.takeIf { it > 0L } ?: roomId
        liveRankLoading = true
        lifecycleScope.launch {
            try {
                var ownerUid = roomUid.takeIf { it > 0L } ?: 0L
                if (ownerUid <= 0L) {
                    val extra = withContext(Dispatchers.IO) { BiliApi.liveRoomExtraInfo(room) }
                    if (extra.uid > 0L) ownerUid = extra.uid
                }
                val result =
                    withContext(Dispatchers.IO) {
                        BiliApi.liveRoomRank(roomId = room, uid = ownerUid)
                    }
                if (isFinishing || isDestroyed) return@launch
                if (result.items.isEmpty()) {
                    AppToast.show(this@LivePlayerActivity, "暂无贡献榜数据")
                    return@launch
                }
                showRankPopup(result.items)
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg =
                    (t as? BiliApiException)?.apiMessage
                        ?: t.message
                        ?: "未知错误"
                AppToast.show(this@LivePlayerActivity, "贡献榜加载失败：${msg.take(50)}")
            } finally {
                liveRankLoading = false
            }
        }
    }

    private fun showRankPopup(items: List<LiveApi.LiveRankItem>) {
        
        val rankTitle = "直播间贡献榜"
        AppPopup.custom(
            context = this,
            title = rankTitle,
            cancelable = true,
            actions =
                listOf(
                    blbl.cat3399.core.ui.popup.PopupAction(
                        role = blbl.cat3399.core.ui.popup.PopupActionRole.NEGATIVE,
                        text = "关闭",
                    ) {},
                ),
            autoFocus = true,
        ) { ctx ->
            android.widget.LinearLayout(ctx).apply {
                orientation = android.widget.LinearLayout.VERTICAL
                val recycler =
                    androidx.recyclerview.widget.RecyclerView(ctx).apply {
                        layoutManager = androidx.recyclerview.widget.LinearLayoutManager(ctx)
                        isVerticalScrollBarEnabled = false
                        adapter = RankPopupAdapter(items) { item ->
                            if (item.uid > 0L) {
                                startActivity(
                                    android.content.Intent(this@LivePlayerActivity, blbl.cat3399.feature.following.UpDetailActivity::class.java)
                                        .putExtra(blbl.cat3399.feature.following.UpDetailActivity.EXTRA_MID, item.uid)
                                        .apply {
                                            putExtra(blbl.cat3399.feature.following.UpDetailActivity.EXTRA_NAME, item.uname)
                                            item.face?.takeIf { it.isNotBlank() }?.let { putExtra(blbl.cat3399.feature.following.UpDetailActivity.EXTRA_AVATAR, it) }
                                        },
                                )
                            }
                        }
                    }
                addView(
                    recycler,
                    android.widget.LinearLayout.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        (56f * ctx.resources.displayMetrics.density * items.size.coerceIn(1, 7)).toInt(),
                    ),
                )
            }
        }
    }

    
    private class RankPopupAdapter(
        private val items: List<LiveApi.LiveRankItem>,
        private val onClick: (LiveApi.LiveRankItem) -> Unit,
    ) : androidx.recyclerview.widget.RecyclerView.Adapter<RankPopupAdapter.VH>() {
        class VH(val root: android.widget.LinearLayout) :
            androidx.recyclerview.widget.RecyclerView.ViewHolder(root)

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(
            parent: android.view.ViewGroup,
            viewType: Int,
        ): VH {
            val ctx = parent.context
            val density = ctx.resources.displayMetrics.density
            val root =
                android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.HORIZONTAL
                    gravity = Gravity.CENTER_VERTICAL
                    isFocusable = true
                    isClickable = true
                    setPadding((8 * density).toInt(), (6 * density).toInt(), (8 * density).toInt(), (6 * density).toInt())
                    background =
                        androidx.core.content.ContextCompat.getDrawable(ctx, R.drawable.blbl_focus_bg_round)
                    layoutParams = androidx.recyclerview.widget.RecyclerView.LayoutParams(
                        android.widget.LinearLayout.LayoutParams.MATCH_PARENT,
                        (52 * density).toInt(),
                    )
                }
            val face =
                ImageView(ctx).apply {
                    setImageResource(R.drawable.ic_fm_image)
                    background = androidx.core.content.ContextCompat.getDrawable(ctx, R.drawable.bg_circle_avatar)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    layoutParams = android.widget.LinearLayout.LayoutParams((40 * density).toInt(), (40 * density).toInt())
                }
            val names =
                android.widget.LinearLayout(ctx).apply {
                    orientation = android.widget.LinearLayout.VERTICAL
                    val lp = android.widget.LinearLayout.LayoutParams(0, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT, 1f)
                    lp.marginStart = (10 * density).toInt()
                    layoutParams = lp
                }
            val nameTv =
                TextView(ctx).apply {
                    textSize = 15f
                    setTextColor(0xFFEEEEEE.toInt())
                    maxLines = 1
                    ellipsize = android.text.TextUtils.TruncateAt.END
                }
            val scoreTv =
                TextView(ctx).apply {
                    textSize = 12f
                    setTextColor(0xFF9A9A9A.toInt())
                    maxLines = 1
                }
            names.addView(nameTv, android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            names.addView(scoreTv, android.widget.LinearLayout.LayoutParams(android.widget.LinearLayout.LayoutParams.MATCH_PARENT, android.widget.LinearLayout.LayoutParams.WRAP_CONTENT))
            root.addView(face)
            root.addView(names)
            return VH(root)
        }

        override fun onBindViewHolder(holder: VH, position: Int) {
            val item = items[position]
            val face = holder.root.getChildAt(0) as ImageView
            val names = holder.root.getChildAt(1) as android.widget.LinearLayout
            val nameTv = names.getChildAt(0) as TextView
            val scoreTv = names.getChildAt(1) as TextView
            nameTv.text = "榜${item.rank}  ${item.uname}"
            scoreTv.text = "贡献值 ${item.score}${formatLiveScoreSuffix(item.score)}"
            if (item.face.isNullOrBlank()) {
                face.setImageResource(R.drawable.ic_fm_image)
            } else {
                face.setImageResource(R.drawable.ic_fm_image)
                ImageLoader.loadInto(face, item.face)
            }
            holder.root.setOnClickListener { onClick(item) }
        }
    }

    private fun formatLiveCount(value: Long): String {
        if (value < 10_000L) return value.toString()
        if (value < 100_000_000L) {
            val w = value / 10_000.0
            return if (w >= 100.0) "${(w).toInt()}万" else String.format(java.util.Locale.US, "%.1f万", w)
        }
        val y = value / 100_000_000.0
        return String.format(java.util.Locale.US, "%.1f亿", y)
    }

    override fun onStop() {
        touchController?.onStop()
        clearLiveCustomShortcutPending()
        super.onStop()
    }

    override fun onDestroy() {
        val t0 = SystemClock.elapsedRealtime()
        AppLog.i("LivePlayer", "activity:onDestroy:start")
        transientPlaybackResumeRequested = null
        messageClient?.close()
        messageClient = null
        superChatLoadJob?.cancel()
        if (::superChatOverlay.isInitialized) superChatOverlay.release()
        releaseTouchGestures()
        seekHintJob?.cancel()
        debugJob?.cancel()
        autoFailoverJob?.cancel()
        autoFailoverInFlight = false
        autoHideJob?.cancel()
        upQuickCard.release()
        resetBufferingOverlayState()
        binding.playerView.player = null
        player?.setVideoSurface(null)
        ijkTextureSurface?.release()
        ijkTextureSurface = null
        val releaseStart = SystemClock.elapsedRealtime()
        player?.release()
        val releaseCostMs = SystemClock.elapsedRealtime() - releaseStart
        AppLog.i("LivePlayer", "player:release:done cost=${releaseCostMs}ms")
        player = null
        val totalCostMs = SystemClock.elapsedRealtime() - t0
        AppLog.i("LivePlayer", "activity:onDestroy:beforeSuper cost=${totalCostMs}ms")
        super.onDestroy()
    }

    override fun finish() {
        exitRequested = true
        transientPlaybackResumeRequested = null
        autoFailoverJob?.cancel()
        autoFailoverInFlight = false
        runCatching { player?.pause() }
        if (::binding.isInitialized) {
            binding.playerView.player = null
        }
        super.finish()
        applyCloseTransitionNoAnim()
    }

    private fun applyRenderForEngine(engine: BlblPlayerEngine, prefs: AppPrefs) {
        
        binding.ijkAspect.visibility = View.GONE
        binding.ijkContainer.removeAllViews()
        ijkRenderView = null
        ijkTextureSurface?.release()
        ijkTextureSurface = null
        engine.setVideoSurface(null)

        val exo = (engine as? ExoPlayerEngine)?.exoPlayer
        if (engine.kind == PlayerEngineKind.ExoPlayer) {
            binding.playerView.player = exo
            return
        }

        
        binding.playerView.player = null
        binding.ijkAspect.visibility = View.VISIBLE
        binding.ijkAspect.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT)
        binding.ijkAspect.setAspectRatio(0f)

        val renderView: View =
            if (prefs.playerRenderViewType == AppPrefs.PLAYER_RENDER_VIEW_TEXTURE_VIEW) {
                TextureView(this).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    isClickable = false
                    isLongClickable = false
                }
            } else {
                SurfaceView(this).apply {
                    isFocusable = false
                    isFocusableInTouchMode = false
                    isClickable = false
                    isLongClickable = false
                }
            }

        binding.ijkContainer.addView(
            renderView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )
        ijkRenderView = renderView

        when (renderView) {
            is SurfaceView -> {
                val callback =
                    object : SurfaceHolder.Callback {
                        override fun surfaceCreated(holder: SurfaceHolder) {
                            engine.setVideoSurface(holder.surface)
                        }

                        override fun surfaceChanged(holder: SurfaceHolder, format: Int, width: Int, height: Int) {
                            engine.setVideoSurface(holder.surface)
                        }

                        override fun surfaceDestroyed(holder: SurfaceHolder) {
                            engine.setVideoSurface(null)
                        }
                    }
                renderView.holder.addCallback(callback)
            }

            is TextureView -> {
                fun setSurface(surfaceTexture: SurfaceTexture?) {
                    ijkTextureSurface?.release()
                    ijkTextureSurface = null
                    if (surfaceTexture == null) {
                        engine.setVideoSurface(null)
                        return
                    }
                    val surface = Surface(surfaceTexture)
                    ijkTextureSurface = surface
                    engine.setVideoSurface(surface)
                }

                renderView.surfaceTextureListener =
                    object : TextureView.SurfaceTextureListener {
                        override fun onSurfaceTextureAvailable(surface: SurfaceTexture, width: Int, height: Int) {
                            setSurface(surface)
                        }

                        override fun onSurfaceTextureSizeChanged(surface: SurfaceTexture, width: Int, height: Int) {}

                        override fun onSurfaceTextureDestroyed(surface: SurfaceTexture): Boolean {
                            setSurface(null)
                            return true
                        }

                        override fun onSurfaceTextureUpdated(surface: SurfaceTexture) {}
                    }
                if (renderView.isAvailable) {
                    setSurface(renderView.surfaceTexture)
                }
            }
        }
    }

    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val keyCode = event.keyCode

        
        
        val popupHost = PopupHost.peek(this)
        if (popupHost != null) {
            if (popupHost.consumeBackLikeKeyEventIfNeeded(event)) {
                finishOnBackKeyUp = false
                return true
            }
            if (popupHost.hasModalView()) {
                return super.dispatchKeyEvent(event)
            }
        }

        if (event.action == KeyEvent.ACTION_DOWN && isInteractionKey(keyCode)) noteUserInteraction()

        when (val shortcutResult = dispatchLiveCustomShortcutIfNeeded(event)) {
            PlayerCustomShortcutDispatchResult.NotHandled -> Unit
            PlayerCustomShortcutDispatchResult.Consumed -> return true
            is PlayerCustomShortcutDispatchResult.RunDefaultShortPress -> {
                return dispatchDefaultLiveShortPress(
                    downEvent = shortcutResult.downEvent,
                    upEvent = shortcutResult.upEvent,
                )
            }
        }

        return dispatchLiveKeyEventWithoutCustomShortcut(event)
    }

    private fun dispatchDefaultLiveShortPress(downEvent: KeyEvent, upEvent: KeyEvent): Boolean {
        return PlayerDefaultShortPressDispatcher.dispatchAndConsume(
            context = this,
            downEvent = downEvent,
            upEvent = upEvent,
            dispatchDefaultEvent = ::dispatchLiveKeyEventWithoutCustomShortcut,
        )
    }

    private fun dispatchLiveKeyEventWithoutCustomShortcut(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        if (event.action == KeyEvent.ACTION_UP) {
            if (isExitKey(keyCode)) {
                if (finishOnBackKeyUp) {
                    finishOnBackKeyUp = false
                    finish()
                }
                return true
            }
            return super.dispatchKeyEvent(event)
        }

        if (event.action != KeyEvent.ACTION_DOWN) return super.dispatchKeyEvent(event)

        when (keyCode) {
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_SETTINGS,
            KeyEvent.KEYCODE_INFO,
            KeyEvent.KEYCODE_GUIDE,
            -> {
                if (binding.settingsPanel.visibility == View.VISIBLE) return true
                setControlsVisible(true)
                focusLastOsdControlOrFirst()
                return true
            }

            KeyEvent.KEYCODE_BACK -> {
                
            }
            KeyEvent.KEYCODE_ESCAPE,
            KeyEvent.KEYCODE_BUTTON_B,
            -> {
                
            }

            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            -> {
                if (binding.settingsPanel.visibility == View.VISIBLE) return super.dispatchKeyEvent(event)
                setControlsVisible(true)
                if (!hasControlsFocus()) {
                    focusLastOsdControlOrFirst()
                    return true
                }
            }

            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            -> {
                if (binding.settingsPanel.visibility != View.VISIBLE && !hasControlsFocus()) {
                    setControlsVisible(true)
                    focusLastOsdControlOrFirst()
                    return true
                }
                if (!controlsVisible && binding.settingsPanel.visibility != View.VISIBLE) {
                    setControlsVisible(true)
                    focusLastOsdControlOrFirst()
                    return true
                }
            }

            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE,
            -> {
                binding.btnPlayPause.performClick()
                return true
            }

            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            -> {
                if (binding.settingsPanel.visibility == View.VISIBLE) return super.dispatchKeyEvent(event)
                if (!controlsVisible) {
                    setControlsVisible(true)
                    
                    focusLastOsdControlOrFirst()
                    return true
                }
                if (!hasControlsFocus()) {
                    focusLastOsdControlOrFirst()
                    return true
                }
            }
        }
        if (isExitKey(keyCode)) {
            finishOnBackKeyUp = false
            if (binding.settingsPanel.visibility == View.VISIBLE) {
                setControlsVisible(true)
                settingsPanelReturnFocus.restoreAndClear(fallback = binding.btnAdvanced, postOnFail = false)
                binding.settingsPanel.visibility = View.GONE
                onTouchOverlayStateChanged()
                return true
            }
            if (controlsVisible) {
                setControlsVisible(false)
                return true
            }
            finishOnBackKeyUp = doubleBackToExit.shouldExit(enabled = BiliClient.prefs.playerDoubleBackToExit)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    private fun dispatchLiveCustomShortcutIfNeeded(
        event: KeyEvent,
    ): PlayerCustomShortcutDispatchResult<KeyEvent> {
        return when (event.action) {
            KeyEvent.ACTION_DOWN -> shortcutPressController.onKeyDown(event.keyCode, event.repeatCount, event)
            KeyEvent.ACTION_UP -> shortcutPressController.onKeyUp(event.keyCode, event)
            else -> PlayerCustomShortcutDispatchResult.NotHandled
        }
    }

    private fun canDispatchLiveCustomShortcut(): Boolean =
        PlayerCustomShortcutInputPolicy.canDispatchInLive(
            hasInteractiveOsd = controlsVisible,
            hasSettingsPanel = binding.settingsPanel.visibility == View.VISIBLE,
        )

    private fun clearLiveCustomShortcutPending() {
        shortcutPressController.clear()
    }

    private fun shortcutMemoryKey(keyCode: Int, trigger: PlayerCustomShortcutTrigger): Int =
        if (trigger == PlayerCustomShortcutTrigger.SHORT_PRESS) keyCode else keyCode xor Int.MIN_VALUE

    private fun isLiveCustomShortcutActionSupported(action: PlayerCustomShortcutAction): Boolean =
        when (action) {
            PlayerCustomShortcutAction.ShowOsd,
            PlayerCustomShortcutAction.OpenSettings,
            PlayerCustomShortcutAction.TogglePlayPause,
            PlayerCustomShortcutAction.ToggleDanmaku,
            is PlayerCustomShortcutAction.SetDanmakuOpacity,
            is PlayerCustomShortcutAction.SetDanmakuTextSize,
            is PlayerCustomShortcutAction.SetDanmakuSpeed,
            is PlayerCustomShortcutAction.SetDanmakuArea,
            PlayerCustomShortcutAction.ToggleDebugOverlay,
            -> true

            else -> false
        }

    private fun applyLiveCustomShortcut(keyCode: Int, action: PlayerCustomShortcutAction): Boolean {
        when (action) {
            PlayerCustomShortcutAction.ShowOsd -> {
                noteUserInteraction()
                setControlsVisible(true)
                focusLastOsdControlOrFirst()
                return true
            }

            PlayerCustomShortcutAction.OpenSettings -> {
                noteUserInteraction()
                setControlsVisible(true)
                if (this.binding.settingsPanel.visibility != View.VISIBLE) {
                    settingsPanelReturnFocus.capture(currentFocus)
                    this.binding.settingsPanel.visibility = View.VISIBLE
                    onTouchOverlayStateChanged()
                }
                focusSettingsPanel()
                return true
            }

            PlayerCustomShortcutAction.TogglePlayPause -> {
                noteUserInteraction()
                val engine = player ?: return true
                val willPlay = !engine.isPlaying
                if (willPlay) engine.play() else engine.pause()
                showSeekHint(if (willPlay) "播放" else "暂停")
                return true
            }

            PlayerCustomShortcutAction.ToggleDanmaku -> {
                noteUserInteraction()
                session = session.copy(danmaku = session.danmaku.copy(enabled = !session.danmaku.enabled))
                this.binding.danmakuView.invalidate()
                superChatOverlay.setEnabled(session.danmaku.enabled)
                updateDanmakuButton()
                val state = if (session.danmaku.enabled) "开" else "关"
                showShortcutHint("弹幕：$state")
                return true
            }

            is PlayerCustomShortcutAction.SetDanmakuOpacity -> {
                noteUserInteraction()
                val target = action.opacity.takeIf { it.isFinite() }?.coerceIn(0.05f, 1.0f) ?: session.danmaku.opacity
                val current = session.danmaku.opacity
                val next =
                    if (sameFloat(current, target)) {
                        shortcutPrevDanmakuOpacityByKey[keyCode] ?: target
                    } else {
                        shortcutPrevDanmakuOpacityByKey[keyCode] = current
                        target
                    }
                session = session.copy(danmaku = session.danmaku.copy(opacity = next))
                this.binding.danmakuView.invalidate()
                showShortcutHint("弹幕透明度：${String.format(Locale.US, "%.2f", next)}")
                return true
            }

            is PlayerCustomShortcutAction.SetDanmakuTextSize -> {
                noteUserInteraction()
                val target = action.textSizeSp.takeIf { it.isFinite() }?.coerceIn(10f, 60f) ?: session.danmaku.textSizeSp
                val current = session.danmaku.textSizeSp
                val next =
                    if (sameFloat(current, target)) {
                        shortcutPrevDanmakuTextSizeByKey[keyCode] ?: target
                    } else {
                        shortcutPrevDanmakuTextSizeByKey[keyCode] = current
                        target
                    }
                session = session.copy(danmaku = session.danmaku.copy(textSizeSp = next))
                this.binding.danmakuView.invalidate()
                showShortcutHint("弹幕大小：${next.toInt()}")
                return true
            }

            is PlayerCustomShortcutAction.SetDanmakuSpeed -> {
                noteUserInteraction()
                val target = action.speedLevel.coerceIn(1, 10)
                val current = session.danmaku.speedLevel
                val next =
                    if (current == target) {
                        shortcutPrevDanmakuSpeedLevelByKey[keyCode] ?: target
                    } else {
                        shortcutPrevDanmakuSpeedLevelByKey[keyCode] = current
                        target
                    }
                session = session.copy(danmaku = session.danmaku.copy(speedLevel = next))
                this.binding.danmakuView.invalidate()
                showShortcutHint("弹幕速度：$next")
                return true
            }

            is PlayerCustomShortcutAction.SetDanmakuArea -> {
                noteUserInteraction()
                val target = action.area.takeIf { it.isFinite() }?.let(AppPrefs::normalizeLegacyDanmakuAreaCompat) ?: session.danmaku.area
                val current = session.danmaku.area
                val next =
                    if (sameFloat(current, target)) {
                        shortcutPrevDanmakuAreaByKey[keyCode] ?: target
                    } else {
                        shortcutPrevDanmakuAreaByKey[keyCode] = current
                        target
                    }
                session = session.copy(danmaku = session.danmaku.copy(area = next))
                this.binding.danmakuView.invalidate()
                showShortcutHint("弹幕区域：${areaText(next)}")
                return true
            }

            PlayerCustomShortcutAction.ToggleDebugOverlay -> {
                noteUserInteraction()
                session = session.copy(debugEnabled = !session.debugEnabled)
                updateDebugOverlay()
                refreshSettings()
                val state = if (session.debugEnabled) "开" else "关"
                showShortcutHint("调试信息：$state")
                return true
            }

            else -> return false
        }
    }

    private fun showShortcutHint(text: String) {
        if (!controlsVisible) setControlsVisible(true)
        showSeekHint(text, hold = false)
    }

    private fun showSeekHint(text: String, hold: Boolean = false) {
        binding.tvSeekHint.text = text
        binding.tvSeekHint.visibility = View.VISIBLE
        seekHintJob?.cancel()
        if (!hold) scheduleHideSeekHint()
    }

    private fun scheduleHideSeekHint() {
        seekHintJob?.cancel()
        seekHintJob =
            lifecycleScope.launch {
                delay(SEEK_HINT_HIDE_DELAY_MS)
                binding.tvSeekHint.visibility = View.GONE
            }
    }

    private fun sameFloat(a: Float, b: Float): Boolean {
        if (!a.isFinite() || !b.isFinite()) return false
        return kotlin.math.abs(a - b) < 0.0001f
    }

    private fun setupSettingsPanel() {
        val settingsAdapter =
            PlayerSettingsAdapter { item ->
                when (item.key) {
                    LivePlayerSettingKeys.QUALITY -> showQualityDialog()
                    LivePlayerSettingKeys.LINE -> showLineDialog()
                    LivePlayerSettingKeys.HIGH_BITRATE -> toggleLiveHighBitrate()
                    LivePlayerSettingKeys.AUDIO_BALANCE -> showAudioBalanceDialog()
                    LivePlayerSettingKeys.PLAYER_ENGINE -> showPlayerEngineDialog()
                    LivePlayerSettingKeys.DEBUG_INFO -> {
                        session = session.copy(debugEnabled = !session.debugEnabled)
                        updateDebugOverlay()
                        refreshSettings()
                    }

                    else -> AppToast.show(this, "暂未实现：${item.title}")
                }
            }
        binding.recyclerSettings.adapter = settingsAdapter
        binding.recyclerSettings.layoutManager = androidx.recyclerview.widget.LinearLayoutManager(this)
        binding.recyclerSettings.itemAnimator = null
        binding.recyclerSettings.addOnChildAttachStateChangeListener(
            object : androidx.recyclerview.widget.RecyclerView.OnChildAttachStateChangeListener {
                override fun onChildViewAttachedToWindow(view: View) {
                    view.setOnKeyListener { v, keyCode, event ->
                        if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false
                        val holder = binding.recyclerSettings.findContainingViewHolder(v) ?: return@setOnKeyListener false
                        val pos =
                            holder.bindingAdapterPosition.takeIf { it != androidx.recyclerview.widget.RecyclerView.NO_POSITION }
                                ?: return@setOnKeyListener false

                        when (keyCode) {
                            KeyEvent.KEYCODE_DPAD_UP -> {
                                if (pos == 0 && !binding.recyclerSettings.canScrollVertically(-1)) return@setOnKeyListener true
                                false
                            }

                            KeyEvent.KEYCODE_DPAD_DOWN -> {
                                val last = (binding.recyclerSettings.adapter?.itemCount ?: 0) - 1
                                if (pos == last && !binding.recyclerSettings.canScrollVertically(1)) return@setOnKeyListener true
                                false
                            }

                            else -> false
                        }
                    }
                }

                override fun onChildViewDetachedFromWindow(view: View) {
                    view.setOnKeyListener(null)
                }
            },
        )
        refreshSettings()
        updateDebugOverlay()
    }

    private fun showAudioBalanceDialog() {
        val prefs = BiliClient.prefs
        val options = AudioBalanceLevel.ordered
        val labels = options.map { it.label }
        val current = AudioBalanceLevel.fromPrefValue(prefs.playerAudioBalanceLevel)
        val checked = options.indexOf(current).takeIf { it >= 0 } ?: 0

        AppPopup.singleChoice(
            context = this,
            title = "音频平衡",
            items = labels,
            checkedIndex = checked,
        ) { which, _ ->
            val picked = options.getOrNull(which) ?: AudioBalanceLevel.Off
            prefs.playerAudioBalanceLevel = picked.prefValue
            val engine = player
            if (engine is ExoPlayerEngine) {
                engine.setAudioBalanceLevel(picked)
                AppToast.show(this, "音频平衡：${picked.label}")
            } else {
                AppToast.show(this, "当前播放器内核不支持音频平衡")
            }
            refreshSettings()
        }
    }

    private fun refreshSettings() {
        val prefs = BiliClient.prefs
        val p = lastPlay
        val qn = session.targetQn.takeIf { it > 0 } ?: p?.currentQn ?: LIVE_QN_ORIGINAL
        val qLabel = liveQnLabel(qn, p)
        val lineLabel =
            p?.lines
                ?.getOrNull((session.lineOrder - 1).coerceAtLeast(0))
                ?.let { "线路 ${it.order}" }
                ?: "自动"
        val engineLabel =
            when (player?.kind ?: session.engineKind) {
                PlayerEngineKind.IjkPlayer -> "IjkPlayer"
                PlayerEngineKind.ExoPlayer -> "ExoPlayer"
            }
        val balanceLabel = AudioBalanceLevel.fromPrefValue(prefs.playerAudioBalanceLevel).label
        val list =
            listOf(
                PlayerSettingsAdapter.SettingItem(key = LivePlayerSettingKeys.QUALITY, title = "清晰度", subtitle = qLabel),
                PlayerSettingsAdapter.SettingItem(key = LivePlayerSettingKeys.LINE, title = "线路选择", subtitle = lineLabel),
                PlayerSettingsAdapter.SettingItem(
                    key = LivePlayerSettingKeys.HIGH_BITRATE,
                    title = "提高直播码率",
                    subtitle = if (session.highBitrateEnabled) "开" else "关",
                ),
                PlayerSettingsAdapter.SettingItem(key = LivePlayerSettingKeys.AUDIO_BALANCE, title = "音频平衡", subtitle = balanceLabel),
                PlayerSettingsAdapter.SettingItem(key = LivePlayerSettingKeys.PLAYER_ENGINE, title = "播放器内核", subtitle = engineLabel),
                PlayerSettingsAdapter.SettingItem(key = LivePlayerSettingKeys.DEBUG_INFO, title = "调试信息", subtitle = if (session.debugEnabled) "开" else "关"),
            )
        (binding.recyclerSettings.adapter as? PlayerSettingsAdapter)?.submit(list)
    }

    private fun toggleLiveHighBitrate() {
        val enabled = !session.highBitrateEnabled
        session = session.copy(highBitrateEnabled = enabled, lineOrder = 1, originFailCount = 0)
        resetPlaybackRecoveryState()
        refreshSettings()
        AppToast.show(this, "提高直播码率：${if (enabled) "开" else "关"}")
        lifecycleScope.launch { loadAndPlay(initial = false) }
    }

    private fun resetPlaybackRecoveryState() {
        autoFailoverJob?.cancel()
        autoFailoverJob = null
        autoFailoverWindowStartAtMs = 0L
        autoFailoverSwitchCount = 0
        autoFailoverLastSwitchAtMs = 0L
        autoFailoverInFlight = false
        behindLiveWindowWindowStartAtMs = 0L
        behindLiveWindowRecoverCount = 0
        behindLiveWindowLastRecoverAtMs = 0L
    }

    private fun showPlayerEngineDialog() {
        val currentKind = player?.kind ?: session.engineKind
        val items = listOf("ExoPlayer", "IjkPlayer")
        val checked = if (currentKind == PlayerEngineKind.IjkPlayer) 1 else 0
        AppPopup.singleChoice(
            context = this,
            title = "播放器内核",
            items = items,
            checkedIndex = checked,
        ) { which, _ ->
            val picked = if (which == 1) PlayerEngineKind.IjkPlayer else PlayerEngineKind.ExoPlayer
            if (picked == currentKind) return@singleChoice
            fun doSwitch() {
                val sessionJson = session.copy(engineKind = picked).toEngineSwitchJsonString()
                val restart =
                    Intent(this, LivePlayerActivity::class.java).apply {
                        putExtra(EXTRA_ROOM_ID, roomId)
                        putExtra(EXTRA_TITLE, roomTitle)
                        putExtra(EXTRA_UNAME, roomUname)
                        putExtra(EXTRA_ENGINE_SWITCH_SESSION_JSON, sessionJson)
                    }
                startActivity(restart)
                finish()
            }

            if (picked == PlayerEngineKind.IjkPlayer) {
                IjkPlayerPluginUi.ensureInstalled(this) {
                    doSwitch()
                }
            } else {
                doSwitch()
            }
        }
    }

    private fun toggleControls() {
        if (isTouchLocked()) return
        val willShow = !controlsVisible
        if (!willShow) binding.settingsPanel.visibility = View.GONE
        setControlsVisible(willShow)
    }

    private fun setControlsVisible(visible: Boolean) {
        val hadControlsFocus = hasControlsFocus()
        val nextControlsVisible = visible && !isTouchLocked()
        val show = nextControlsVisible || binding.settingsPanel.visibility == View.VISIBLE
        if (!show && controlsVisible) rememberOsdFocusBeforeHide()
        controlsVisible = nextControlsVisible
        binding.topBar.visibility = if (show) View.VISIBLE else View.GONE
        binding.bottomBar.visibility = if (show) View.VISIBLE else View.GONE
        if (!show) PlayerOsdHoverLabel.hide(binding)
        upQuickCard.updateUi()
        if (!show && hadControlsFocus) binding.root.requestFocus()

        onTouchOverlayStateChanged()
        restartAutoHideTimer()
    }

    private fun restartAutoHideTimer() {
        autoHideJob?.cancel()
        if (isTouchLocked()) return
        if (!controlsVisible) return
        if (binding.settingsPanel.visibility == View.VISIBLE) return
        val token = lastInteractionAtMs
        autoHideJob =
            lifecycleScope.launch {
                delay(AUTO_HIDE_MS)
                if (token != lastInteractionAtMs) return@launch
                if (binding.settingsPanel.visibility == View.VISIBLE) return@launch
                if (controlsVisible) setControlsVisible(false)
            }
    }

    private fun rememberOsdFocusBeforeHide() {
        val focused = currentFocus ?: return
        val focusIsInOsd =
            binding.topBar.hasFocus() ||
                binding.cardUpQuick.hasFocus() ||
                binding.bottomBar.hasFocus()
        if (focusIsInOsd) osdFocusReturn.capture(focused)
    }

    private fun focusLastOsdControlOrFirst() {
        binding.root.post {
            if (!osdFocusReturn.restoreAndClear(postOnFail = false)) focusFirstControl()
        }
    }

    private fun focusFirstControl(): Boolean {
        return requestFocusControlNow(binding.btnPlayPause) || requestFocusControlNow(binding.btnBack)
    }

    private fun requestFocusControlNow(view: View?): Boolean {
        val target = view ?: return false
        if (!target.isShown) return false
        if (!target.isEnabled) return false
        if (!target.isFocusable) return false
        return target.requestFocus()
    }

    private fun focusAdvancedControl(): Boolean {
        return binding.btnAdvanced.requestFocus()
    }

    private fun focusSettingsPanel() {
        binding.recyclerSettings.post {
            val child = binding.recyclerSettings.getChildAt(0)
            if (child != null) {
                child.requestFocus()
                return@post
            }

            binding.recyclerSettings.scrollToPosition(0)
            binding.recyclerSettings.post {
                val first = binding.recyclerSettings.getChildAt(0)
                (first ?: binding.recyclerSettings).requestFocus()
            }
        }
    }

    private fun hasControlsFocus(): Boolean {
        if (binding.settingsPanel.visibility == View.VISIBLE) return true
        return binding.topBar.hasFocus() ||
            binding.cardUpQuick.hasFocus() ||
            binding.bottomBar.hasFocus()
    }

    private fun initTouchGestures() {
        if (!BiliClient.prefs.playerTouchGesturesEnabled) {
            releaseTouchGestures()
            return
        }
        if (touchController != null) return
        touchController =
            PlayerTouchController(createLiveTouchHost(), requirePlayerTouchOverlayBinding(binding)).also { controller ->
                controller.install()
            }
    }

    private fun releaseTouchGestures() {
        touchController?.release()
        touchController = null
    }

    private fun isTouchLocked(): Boolean = touchController?.isTouchLocked() == true

    private fun onTouchOverlayStateChanged() {
        touchController?.onControlsStateChanged()
    }

    private fun createLiveTouchHost(): PlayerTouchGestureHost {
        return object : PlayerTouchGestureHost {
            override val activity: android.app.Activity
                get() = this@LivePlayerActivity
            override val binding: ActivityPlayerBinding
                get() = this@LivePlayerActivity.binding
            override val lifecycleScope: LifecycleCoroutineScope
                get() = this@LivePlayerActivity.lifecycleScope
            override val player: BlblPlayerEngine?
                get() = this@LivePlayerActivity.player
            override val controlsVisibleForTouch: Boolean
                get() = controlsVisible
            override val isSidePanelVisible: Boolean
                get() = this@LivePlayerActivity.binding.settingsPanel.visibility == View.VISIBLE
            override val isBottomCardPanelVisible: Boolean = false
            override val isCommentImageViewerVisible: Boolean = false

            override fun setControlsVisibleFromTouch(visible: Boolean) {
                setControlsVisible(visible)
            }

            override fun closeSidePanelFromTouch(): Boolean {
                if (this@LivePlayerActivity.binding.settingsPanel.visibility != View.VISIBLE) return false
                setControlsVisible(true)
                settingsPanelReturnFocus.restoreAndClear(fallback = this@LivePlayerActivity.binding.btnAdvanced, postOnFail = false)
                this@LivePlayerActivity.binding.settingsPanel.visibility = View.GONE
                onTouchOverlayStateChanged()
                return true
            }

            override fun togglePlayPauseFromTouch() {
                val engine = player ?: return
                val willPlay = !engine.isPlaying
                if (willPlay) engine.play() else engine.pause()
                showSeekHint(if (willPlay) "播放" else "暂停", hold = false)
            }

            override fun noteUserInteractionFromTouch() {
                noteUserInteraction()
            }

            override fun showTouchHint(text: String, hold: Boolean) {
                showSeekHint(text, hold)
            }

            override fun scheduleHideTouchHint() {
                scheduleHideSeekHint()
            }
        }
    }

    private fun noteUserInteraction() {
        lastInteractionAtMs = SystemClock.uptimeMillis()
        restartAutoHideTimer()
    }

    private fun isInteractionKey(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_DPAD_UP,
            KeyEvent.KEYCODE_DPAD_DOWN,
            KeyEvent.KEYCODE_DPAD_LEFT,
            KeyEvent.KEYCODE_DPAD_RIGHT,
            KeyEvent.KEYCODE_DPAD_CENTER,
            KeyEvent.KEYCODE_ENTER,
            KeyEvent.KEYCODE_NUMPAD_ENTER,
            KeyEvent.KEYCODE_SPACE,
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_ESCAPE,
            KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE,
            KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE,
            KeyEvent.KEYCODE_MENU,
            KeyEvent.KEYCODE_SETTINGS,
            KeyEvent.KEYCODE_INFO,
            KeyEvent.KEYCODE_GUIDE,
            -> true
            else -> false
        }
    }

    private fun isExitKey(keyCode: Int): Boolean {
        return when (keyCode) {
            KeyEvent.KEYCODE_BACK,
            KeyEvent.KEYCODE_ESCAPE, 
            KeyEvent.KEYCODE_BUTTON_B, 
            -> true
            else -> false
        }
    }

    private fun isPlayerTeardownInProgress(): Boolean {
        return exitRequested || isFinishing || isDestroyed
    }

    private fun shouldSuppressPlayerError(error: Throwable): Boolean {
        if (!isPlayerTeardownInProgress()) return false
        val playbackException = error as? PlaybackException
        val errorLabel = playbackException?.errorCodeName ?: (error.message ?: error::class.java.simpleName)
        AppLog.i(
            "LivePlayer",
            "ignorePlayerError teardown=1 finishing=${if (isFinishing) 1 else 0} destroyed=${if (isDestroyed) 1 else 0} " +
                "exitRequested=${if (exitRequested) 1 else 0} type=$errorLabel",
        )
        return true
    }

    private fun shouldAutoFailoverOnError(error: PlaybackException): Boolean {
        
        return when (error.errorCode) {
            PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW,
            PlaybackException.ERROR_CODE_IO_BAD_HTTP_STATUS,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_FAILED,
            PlaybackException.ERROR_CODE_IO_NETWORK_CONNECTION_TIMEOUT,
            -> true
            else -> false
        }
    }

    private fun tryRecoverBehindLiveWindow(error: PlaybackException): Boolean {
        if (error.errorCode != PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) return false
        if (isFinishing || isDestroyed) return false
        if (autoFailoverInFlight) return false

        
        
        val engine = (player as? ExoPlayerEngine) ?: return false
        val exo = engine.exoPlayer

        val nowMs = SystemClock.elapsedRealtime()
        if (behindLiveWindowWindowStartAtMs <= 0L || nowMs - behindLiveWindowWindowStartAtMs > BEHIND_LIVE_WINDOW_RECOVER_WINDOW_MS) {
            behindLiveWindowWindowStartAtMs = nowMs
            behindLiveWindowRecoverCount = 0
        }
        if (nowMs - behindLiveWindowLastRecoverAtMs < BEHIND_LIVE_WINDOW_RECOVER_MIN_INTERVAL_MS) return false
        if (behindLiveWindowRecoverCount >= BEHIND_LIVE_WINDOW_MAX_RECOVERS) return false

        behindLiveWindowRecoverCount += 1
        behindLiveWindowLastRecoverAtMs = nowMs
        val recoverCount = behindLiveWindowRecoverCount
        AppLog.w("LivePlayer", "behindLiveWindow recover #$recoverCount")

        if (recoverCount <= 1) {
            runCatching { exo.seekToDefaultPosition() }
            exo.prepare()
            exo.playWhenReady = true
            return true
        }

        val currentIndex = (session.lineOrder - 1).coerceAtLeast(0)
        val url =
            lastPlay?.lines?.getOrNull(currentIndex)?.url
                ?: exo.currentMediaItem?.localConfiguration?.uri?.toString()
        if (url.isNullOrBlank()) return false

        runCatching { exo.stop() }
        runCatching { engine.setSource(PlaybackSource.Live(url = url)) }
        exo.prepare()
        exo.playWhenReady = true
        return true
    }

    private fun isSignedLiveUrl(url: String): Boolean {
        val u = url.trim()
        
        
        return u.contains('?')
    }

    private fun tryAutoFailoverOnError(error: Throwable): Boolean {
        if (isFinishing || isDestroyed) return false
        if (autoFailoverInFlight) return false

        val play = lastPlay ?: return false
        val lines = play.lines
        if (lines.size <= 1) return false

        val currentIndex = (session.lineOrder - 1).coerceIn(0, lines.lastIndex)

        val signedStartIndex =
            lines.indexOfFirst { isSignedLiveUrl(it.url) }.let { idx ->
                if (idx < 0) lines.size else idx.coerceIn(0, lines.size)
            }
        val originCount = signedStartIndex
        val signedCount = (lines.size - signedStartIndex).coerceAtLeast(0)
        val hasOrigin = originCount > 0
        val hasSigned = signedCount > 0

        
        
        
        val shouldFailover =
            when (error) {
                is PlaybackException -> shouldAutoFailoverOnError(error)
                else ->
                    
                    hasSigned && hasOrigin && currentIndex < signedStartIndex
            }
        if (!shouldFailover) return false

        val nowMs = SystemClock.elapsedRealtime()
        if (autoFailoverWindowStartAtMs <= 0L || nowMs - autoFailoverWindowStartAtMs > AUTO_FAILOVER_WINDOW_MS) {
            autoFailoverWindowStartAtMs = nowMs
            autoFailoverSwitchCount = 0
        }
        if (nowMs - autoFailoverLastSwitchAtMs < AUTO_FAILOVER_MIN_INTERVAL_MS) return false

        
        val maxSwitches = (lines.size - 1).coerceIn(1, AUTO_FAILOVER_MAX_SWITCHES)
        if (autoFailoverSwitchCount >= maxSwitches) return false

        val inSigned = currentIndex >= signedStartIndex
        val preferSigned = session.originFailCount >= ORIGIN_FAIL_BEFORE_SIGNED
        val phaseSigned = inSigned || !hasOrigin || (preferSigned && hasSigned)

        val nextIndex =
            if (!phaseSigned) {
                
                if (originCount <= 1) {
                    if (!hasSigned) return false
                    signedStartIndex
                } else {
                val nextOriginIndex = currentIndex + 1
                val reachEnd = nextOriginIndex >= originCount
                val switchToSigned =
                    hasSigned &&
                        (session.originFailCount + 1 >= ORIGIN_FAIL_BEFORE_SIGNED || reachEnd)
                when {
                    switchToSigned -> signedStartIndex
                    nextOriginIndex in 0 until originCount -> nextOriginIndex
                    else -> 0
                }
                }
            } else {
                
                if (!hasSigned) return false
                if (currentIndex < signedStartIndex) {
                    signedStartIndex
                } else {
                    if (signedCount <= 1) return false
                    val nextSignedIndex = currentIndex + 1
                    if (nextSignedIndex < lines.size) nextSignedIndex else signedStartIndex
                }
            }
        if (nextIndex == currentIndex) return false

        val fromOrder = lines[currentIndex].order
        val toOrder = lines[nextIndex].order
        val errorLabel =
            when (error) {
                is PlaybackException -> error.errorCodeName
                else -> error::class.java.simpleName
            }
        AppLog.w("LivePlayer", "autoFailover error=$errorLabel line=$fromOrder -> $toOrder")

        autoFailoverSwitchCount += 1
        autoFailoverLastSwitchAtMs = nowMs
        autoFailoverInFlight = true
        autoFailoverJob?.cancel()

        
        runCatching { player?.stop() }

        session =
            if (!phaseSigned) {
                val nextFail = (session.originFailCount + 1).coerceAtLeast(0)
                val switchedToSigned = nextIndex >= signedStartIndex && hasSigned
                session.copy(
                    lineOrder = nextIndex + 1,
                    originFailCount = if (switchedToSigned) ORIGIN_FAIL_BEFORE_SIGNED else nextFail,
                )
            } else {
                session.copy(lineOrder = nextIndex + 1)
            }
        refreshSettings()
        AppToast.show(this, "线路 $fromOrder 失败，尝试线路 $toOrder")

        autoFailoverJob =
            lifecycleScope.launch {
                try {
                    loadAndPlay(initial = false)
                } finally {
                    autoFailoverInFlight = false
                }
            }
        return true
    }

    private suspend fun loadAndPlay(initial: Boolean) {
        val engine = player ?: return
        try {
            val info = BiliApi.liveRoomInfo(roomId)
            realRoomId = info.roomId
            lastLiveStatus = info.liveStatus
            updateLiveUpQuickCardOwner(info)

            val title = info.title.ifBlank { roomTitle }
            binding.tvTitle.text =
                buildString {
                    append(title.ifBlank { "直播间 $realRoomId" })
                    if (roomUname.isNotBlank()) append(" · ").append(roomUname)
                }

            val qn = session.targetQn.takeIf { it > 0 } ?: 150
            val play = BiliApi.livePlayUrl(realRoomId, qn, highBitrateEnabled = session.highBitrateEnabled)
            lastPlay = play
            if (play.lines.isNotEmpty()) {
                
                val safeLineOrder = session.lineOrder.takeIf { it in 1..play.lines.size } ?: 1
                if (safeLineOrder != session.lineOrder) session = session.copy(lineOrder = safeLineOrder)
                if (session.originFailCount >= ORIGIN_FAIL_BEFORE_SIGNED) {
                    val signedStartIndex =
                        play.lines.indexOfFirst { isSignedLiveUrl(it.url) }.let { idx ->
                            if (idx < 0) play.lines.size else idx.coerceIn(0, play.lines.size)
                        }
                    val signedStartOrder = signedStartIndex + 1
                    
                    if (signedStartIndex in play.lines.indices && session.lineOrder < signedStartOrder) {
                        session = session.copy(lineOrder = signedStartOrder)
                    }
                }
            }
            refreshSettings()

            val pickedLine =
                play.lines.getOrNull((session.lineOrder - 1).coerceAtLeast(0))
                    ?: play.lines.firstOrNull()
            if (pickedLine == null) error("No playable live url")

            debug.reset()
            debug.cdnHost = runCatching { Uri.parse(pickedLine.url).host?.lowercase(Locale.US) }.getOrNull()
            liveHlsDebugInfo = null
            engine.setSource(PlaybackSource.Live(url = pickedLine.url))
            engine.prepare()
            engine.playWhenReady = true
            reportLiveRoomEntry(realRoomId)

            if (initial) {
                connectDanmaku()
                startTemporarySuperChatPreview()
                loadInitialSuperChats(realRoomId)
            }
        } catch (t: Throwable) {
            if (t is CancellationException) throw t
            resetBufferingOverlayState()
            AppLog.e("LivePlayer", "loadAndPlay failed", t)
            val e = t as? BiliApiException
            val msg = e?.let { "B 站返回：${it.apiCode} / ${it.apiMessage}" } ?: (t.message ?: "未知错误")
            AppToast.showLong(this, msg)
        }
    }

    private fun recordBufferingTransferBytes(bytes: Long) {
        bufferingOverlayController.recordTransferBytes(bytes)
    }

    private fun resetBufferingOverlayState() {
        bufferingOverlayController.reset()
    }

    private fun showBufferingOverlay(resetSpeedSample: Boolean = true) {
        bufferingOverlayController.onBufferingStarted(resetSpeedSample = resetSpeedSample)
    }

    private fun connectDanmaku() {
        messageClient?.close()
        messageClient = null
        val rid = realRoomId.takeIf { it > 0 } ?: return
        AppLog.i("LiveDanmaku", "connect room=$rid")

        messageClient =
            LiveMessageClient(
                roomId = rid,
                onDanmaku = { ev ->
                    runOnUiThread(
                        Runnable {
                            appendLiveDanmakuEvent(ev)
                        },
                    )
                },
                onSuperChat = { ev ->
                    runOnUiThread(
                        Runnable {
                            superChatOverlay.submit(ev)
                        },
                    )
                },
                onSuperChatDelete = { ids ->
                    runOnUiThread(
                        Runnable {
                            superChatOverlay.delete(ids)
                        },
                    )
                },
                onStatus = { msg ->
                    runOnUiThread(
                        Runnable {
                            AppLog.d("LiveWs", msg)
                        },
                    )
                },
            )

        lifecycleScope.launch {
            runCatching { messageClient?.connect() }
                .onFailure { AppLog.w("LiveWs", "connect failed", it) }
        }
    }

    private fun liveDanmakuPositionMs(): Long {
        val base = liveDanmakuBaseUptimeMs
        if (base <= 0L) return 0L
        val posMs = SystemClock.elapsedRealtime() - base
        return posMs.coerceIn(0L, Int.MAX_VALUE.toLong())
    }

    private fun liveDanmakuAppendTimeMs(): Int {
        val nowMs = liveDanmakuPositionMs().toInt()
        val lastMs = liveDanmakuLastAppendMs
        val safeMs = if (lastMs == Int.MIN_VALUE) nowMs else nowMs.coerceAtLeast(lastMs)
        liveDanmakuLastAppendMs = safeMs
        return safeMs
    }

    private fun appendLiveDanmakuEvent(ev: LiveMessageClient.LiveDanmakuEvent) {
        if (player == null) return
        val timeMs = liveDanmakuAppendTimeMs()

        
        if (session.danmaku.enabled) {
            val d =
                Danmaku(
                    timeMs = timeMs,
                    mode = 1,
                    text = ev.text,
                    color = ev.color,
                    fontSize = 25,
                    weight = 0,
                    attr = 0,
                )
            binding.danmakuView.appendDanmakus(listOf(d), maxItems = 2000, alreadySorted = true)
        }

        
        liveCommentEntries.add(Triple(timeMs, ev.text, ev.color))
        while (liveCommentEntries.size > 500) liveCommentEntries.removeAt(0)
        if (binding.liveCommentPanel.visibility == View.VISIBLE) {
            renderLiveCommentList()
        }
    }

    
    private fun renderLiveCommentList() {
        val container = binding.liveCommentListInner
        container.removeAllViews()
        val density = resources.displayMetrics.density
        for ((_, text, color) in liveCommentEntries) {
            val tv = TextView(this).apply {
                this.text = text
                textSize = 14f
                setTextColor(if (color != 0 && color != 0xFFFFFF) color or 0xFF000000.toInt() else 0xFFFFFFFF.toInt())
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                isFocusable = false
            }
            container.addView(
                tv,
                LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply {
                    bottomMargin = (4 * density).toInt()
                },
            )
        }
        binding.liveCommentList.post { binding.liveCommentList.fullScroll(View.FOCUS_DOWN) }
    }

    
    private fun toggleLiveHistoryPanel() {
        if (liveHistoryOpen) {
            hideLiveHistoryPanel()
        } else {
            showLiveHistoryPanel()
        }
    }

    private fun showLiveHistoryPanel() {
        liveHistoryOpen = true
        binding.tvLiveCommentTitle.setText(R.string.live_history_panel_title)
        binding.liveCommentPanel.visibility = View.VISIBLE
        renderLiveCommentList()
        binding.liveCommentList.post {
            binding.liveCommentList.requestFocus()
            binding.liveCommentList.fullScroll(View.FOCUS_DOWN)
        }
        if (BiliClient.prefs.liveCommentStyle == 1) {
            binding.danmakuView.visibility = View.GONE
        }
        AppToast.show(this, "历史评论（最多 500 条）")
    }

    private fun hideLiveHistoryPanel() {
        liveHistoryOpen = false
        binding.liveCommentPanel.visibility = View.GONE
        
        if (BiliClient.prefs.liveCommentStyle != 1) {
            binding.danmakuView.visibility =
                if (session.danmaku.enabled) View.VISIBLE else View.GONE
        }
    }

    private fun applyLiveCommentStyle() {
        val style = BiliClient.prefs.liveCommentStyle
        if (style == 1) {
            
            binding.liveCommentPanel.visibility = View.VISIBLE
            binding.tvLiveCommentTitle.setText(R.string.live_comment_panel_title)
            renderLiveCommentList()
            binding.danmakuView.visibility = View.GONE
            superChatOverlay.setEnabled(false)
        } else {
            
            if (!liveHistoryOpen) {
                binding.liveCommentPanel.visibility = View.GONE
            } else {
                binding.tvLiveCommentTitle.setText(R.string.live_history_panel_title)
            }
            binding.danmakuView.visibility =
                if (session.danmaku.enabled) View.VISIBLE else View.GONE
            superChatOverlay.setEnabled(session.danmaku.enabled)
        }
        updateLiveCommentStyleButton()
    }

    
    private fun openLiveDanmakuSend() {
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(this, getString(blbl.cat3399.R.string.live_comment_need_login))
            return
        }
        val room = realRoomId.takeIf { it > 0L } ?: roomId
        if (room <= 0L) {
            AppToast.show(this, "直播间信息尚未就绪")
            return
        }
        AppPopup.input(
            context = this,
            title = "发送直播评论",
            initial = "",
            hint = getString(blbl.cat3399.R.string.live_comment_send_hint),
            positiveText = getString(blbl.cat3399.R.string.live_comment_send),
            validate = { it.isNotBlank() && it.trim().length <= 100 },
            onPositive = { text ->
                lifecycleScope.launch {
                    try {
                        withContext(Dispatchers.IO) {
                            BiliApi.liveDanmakuSend(roomId = room, text = text)
                        }
                        if (isFinishing || isDestroyed) return@launch
                        AppToast.show(this@LivePlayerActivity, getString(blbl.cat3399.R.string.live_comment_send_ok))
                    } catch (t: Throwable) {
                        if (t is CancellationException) throw t
                        val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "发送失败")
                        AppToast.show(this@LivePlayerActivity, msg.take(60))
                    }
                }
            },
        )
    }

    
    private fun showLiveMoreMenu() {
        val style = BiliClient.prefs.liveCommentStyle
        val rows =
            listOf(
                "查看贡献榜",
                if (style == 1) "评论区样式：直接显示（点击切换）" else "评论区样式：弹幕显示（点击切换）",
                "发送评论",
            )
        AppPopup.singleChoice(
            context = this,
            title = "直播互动",
            items = rows,
            checkedIndex = -1,
            cancelable = true,
        ) { index, _ ->
            when (index) {
                0 -> showLiveRankPanel()
                1 -> {
                    BiliClient.prefs.liveCommentStyle = if (style == 1) 0 else 1
                    applyLiveCommentStyle()
                    AppToast.show(
                        this,
                        if (style == 1) "已切换为弹幕显示" else "已切换为直接显示",
                    )
                }
                2 -> openLiveDanmakuSend()
            }
        }
    }

    
    private fun loadLiveRankTop5() {
        val room = realRoomId.takeIf { it > 0L } ?: roomId
        if (room <= 0L) return
        lifecycleScope.launch {
            try {
                var ownerUid = roomUid.takeIf { it > 0L } ?: 0L
                if (ownerUid <= 0L) {
                    val extra = withContext(Dispatchers.IO) { BiliApi.liveRoomExtraInfo(room) }
                    if (extra.uid > 0L) {
                        ownerUid = extra.uid
                        if (roomUid <= 0L) roomUid = ownerUid
                    }
                }
                if (ownerUid <= 0L) return@launch
                val result =
                    withContext(Dispatchers.IO) {
                        BiliApi.liveRoomRank(roomId = room, uid = ownerUid)
                    }
                if (isFinishing || isDestroyed) return@launch
                val top5 = result.items.take(5)
                if (top5.isEmpty()) {
                    binding.rankTop5Row.visibility = View.GONE
                    binding.tvRankTop5.visibility = View.GONE
                    return@launch
                }
                
                val faces = listOf(binding.rankFace1, binding.rankFace2, binding.rankFace3, binding.rankFace4, binding.rankFace5)
                for (i in 0 until 5) {
                    val face = top5.getOrNull(i)?.face
                    val iv = faces[i]
                    if (face.isNullOrBlank()) {
                        iv.setImageResource(R.drawable.ic_fm_image)
                    } else {
                        iv.setImageResource(R.drawable.ic_fm_image)
                        ImageLoader.loadInto(iv, face)
                    }
                }
                binding.rankTop5Row.visibility = View.VISIBLE
                binding.tvRankTop5.text = top5.joinToString("  ") { "榜${it.rank} ${it.uname}" }.take(40)
                binding.tvRankTop5.visibility = View.VISIBLE
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                AppLog.w("LiveRank", "top5 load failed", t)
            }
        }
    }

    private fun loadInitialSuperChats(roomId: Long) {
        superChatLoadJob?.cancel()
        superChatLoadJob =
            lifecycleScope.launch {
                try {
                    val items =
                        BiliApi.liveSuperChats(roomId)
                            .sortedBy { it.startTimeSeconds ?: Long.MAX_VALUE }
                    items.forEach(superChatOverlay::submit)
                    AppLog.i("LiveSuperChat", "initial room=$roomId count=${items.size}")
                } catch (t: Throwable) {
                    if (t is CancellationException) throw t
                    AppLog.w("LiveSuperChat", "initial fetch failed room=$roomId", t)
                }
            }
    }

    private fun startTemporarySuperChatPreview() {
        if (!BuildConfig.DEBUG || !TEMPORARY_SUPER_CHAT_PREVIEW_ENABLED) return
        if (temporarySuperChatPreviewStarted) return
        temporarySuperChatPreviewStarted = true

        val nowSeconds = System.currentTimeMillis() / 1_000L
        temporarySuperChatPreviewItems(nowSeconds).forEach(superChatOverlay::submit)
        AppLog.i(
            "LiveSuperChat",
            "temporary preview queued count=5 danmakuEnabled=${session.danmaku.enabled}",
        )
    }

    private fun temporarySuperChatPreviewItems(nowSeconds: Long): List<LiveSuperChat> {
        fun preview(
            id: Long,
            user: String,
            price: Long,
            message: String,
            headerColor: String,
            bodyColor: String,
            priceColor: String,
            messageColor: String = "#FFFFFF",
        ) = LiveSuperChat(
            id = id,
            uid = 0L,
            userName = user,
            userFaceUrl = roomFace,
            userNameColor = "#4A4A4A",
            price = price,
            message = message,
            backgroundImageUrl = null,
            backgroundColor = headerColor,
            backgroundBottomColor = bodyColor,
            backgroundPriceColor = priceColor,
            messageFontColor = messageColor,
            startTimeSeconds = nowSeconds,
            endTimeSeconds = nowSeconds + TEMPORARY_SUPER_CHAT_EXPIRY_SECONDS,
            durationSeconds = TEMPORARY_SUPER_CHAT_DURATION_SECONDS,
        )

        return listOf(
            preview(
                id = -1L,
                user = "SC 预览 · 1/5",
                price = 30L,
                message = "第一条：短文本与基础蓝色样式。",
                headerColor = "#EDF5FF",
                bodyColor = "#2A60B2",
                priceColor = "#7497CD",
            ),
            preview(
                id = -2L,
                user = "SC 预览 · 2/5",
                price = 50L,
                message = "第二条：稍长一些的醒目留言，用来观察两行正文的间距和换行效果。",
                headerColor = "#E1F7FF",
                bodyColor = "#287D9B",
                priceColor = "#5B9CB5",
            ),
            preview(
                id = -3L,
                user = "SC 预览 · 3/5",
                price = 100L,
                message = "第三条：测试暖黄色价格档位，以及浅色头部中的昵称、金额对比度。",
                headerColor = "#FFF4D6",
                bodyColor = "#C88A1A",
                priceColor = "#B97B12",
            ),
            preview(
                id = -4L,
                user = "SC 预览 · 4/5",
                price = 500L,
                message = "第四条：这是更长的橙色 SC。它会继续走正式队列，验证卡片切换、正文最多四行以及底部 OSD 出现时的避让位置。",
                headerColor = "#FFE8D5",
                bodyColor = "#D75A24",
                priceColor = "#C65324",
            ),
            preview(
                id = -5L,
                user = "SC 预览 · 5/5",
                price = 1_000L,
                message = "第五条：高金额红色样式，预览结束后会自动淡出。",
                headerColor = "#FFE1E6",
                bodyColor = "#A9233D",
                priceColor = "#C54C63",
            ),
        )
    }

    private fun showQualityDialog() {
        val play = lastPlay ?: run {
            AppToast.show(this, "暂无可用清晰度")
            return
        }
        val available = play.acceptQn.ifEmpty { play.qnDesc.keys.sortedDescending() }.distinct()
        if (available.isEmpty()) {
            AppToast.show(this, "暂无可用清晰度")
            return
        }
        val optionsAvailable = available.sortedWith(compareBy({ it != LIVE_QN_ORIGINAL }, { -it }))
        val options = optionsAvailable.map { q -> liveQnLabel(q, play) }
        val current = session.targetQn.takeIf { it > 0 } ?: play.currentQn
        val checked =
            optionsAvailable.indexOf(current).takeIf { it >= 0 }
                ?: optionsAvailable.indexOf(LIVE_QN_ORIGINAL).takeIf { it >= 0 }
                ?: 0
        AppPopup.singleChoice(
            context = this,
            title = "清晰度",
            items = options,
            checkedIndex = checked,
        ) { which, _ ->
            val picked = optionsAvailable.getOrNull(which) ?: return@singleChoice
            session = session.copy(targetQn = picked, lineOrder = 1, originFailCount = 0)
            resetPlaybackRecoveryState()
            refreshSettings()
            lifecycleScope.launch { loadAndPlay(initial = false) }
        }
    }

    private fun showLineDialog() {
        val play = lastPlay ?: run {
            AppToast.show(this, "暂无可用线路")
            return
        }
        val lines = play.lines
        if (lines.isEmpty()) {
            AppToast.show(this, "暂无可用线路")
            return
        }
        val options = lines.map { "线路 ${it.order}" }
        val checked = (session.lineOrder - 1).coerceIn(0, lines.size - 1)
        AppPopup.singleChoice(
            context = this,
            title = "线路",
            items = options,
            checkedIndex = checked,
        ) { which, _ ->
            val picked = lines.getOrNull(which) ?: return@singleChoice
            session =
                if (isSignedLiveUrl(picked.url)) {
                    session.copy(lineOrder = picked.order)
                } else {
                    
                    session.copy(lineOrder = picked.order, originFailCount = 0)
                }
            resetPlaybackRecoveryState()
            refreshSettings()
            lifecycleScope.launch { loadAndPlay(initial = false) }
        }
    }

    private fun updatePlayPauseIcon(isPlaying: Boolean) {
        val icon = if (isPlaying) blbl.cat3399.R.drawable.ic_player_pause else blbl.cat3399.R.drawable.ic_player_play
        binding.btnPlayPause.setImageResource(icon)
    }

    private fun updateDanmakuButton() {
        binding.btnDanmaku.imageTintList = null
        binding.btnDanmaku.isSelected = session.danmaku.enabled
    }

    private fun updateDebugOverlay() {
        val enabled = session.debugEnabled
        binding.tvDebug.visibility = if (enabled) View.VISIBLE else View.GONE
        binding.danmakuView.setDebugEnabled(enabled)
        debugJob?.cancel()
        if (!enabled) return
        val engine = player ?: return
        debugJob =
            lifecycleScope.launch {
                while (isActive) {
                    binding.tvDebug.text =
                        when (engine) {
                            is ExoPlayerEngine -> buildExoDebugText(engine.exoPlayer)
                            is IjkPlayerEngine -> buildIjkDebugText(engine)
                            else -> "-"
                        }
                    delay(500)
                }
            }
    }

    private fun buildExoDebugText(exo: ExoPlayer): String {
        updateDebugVideoStatsFromCounters(exo)
        val trackFormat = pickSelectedVideoFormat(exo)
        val trackBitrate =
            trackFormat
                ?.let { format ->
                    format.averageBitrate.takeIf { it > 0 }
                        ?: format.bitrate.takeIf { it > 0 }
                        ?: format.peakBitrate.takeIf { it > 0 }
                }?.toLong()
        val brBps = liveHlsDebugInfo?.recentBitrateBps?.takeIf { it > 0L } ?: trackBitrate
        val state =
            when (exo.playbackState) {
                Player.STATE_IDLE -> "IDLE"
                Player.STATE_BUFFERING -> "BUFFERING"
                Player.STATE_READY -> "READY"
                Player.STATE_ENDED -> "ENDED"
                else -> exo.playbackState.toString()
            }
        return buildString {
            appendLiveDebugHeader(this, state = state, isPlaying = exo.isPlaying, playWhenReady = exo.playWhenReady)
            append("pos=").append(exo.currentPosition).append("ms")
            append(" buf=").append(exo.bufferedPosition).append("ms")
            append(" spd=").append(String.format(Locale.US, "%.2f", exo.playbackParameters.speed))
            append('\n')

            append("res=").append(buildDebugResolutionText(exo, trackFormat))
            append(" fps=").append(formatDebugFps(debug.renderFps) ?: formatDebugFps(debug.videoInputFps ?: trackFormat?.frameRate) ?: "-")
            append(" br=").append(formatBitrateKbps(brBps))
            appendCdnHostLine(this)

            buildDebugDisplayText()?.let { disp ->
                append("disp=").append(disp)
                append('\n')
            }

            append("decoder=").append(shortenDebugValue(debug.videoDecoderName ?: "-", maxChars = 64))
            append(" drop=").append(debug.droppedFramesTotal)
            append(" rebuffer=").append(debug.rebufferCount)
            append('\n')

            appendLiveHlsDebug(this)
            appendDanmakuDebug(this)
        }
    }

    private fun buildIjkDebugText(engine: IjkPlayerEngine): String {
        val snap = engine.debugSnapshot()
        val state =
            when (snap.playbackState) {
                Player.STATE_IDLE -> "IDLE"
                Player.STATE_BUFFERING -> "BUFFERING"
                Player.STATE_READY -> "READY"
                Player.STATE_ENDED -> "ENDED"
                else -> snap.playbackState.toString()
            }
        val resolution =
            if ((snap.videoWidth ?: 0) > 0 && (snap.videoHeight ?: 0) > 0) {
                "${snap.videoWidth}x${snap.videoHeight}"
            } else {
                "-"
            }
        val decoder =
            when (snap.videoDecoder) {
                tv.danmaku.ijk.media.player.IjkMediaPlayer.FFP_PROPV_DECODER_MEDIACODEC -> "MediaCodec"
                tv.danmaku.ijk.media.player.IjkMediaPlayer.FFP_PROPV_DECODER_AVCODEC -> "avcodec"
                else -> "-"
            }
        return buildString {
            appendLiveDebugHeader(this, state = state, isPlaying = snap.isPlaying, playWhenReady = snap.playWhenReady)
            append("pos=").append(snap.positionMs).append("ms")
            append(" buf=").append(snap.bufferedPositionMs).append("ms")
            append(" spd=").append(String.format(Locale.US, "%.2f", snap.playbackSpeed))
            append('\n')

            append("res=").append(resolution)
            append(" fps=").append(formatDebugFps(snap.fpsOutput ?: snap.fpsDecode) ?: "-")
            append(" br=").append(formatBitrateKbps(snap.bitRate.takeIf { it > 0L }))
            appendCdnHostLine(this)

            buildDebugDisplayText()?.let { disp ->
                append("disp=").append(disp)
                append('\n')
            }

            append("decoder=").append(decoder)
            if (snap.tcpSpeed > 0L) {
                append(" net=").append(String.format(Locale.US, "%.2f", snap.tcpSpeed * 8.0 / 1_000_000.0)).append("Mbps")
            }
            append(" vCache=").append(snap.videoCachedDurationMs.coerceAtLeast(0L)).append("ms")
            append(" aCache=").append(snap.audioCachedDurationMs.coerceAtLeast(0L)).append("ms")
            append('\n')

            appendDanmakuDebug(this)
        }
    }

    private fun appendLiveDebugHeader(sb: StringBuilder, state: String, isPlaying: Boolean, playWhenReady: Boolean) {
        val play = lastPlay
        sb.append("room=").append(realRoomId)
        sb.append(" qn=").append(play?.currentQn ?: 0)
        sb.append(" line=").append(session.lineOrder)
        sb.append(" state=").append(state)
        sb.append(" playing=").append(isPlaying)
        sb.append(" pwr=").append(playWhenReady)
        sb.append('\n')
    }

    private fun appendCdnHostLine(sb: StringBuilder) {
        val cdnHost = debug.videoTransferHost?.trim().takeIf { !it.isNullOrBlank() } ?: debug.cdnHost?.trim().takeIf { !it.isNullOrBlank() } ?: "-"
        if (cdnHost.length <= 42) {
            sb.append(" cdn=").append(cdnHost)
            sb.append('\n')
        } else {
            sb.append('\n')
            sb.append("cdn=").append(cdnHost)
            sb.append('\n')
        }
    }

    private fun appendLiveHlsDebug(sb: StringBuilder) {
        val info = liveHlsDebugInfo ?: return
        sb.append("hls=")
        var hasField = false
        info.lastSegmentSequence?.let {
            sb.append("seq=").append(it)
            hasField = true
        } ?: info.mediaSequence?.let {
            sb.append("seq=").append(it)
            hasField = true
        }
        info.targetDurationSec?.let {
            if (hasField) sb.append(' ')
            sb.append("td=").append(formatDebugSeconds(it)).append('s')
            hasField = true
        }
        info.lastSegmentUri?.substringAfterLast('/')?.takeIf { it.isNotBlank() }?.let {
            if (hasField) sb.append(' ')
            sb.append("seg=").append(shortenDebugValue(it, maxChars = 24))
            hasField = true
        }
        if (info.segmentCount > 0) {
            if (hasField) sb.append(' ')
            sb.append("win=").append(info.segmentCount)
            hasField = true
        }
        if (!hasField) sb.append('-')
        sb.append('\n')

        if (!info.lastAuxRaw.isNullOrBlank()) {
            sb.append("aux=").append(shortenDebugValue(info.lastAuxRaw, maxChars = 48)).append('\n')
        }
        if (!info.mapUri.isNullOrBlank()) {
            sb.append("map=").append(shortenDebugValue(info.mapUri.substringAfterLast('/'), maxChars = 32)).append('\n')
        }
    }

    private fun appendDanmakuDebug(sb: StringBuilder) {
        runCatching { binding.danmakuView.getDebugStats() }.getOrNull()?.let { dm ->
            sb.append("dm=").append(if (dm.configEnabled) "on" else "off")
            sb.append(" fps=").append(String.format(Locale.US, "%.1f", dm.drawFps))
            sb.append(" act=").append(dm.lastFrameActive)
            sb.append(" pend=").append(dm.lastFramePending)
            sb.append(" hit=").append(dm.lastFrameCachedDrawn).append('/').append(dm.lastFrameActive)
            sb.append(" fb=").append(dm.lastFrameFallbackDrawn)
            sb.append(" q=").append(dm.queueDepth)
            if (dm.invalidateFull) {
                sb.append(" inv=full")
            } else {
                sb.append(" inv=").append(dm.invalidateTopPx).append('-').append(dm.invalidateBottomPx)
            }
        }
    }

    private fun reportLiveRoomEntry(roomId: Long) {
        if (roomId <= 0L || lastLiveStatus != 1) return
        if (liveEntryReportedRoomId == roomId) return
        liveEntryReportedRoomId = roomId
        lifecycleScope.launch {
            runCatching { BiliApi.liveRoomEntryAction(roomId) }
                .onSuccess { AppLog.d("LiveReport", "entry ok room=$roomId") }
                .onFailure { t ->
                    if (t is CancellationException) throw t
                    if (liveEntryReportedRoomId == roomId) liveEntryReportedRoomId = 0L
                    AppLog.w("LiveReport", "entry failed room=$roomId", t)
                }
        }
    }

    private fun updateDebugVideoStatsFromCounters(exo: ExoPlayer) {
        val nowMs = SystemClock.elapsedRealtime()
        val counters = exo.videoDecoderCounters ?: return
        counters.ensureUpdated()
        debug.droppedFramesTotal = maxOf(debug.droppedFramesTotal, counters.droppedBufferCount.toLong())

        val count = counters.renderedOutputBufferCount
        val lastCount = debug.renderedFramesLastCount
        val lastAt = debug.renderedFramesLastAtMs
        debug.renderedFramesLastCount = count
        debug.renderedFramesLastAtMs = nowMs

        if (lastCount == null || lastAt == null) return
        val deltaMs = nowMs - lastAt
        val deltaFrames = count - lastCount
        if (deltaMs <= 0L || deltaMs > 10_000L) return
        if (deltaFrames <= 0) return
        val instantFps = (deltaFrames * 1000f) / deltaMs.toFloat()
        debug.renderFps = debug.renderFps?.let { it * 0.7f + instantFps * 0.3f } ?: instantFps
    }

    private fun buildDebugResolutionText(exo: ExoPlayer, trackFormat: Format?): String {
        val videoSize = exo.videoSize
        val width = videoSize.width.takeIf { it > 0 } ?: debug.videoInputWidth ?: 0
        val height = videoSize.height.takeIf { it > 0 } ?: debug.videoInputHeight ?: 0
        if (width > 0 && height > 0) return "${width}x${height}"
        val trackWidth = trackFormat?.width?.takeIf { it > 0 } ?: 0
        val trackHeight = trackFormat?.height?.takeIf { it > 0 } ?: 0
        return if (trackWidth > 0 && trackHeight > 0) "${trackWidth}x${trackHeight}" else "-"
    }

    private fun pickSelectedVideoFormat(exo: ExoPlayer): Format? {
        val tracks = exo.currentTracks
        for (group in tracks.groups) {
            if (!group.isSelected) continue
            for (i in 0 until group.length) {
                if (!group.isTrackSelected(i)) continue
                val format = group.getTrackFormat(i)
                val mime = format.sampleMimeType ?: ""
                if (mime.startsWith("video/")) return format
            }
        }
        return null
    }

    private fun formatDebugFps(fps: Float?): String? {
        val value = fps?.takeIf { it > 0f } ?: return null
        val rounded = value.roundToInt().toFloat()
        return if (abs(value - rounded) < 0.05f) rounded.toInt().toString() else String.format(Locale.US, "%.1f", value)
    }

    private fun formatDebugSeconds(seconds: Double): String {
        val rounded = seconds.roundToInt().toDouble()
        return if (abs(seconds - rounded) < 0.01) rounded.toInt().toString() else String.format(Locale.US, "%.2f", seconds)
    }

    private fun formatBitrateKbps(bps: Long?): String {
        val value = bps?.takeIf { it > 0L } ?: return "-"
        return String.format(Locale.US, "%.1fkbps", value / 1000.0)
    }

    private fun shortenDebugValue(value: String, maxChars: Int): String {
        val text = value.trim()
        if (text.length <= maxChars) return text
        return text.take(maxChars - 1) + "…"
    }

    private fun buildDebugDisplayText(): String? {
        val display = binding.root.display ?: return null
        val hz = display.refreshRate.takeIf { it > 0f }
        if (Build.VERSION.SDK_INT < 23) {
            return hz?.let { String.format(Locale.US, "%.0fHz", it) } ?: "-"
        }
        val mode = display.mode
        val w = mode.physicalWidth.takeIf { it > 0 } ?: 0
        val h = mode.physicalHeight.takeIf { it > 0 } ?: 0
        val mhz = mode.refreshRate.takeIf { it > 0f } ?: hz
        val hzText = mhz?.let { String.format(Locale.US, "%.0fHz", it) } ?: "-"
        if (w <= 0 || h <= 0) return hzText
        return "${w}x${h}@${hzText}"
    }

    private fun liveQnLabel(qn: Int, play: BiliApi.LivePlayUrl?): String {
        val fromApi = play?.qnDesc?.get(qn)?.takeIf { it.isNotBlank() }
        if (fromApi != null) return fromApi
        return when (qn) {
            30000 -> "杜比"
            20000 -> "4K"
            10000 -> "原画"
            400 -> "蓝光"
            250 -> "超清"
            150 -> "高清"
            80 -> "流畅"
            else -> qn.toString()
        }
    }

    private fun LiveSession.toEngineSwitchJsonString(): String {
        return JSONObject().apply {
            put("v", 1)
            put("engineKind", engineKind.prefValue)
            put("targetQn", targetQn)
            put("lineOrder", lineOrder)
            put("originFailCount", originFailCount)
            put("highBitrateEnabled", highBitrateEnabled)
            put("danmakuEnabled", danmaku.enabled)
            put("danmakuOpacity", danmaku.opacity.toDouble())
            put("danmakuTextSizeSp", danmaku.textSizeSp.toDouble())
            put("danmakuFontWeight", danmaku.fontWeight.prefValue)
            put("danmakuStrokeWidthPx", danmaku.strokeWidthPx)
            put("danmakuSpeedLevel", danmaku.speedLevel)
            put("danmakuArea", danmaku.area.toDouble())
            put("danmakuLaneDensity", danmaku.laneDensity.prefValue)
            put("debugEnabled", debugEnabled)
        }.toString()
    }

    private fun LiveSession.restoreFromEngineSwitchJsonString(raw: String): LiveSession {
        val obj = runCatching { JSONObject(raw) }.getOrNull() ?: return this

        fun optFloat(key: String, fallback: Float): Float {
            val value = obj.optDouble(key, fallback.toDouble()).toFloat()
            if (!value.isFinite()) return fallback
            return value
        }

        fun optInt(key: String, fallback: Int): Int {
            return obj.optInt(key, fallback)
        }

        fun normalizeDanmakuStrokeWidthPx(value: Int): Int {
            return when {
                value <= 1 -> 0
                value <= 3 -> 2
                value <= 5 -> 4
                else -> 6
            }
        }

        val restoredEngineKind = PlayerEngineKind.fromPrefValue(obj.optString("engineKind", engineKind.prefValue))
        val restoredTargetQn = optInt("targetQn", targetQn).takeIf { it > 0 } ?: targetQn
        val restoredLineOrder = optInt("lineOrder", lineOrder).takeIf { it > 0 } ?: lineOrder
        val restoredOriginFailCount = optInt("originFailCount", originFailCount).coerceAtLeast(0)
        val restoredHighBitrateEnabled = obj.optBoolean("highBitrateEnabled", highBitrateEnabled)
        val restoredDanmakuEnabled = obj.optBoolean("danmakuEnabled", danmaku.enabled)
        val restoredDanmakuOpacity = optFloat("danmakuOpacity", danmaku.opacity).coerceIn(0.05f, 1.0f)
        val restoredDanmakuTextSizeSp = optFloat("danmakuTextSizeSp", danmaku.textSizeSp).coerceIn(10f, 60f)
        val restoredDanmakuFontWeight = DanmakuFontWeight.fromPrefValue(obj.optString("danmakuFontWeight", danmaku.fontWeight.prefValue))
        val restoredDanmakuStrokeWidthPx = normalizeDanmakuStrokeWidthPx(optInt("danmakuStrokeWidthPx", danmaku.strokeWidthPx))
        val restoredDanmakuSpeedLevel = optInt("danmakuSpeedLevel", danmaku.speedLevel).coerceIn(1, 10)
        val restoredDanmakuArea = AppPrefs.normalizeLegacyDanmakuAreaCompat(optFloat("danmakuArea", danmaku.area))
        val restoredDanmakuLaneDensity = DanmakuLaneDensity.fromPrefValue(obj.optString("danmakuLaneDensity", danmaku.laneDensity.prefValue))
        val restoredDebugEnabled = obj.optBoolean("debugEnabled", debugEnabled)

        return copy(
            engineKind = restoredEngineKind,
            targetQn = restoredTargetQn,
            lineOrder = restoredLineOrder,
            originFailCount = restoredOriginFailCount,
            highBitrateEnabled = restoredHighBitrateEnabled,
            danmaku =
                danmaku.copy(
                    enabled = restoredDanmakuEnabled,
                    opacity = restoredDanmakuOpacity,
                    textSizeSp = restoredDanmakuTextSizeSp,
                    fontWeight = restoredDanmakuFontWeight,
                    strokeWidthPx = restoredDanmakuStrokeWidthPx,
                    speedLevel = restoredDanmakuSpeedLevel,
                    area = restoredDanmakuArea,
                    laneDensity = restoredDanmakuLaneDensity,
                ),
            debugEnabled = restoredDebugEnabled,
        )
    }

    private data class LiveSession(
        val engineKind: PlayerEngineKind = PlayerEngineKind.fromPrefValue(BiliClient.prefs.playerEngineKind),
        val targetQn: Int = LIVE_QN_ORIGINAL,
        val lineOrder: Int = 1,
        val originFailCount: Int = 0,
        val highBitrateEnabled: Boolean = BiliClient.prefs.liveHighBitrateEnabled,
        val danmaku: DanmakuSessionSettings =
            DanmakuSessionSettings(
                enabled = BiliClient.prefs.danmakuEnabled,
                opacity = BiliClient.prefs.danmakuOpacity,
                textSizeSp = BiliClient.prefs.danmakuTextSizeSp,
                fontWeight = DanmakuFontWeight.fromPrefValue(BiliClient.prefs.danmakuFontWeight),
                strokeWidthPx = BiliClient.prefs.danmakuStrokeWidthPx,
                speedLevel = BiliClient.prefs.danmakuSpeed,
                area = BiliClient.prefs.danmakuArea,
                laneDensity = DanmakuLaneDensity.fromPrefValue(BiliClient.prefs.danmakuLaneDensity),
            ),
        val debugEnabled: Boolean = BiliClient.prefs.playerDebugEnabled,
    )

    companion object {
        private fun formatLiveScoreSuffix(score: Long): String = ""

        const val EXTRA_ROOM_ID = "room_id"
        const val EXTRA_TITLE = "title"
        const val EXTRA_UNAME = "uname"

        private const val EXTRA_ENGINE_SWITCH_SESSION_JSON = "engine_switch_session_json"
        private const val LIVE_QN_ORIGINAL = 10_000

        private const val AUTO_HIDE_MS = 4_000L
        private const val SEEK_HINT_HIDE_DELAY_MS = 900L
        
        private const val TEMPORARY_SUPER_CHAT_PREVIEW_ENABLED = false
        private const val TEMPORARY_SUPER_CHAT_DURATION_SECONDS = 5L
        private const val TEMPORARY_SUPER_CHAT_EXPIRY_SECONDS = 5 * 60L
        private const val BACK_DOUBLE_PRESS_WINDOW_MS = 2_500L
        private const val AUTO_FAILOVER_WINDOW_MS = 12_000L
        private const val AUTO_FAILOVER_MIN_INTERVAL_MS = 1_200L
        private const val AUTO_FAILOVER_MAX_SWITCHES = 6
        private const val ORIGIN_FAIL_BEFORE_SIGNED = 5
        private const val BEHIND_LIVE_WINDOW_RECOVER_WINDOW_MS = 15_000L
        private const val BEHIND_LIVE_WINDOW_RECOVER_MIN_INTERVAL_MS = 1_200L
        private const val BEHIND_LIVE_WINDOW_MAX_RECOVERS = 2
    }
}
