package blbl.cat3399.feature.message

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R
import blbl.cat3399.core.api.BiliApi
import blbl.cat3399.core.api.BiliApiException
import blbl.cat3399.core.image.ImageLoader
import blbl.cat3399.core.image.ImageUrl
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.core.ui.BaseActivity
import blbl.cat3399.core.ui.Immersive
import blbl.cat3399.core.ui.cloneInUserScale
import androidx.lifecycle.lifecycleScope
import blbl.cat3399.databinding.ActivityMessageListBinding
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


class MessageListActivity : BaseActivity() {
    private var _binding: ActivityMessageListBinding? = null
    private val binding get() = _binding!!
    private val adapter = SessionAdapter()
    private var loading = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        _binding = ActivityMessageListBinding.inflate(layoutInflater.cloneInUserScale(this))
        setContentView(binding.root)
        Immersive.apply(this, BiliClient.prefs.fullscreenEnabled)

        binding.btnBack.setOnClickListener { finish() }
        binding.recycler.layoutManager = LinearLayoutManager(this)
        binding.recycler.adapter = adapter
        binding.swipeRefresh.setOnRefreshListener { load(initial = true) }
        binding.swipeRefresh.post { load(initial = true) }
    }

    override fun onResume() {
        super.onResume()
        if (adapter.itemCount == 0 && !loading) load(initial = true)
    }

    private fun load(initial: Boolean = false) {
        if (loading) return
        if (!BiliClient.cookies.hasSessData()) {
            binding.swipeRefresh.isRefreshing = false
            binding.tvEmpty.text = getString(R.string.message_need_login)
            binding.tvEmpty.visibility = View.VISIBLE
            return
        }
        loading = true
        if (initial) {
            binding.tvEmpty.visibility = View.GONE
            binding.swipeRefresh.isRefreshing = true
        }
        lifecycleScope.launch {
            try {
                val sessions =
                    withContext(Dispatchers.IO) {
                        BiliApi.messageSessions()
                    }
                if (isFinishing || isDestroyed) return@launch
                if (sessions.isEmpty()) {
                    adapter.submit(emptyList())
                    binding.tvEmpty.visibility = View.VISIBLE
                } else {
                    adapter.submit(sessions)
                    binding.tvEmpty.visibility = View.GONE
                }
            } catch (t: Throwable) {
                if (t is CancellationException) throw t
                val msg = (t as? BiliApiException)?.apiMessage ?: (t.message ?: "加载失败")
                AppToast.show(this@MessageListActivity, msg.take(60))
            } finally {
                loading = false
                binding.swipeRefresh.isRefreshing = false
            }
        }
    }

    override fun onDestroy() {
        _binding = null
        super.onDestroy()
    }

    private inner class SessionAdapter : RecyclerView.Adapter<SessionAdapter.Vh>() {
        private val items = ArrayList<BiliApi.MessageSession>()

        fun submit(list: List<BiliApi.MessageSession>) {
            items.clear()
            items.addAll(list)
            notifyDataSetChanged()
        }

        override fun getItemCount(): Int = items.size

        override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): Vh {
            val root =
                LinearLayout(parent.context).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(14), dp(8), dp(14), dp(8))
                    background = androidx.core.content.ContextCompat.getDrawable(parent.context, R.drawable.blbl_focus_bg_round)
                    isFocusable = true
                    isClickable = true
                }
            val row = LinearLayout(parent.context).apply { orientation = LinearLayout.HORIZONTAL }
            val avatar = ImageView(parent.context).apply {
                layoutParams = LinearLayout.LayoutParams(dp(56), dp(56))
                scaleType = ImageView.ScaleType.CENTER_CROP
            }
            val col = LinearLayout(parent.context).apply {
                orientation = LinearLayout.VERTICAL
                layoutParams = LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f).apply {
                    marginStart = dp(12)
                }
            }
            val name = TextView(parent.context).apply {
                textSize = 16f
                setTextColor(androidx.core.content.ContextCompat.getColor(parent.context, R.color.blbl_text))
                maxLines = 1
            }
            val last = TextView(parent.context).apply {
                textSize = 13f
                setTextColor(androidx.core.content.ContextCompat.getColor(parent.context, R.color.blbl_text_secondary))
                maxLines = 1
                setPadding(0, dp(4), 0, 0)
            }
            val badge = TextView(parent.context).apply {
                textSize = 11f
                setTextColor(0xFFFFFFFF.toInt())
                setPadding(dp(8), dp(2), dp(8), dp(2))
                gravity = android.view.Gravity.CENTER
                visibility = View.GONE
            }
            col.addView(name)
            col.addView(last)
            row.addView(avatar)
            row.addView(col)
            root.addView(row)
            root.addView(
                TextView(parent.context).apply {
                    textSize = 10f
                    setTextColor(androidx.core.content.ContextCompat.getColor(parent.context, R.color.blbl_text_secondary))
                    visibility = View.GONE
                },
            )
            return Vh(root, avatar, name, last, badge)
        }

        override fun onBindViewHolder(holder: Vh, position: Int) {
            val session = items[position]
            holder.name.text = session.talkerName.ifBlank { "用户${session.talkerId}" }
            holder.last.text = session.lastMsgText.ifBlank { if (session.lastMsgType == 2) "[图片]" else "" }
            holder.badge.visibility = if (session.unreadCount > 0) View.VISIBLE else View.GONE
            holder.badge.text = if (session.unreadCount > 99) "99+" else session.unreadCount.toString()
            holder.badge.background = android.graphics.drawable.GradientDrawable().apply {
                shape = android.graphics.drawable.GradientDrawable.OVAL
                setColor(0xFFFB7299.toInt())
            }
            holder.avatar.setImageResource(R.drawable.ic_nav_msg)
            session.talkerFace?.let { face ->
                ImageLoader.loadInto(holder.avatar, ImageUrl.avatar(face))
            }
            holder.root.setOnClickListener {
                startActivity(
                    Intent(this@MessageListActivity, ChatActivity::class.java)
                        .putExtra(ChatActivity.EXTRA_TALKER_ID, session.talkerId)
                        .putExtra(ChatActivity.EXTRA_TALKER_NAME, session.talkerName.ifBlank { "用户${session.talkerId}" }),
                )
            }
        }

        inner class Vh(
            val root: View,
            val avatar: ImageView,
            val name: TextView,
            val last: TextView,
            val badge: TextView,
        ) : RecyclerView.ViewHolder(root)
    }

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
}
