package blbl.cat3399.feature.live

import blbl.cat3399.core.ui.TabContentFocusTarget

interface LivePageFocusTarget : TabContentFocusTarget {
    
    fun requestFocusFirstCardFromTab(): Boolean

    
    fun requestFocusFirstCardFromContentSwitch(): Boolean

    
    fun requestFocusFirstCardFromBackToTab0(): Boolean = requestFocusFirstCardFromContentSwitch()

    override fun requestFocusPrimaryItemFromTab(): Boolean = requestFocusFirstCardFromTab()

    override fun requestFocusPrimaryItemFromContentSwitch(): Boolean = requestFocusFirstCardFromContentSwitch()

    override fun requestFocusPrimaryItemFromBackToTab0(): Boolean = requestFocusFirstCardFromBackToTab0()
}
