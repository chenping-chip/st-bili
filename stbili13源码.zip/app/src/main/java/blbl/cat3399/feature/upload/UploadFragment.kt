package blbl.cat3399.feature.upload

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import blbl.cat3399.R
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.ui.AppToast
import blbl.cat3399.databinding.FragmentUploadBinding


class UploadFragment : Fragment() {
    private var _binding: FragmentUploadBinding? = null
    private val binding get() = _binding!!

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View {
        _binding = FragmentUploadBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        binding.btnUploadVideo.setOnClickListener { launchUpload(mode = 0) }
        binding.btnCapture.setOnClickListener { launchUpload(mode = 1) }
        binding.btnDraw.setOnClickListener { launchUpload(mode = 2) }
        binding.btnLoginHint.setOnClickListener {
            AppToast.show(requireContext(), "登录后即可投稿")
        }
    }

    private fun launchUpload(mode: Int) {
        if (!BiliClient.cookies.hasSessData()) {
            AppToast.show(requireContext(), getString(R.string.upload_login_required))
            return
        }
        val intent = Intent(requireContext(), UploadActivity::class.java)
        if (mode == 1) intent.putExtra(UploadActivity.EXTRA_START_CAPTURE, true)
        startActivity(intent)
    }

    override fun onDestroyView() {
        _binding = null
        super.onDestroyView()
    }
}
