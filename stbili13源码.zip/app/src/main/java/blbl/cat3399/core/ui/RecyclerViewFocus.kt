package blbl.cat3399.core.ui

import androidx.recyclerview.widget.RecyclerView
import blbl.cat3399.R


internal fun RecyclerView.requestFocusAdapterPositionReliable(
    position: Int,
    smoothScroll: Boolean,
    isAlive: () -> Boolean,
    maxAttempts: Int = 30,
    attemptDelayMs: Long = 16L,
    onFocused: () -> Unit,
): Boolean {
    val nextToken = ((getTag(R.id.tag_recycler_focus_request_token) as? Int) ?: 0) + 1
    setTag(R.id.tag_recycler_focus_request_token, nextToken)
    return requestFocusAdapterPositionReliableInternal(
        position = position,
        smoothScroll = smoothScroll,
        isAlive = isAlive,
        token = nextToken,
        attemptsLeft = maxAttempts.coerceAtLeast(0),
        attemptDelayMs = attemptDelayMs,
        scrolled = false,
        onFocused = onFocused,
    )
}

private fun RecyclerView.requestFocusAdapterPositionReliableInternal(
    position: Int,
    smoothScroll: Boolean,
    isAlive: () -> Boolean,
    token: Int,
    attemptsLeft: Int,
    attemptDelayMs: Long,
    scrolled: Boolean,
    onFocused: () -> Unit,
): Boolean {
    val currentToken = getTag(R.id.tag_recycler_focus_request_token) as? Int
    if (currentToken != token) return false
    if (!isAlive()) return false

    
    
    if (!isAttachedToWindow) {
        if (attemptsLeft <= 0) return false
        postDelayedIfAlive(
            delayMillis = attemptDelayMs,
            isAlive = { isAlive() && (getTag(R.id.tag_recycler_focus_request_token) as? Int) == token },
        ) {
            requestFocusAdapterPositionReliableInternal(
                position = position,
                smoothScroll = smoothScroll,
                isAlive = isAlive,
                token = token,
                attemptsLeft = attemptsLeft - 1,
                attemptDelayMs = attemptDelayMs,
                scrolled = scrolled,
                onFocused = onFocused,
            )
        }
        return true
    }

    val adapter =
        adapter
            ?: run {
                if (attemptsLeft <= 0) return false
                postDelayedIfAlive(
                    delayMillis = attemptDelayMs,
                    isAlive = { isAlive() && isAttachedToWindow && (getTag(R.id.tag_recycler_focus_request_token) as? Int) == token },
                ) {
                    requestFocusAdapterPositionReliableInternal(
                        position = position,
                        smoothScroll = smoothScroll,
                        isAlive = isAlive,
                        token = token,
                        attemptsLeft = attemptsLeft - 1,
                        attemptDelayMs = attemptDelayMs,
                        scrolled = scrolled,
                        onFocused = onFocused,
                    )
                }
                return true
            }
    val itemCount = adapter.itemCount
    if (position !in 0 until itemCount) return false

    val itemView = findViewHolderForAdapterPosition(position)?.itemView
    if (itemView != null && itemView.requestFocus()) {
        onFocused()
        return true
    }

    
    if (!scrolled) {
        if (smoothScroll) smoothScrollToPosition(position) else scrollToPosition(position)
    }

    if (attemptsLeft <= 0) return false
    postDelayedIfAlive(
        delayMillis = attemptDelayMs,
        isAlive = { isAlive() && isAttachedToWindow && (getTag(R.id.tag_recycler_focus_request_token) as? Int) == token },
    ) {
        requestFocusAdapterPositionReliableInternal(
            position = position,
            smoothScroll = smoothScroll,
            isAlive = isAlive,
            token = token,
            attemptsLeft = attemptsLeft - 1,
            attemptDelayMs = attemptDelayMs,
            scrolled = true,
            onFocused = onFocused,
        )
    }
    return true
}
