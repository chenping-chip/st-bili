package blbl.cat3399.core.api

import blbl.cat3399.core.net.BiliClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONObject


object DanmakuPostApi {

    
    suspend fun post(
        bvid: String,
        cid: Long,
        progressMs: Long,
        text: String,
        mode: Int,
        color: Int,
    ): Boolean {
        val csrf = BiliClient.cookies.getCookieValue("bili_jct").orEmpty()
        if (csrf.isBlank()) {
            throw BiliApiException(apiCode = -101, apiMessage = "未登录或登录已过期")
        }
        val msg = text.trim()
        if (msg.isBlank()) {
            throw BiliApiException(apiCode = -400, apiMessage = "弹幕内容为空")
        }

        val form =
            mapOf(
                "type" to "1",
                "oid" to cid.toString(),
                "msg" to msg,
                "bvid" to bvid,
                "progress" to progressMs.coerceAtLeast(0L).toString(),
                "color" to (color and 0xFFFFFF).toString(),
                "fontsize" to "25",
                "pool" to "0",
                "mode" to mode.toString(),
                "plat" to "1",
                "csrf" to csrf,
            )

        val json: JSONObject =
            withContext(Dispatchers.IO) {
                BiliClient.postFormJson(
                    url = "https://api.bilibili.com/x/v2/dm/post",
                    form = form,
                    headers =
                        mapOf(
                            "Referer" to "https://www.bilibili.com/video/$bvid",
                            "Origin" to "https://www.bilibili.com",
                        ),
                )
            }
        val code = json.optInt("code", -1)
        if (code != 0) {
            val message = json.optString("message", "发送失败")
            blbl.cat3399.core.log.AppLog.w(
                "DanmakuPost",
                "post failed code=$code msg=$message progress=$progressMs",
            )
            throw BiliApiException(apiCode = code, apiMessage = message)
        }
        return true
    }

    const val MODE_SCROLL = 1
    const val MODE_BOTTOM = 4
    const val MODE_TOP = 5
    const val MODE_ADVANCED = 7

    const val COLOR_WHITE = 0xFFFFFF
    const val COLOR_RED = 0xFF0000
    const val COLOR_ORANGE = 0xFF8C00
    const val COLOR_YELLOW = 0xFFFF00
    const val COLOR_GREEN = 0x00FF00
    const val COLOR_BLUE = 0x00A1D6
    const val COLOR_PURPLE = 0xFF00FF
    const val COLOR_PINK = 0xFF66CC
}
