package blbl.cat3399.core.ui

import androidx.recyclerview.widget.RecyclerView


internal fun RecyclerView.requestFocusFirstItemOrSelfAfterRefresh(
    itemCount: Int,
    isAlive: () -> Boolean,
    smoothScroll: Boolean = false,
    onDone: (focusedFirstItem: Boolean) -> Unit = {},
): Boolean {
    val focused = rootView?.findFocus()
    val canMoveFocus = focused == null || FocusTreeUtils.isDescendantOf(focused, this)

    if (itemCount <= 0) {
        if (canMoveFocus) requestFocus()
        onDone(false)
        return canMoveFocus
    }

    if (!canMoveFocus) {
        if (smoothScroll) smoothScrollToPosition(0) else scrollToPosition(0)
        onDone(false)
        return true
    }

    return requestFocusAdapterPositionReliable(
        position = 0,
        smoothScroll = smoothScroll,
        isAlive = isAlive,
        onFocused = { onDone(true) },
    )
}

internal fun parkFocusForDataSetReset(vararg controllers: DpadGridController?) {
    for (c in controllers) c?.parkFocusForDataSetReset()
}

internal fun unparkFocusAfterDataSetReset(vararg controllers: DpadGridController?) {
    for (c in controllers) c?.unparkFocusAfterDataSetReset()
}
