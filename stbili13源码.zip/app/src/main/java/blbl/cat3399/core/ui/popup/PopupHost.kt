package blbl.cat3399.core.ui.popup

import androidx.activity.ComponentActivity
import android.os.Handler
import android.os.Looper
import android.util.TypedValue
import android.view.Gravity
import android.view.KeyEvent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.core.graphics.Insets
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import blbl.cat3399.R
import blbl.cat3399.core.ui.FocusReturn
import blbl.cat3399.core.ui.FocusTreeUtils
import blbl.cat3399.core.ui.userScaledContext
import java.lang.ref.WeakReference
import kotlin.math.max

data class PopupModalSizing(
    val widthRatio: Float = 0.90f,
    val maxWidthDp: Float = 600f,
    val maxHeightRatio: Float = 0.90f,
)

internal class PopupHost private constructor(
    private val activity: ComponentActivity,
    private val contentRoot: FrameLayout,
    private val hostView: FrameLayout,
    private val modalLayer: FrameLayout,
) {
    private val mainHandler = Handler(Looper.getMainLooper())

    private var consumeBackLikeKeyUp: Boolean = false

    private var systemBarsInsets = Insets.NONE
    private var imeInsets = Insets.NONE

    private var modalEntry: ModalEntry? = null

    
    
    
    
    
    
    
    
    private var focusParkingView: View? = null
    private var focusParkingListener: ViewTreeObserver.OnGlobalFocusChangeListener? = null

    private data class FocusabilitySnapshot(
        val descendantFocusability: Int?,
        val isFocusable: Boolean,
        val isFocusableInTouchMode: Boolean,
    )

    private var underlyingFocusSnapshots: LinkedHashMap<View, FocusabilitySnapshot>? = null

    private data class ModalEntry(
        val rootView: View,
        val cancelable: Boolean,
        val preferredFocusView: View?,
        var lastFocusedView: WeakReference<View>?,
        val focusReturn: FocusReturn,
        val backCallback: OnBackPressedCallback,
        val focusListener: ViewTreeObserver.OnGlobalFocusChangeListener,
        val modalSizing: PopupModalSizing,
        val onDismiss: (() -> Unit)?,
        val onRestoreFocus: (() -> Boolean)?,
        val onBackPressed: (() -> Boolean)?,
        var dismissing: Boolean = false,
    )

    private fun blockUnderlyingFocus() {
        if (underlyingFocusSnapshots != null) return
        val snapshots = LinkedHashMap<View, FocusabilitySnapshot>()
        for (i in 0 until contentRoot.childCount) {
            val child = contentRoot.getChildAt(i) ?: continue
            if (child === hostView) continue
            snapshots[child] =
                FocusabilitySnapshot(
                    descendantFocusability = (child as? ViewGroup)?.descendantFocusability,
                    isFocusable = child.isFocusable,
                    isFocusableInTouchMode = child.isFocusableInTouchMode,
                )
            (child as? ViewGroup)?.descendantFocusability = ViewGroup.FOCUS_BLOCK_DESCENDANTS
            child.isFocusable = false
            child.isFocusableInTouchMode = false
        }
        underlyingFocusSnapshots = snapshots
    }

    private fun restoreUnderlyingFocus() {
        val snapshots = underlyingFocusSnapshots ?: return
        underlyingFocusSnapshots = null
        for ((view, snap) in snapshots) {
            (view as? ViewGroup)?.let { vg ->
                snap.descendantFocusability?.let { vg.descendantFocusability = it }
            }
            view.isFocusable = snap.isFocusable
            view.isFocusableInTouchMode = snap.isFocusableInTouchMode
        }
    }

    private fun ensureFocusParkingView(): View {
        val existing = focusParkingView
        if (existing != null) return existing

        val view =
            View(activity).apply {
                alpha = 0f
                isClickable = false
                isFocusable = false
                isFocusableInTouchMode = false
                importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
            }
        hostView.addView(
            view,
            FrameLayout.LayoutParams(
                 1,
                 1,
                 Gravity.START or Gravity.TOP,
            ),
        )
        focusParkingView = view
        return view
    }

    
    private fun parkFocusForRestore() {
        val parking = ensureFocusParkingView()
        parking.isFocusable = true
        parking.isFocusableInTouchMode = true

        if (focusParkingListener == null) {
            val listener =
                ViewTreeObserver.OnGlobalFocusChangeListener { _, newFocus ->
                    val v = focusParkingView ?: return@OnGlobalFocusChangeListener
                    if (newFocus == null || newFocus === v) return@OnGlobalFocusChangeListener
                    disableFocusParking()
                }
            focusParkingListener = listener
            runCatching { contentRoot.viewTreeObserver.addOnGlobalFocusChangeListener(listener) }
        }

        
        
        
        if (!parking.requestFocus()) {
            parking.post { parking.requestFocus() }
        }
    }

    
    private fun disableFocusParking() {
        focusParkingView?.let { v ->
            v.isFocusable = false
            v.isFocusableInTouchMode = false
        }

        val listener = focusParkingListener
        focusParkingListener = null
        if (listener != null) {
            runCatching { contentRoot.viewTreeObserver.removeOnGlobalFocusChangeListener(listener) }
        }
    }

    fun showModal(
        title: CharSequence?,
        contentView: View,
        cancelable: Boolean,
        actions: List<PopupAction>,
        preferredActionRole: PopupActionRole? = PopupActionRole.POSITIVE,
        autoFocus: Boolean = true,
        modalSizing: PopupModalSizing = PopupModalSizing(),
        onModalAttached: ((modalRoot: View) -> Unit)? = null,
        onDismiss: (() -> Unit)? = null,
        onRestoreFocus: (() -> Boolean)? = null,
        onBackPressed: (() -> Boolean)? = null,
    ): PopupHandle {
        checkMainThread()

        
        
        
        
        blockUnderlyingFocus()

        
        
        
        val inheritedFocusReturn = modalEntry?.focusReturn
        if (inheritedFocusReturn != null) {
            
            modalEntry?.dismissing = true
            
            
            parkFocusForRestore()
        }
        dismissModalInternal(animate = false, restoreFocus = false)

        val dialogContext = activity.userScaledContext()
        val root =
            LayoutInflater.from(dialogContext)
                .inflate(R.layout.view_popup_modal, modalLayer, false)

        val overlay = root.findViewById<View>(R.id.overlay)
        val card = root.findViewById<View>(R.id.card)
        val tvTitle = root.findViewById<TextView>(R.id.tv_title)
        val content = root.findViewById<FrameLayout>(R.id.content)
        val actionsRow = root.findViewById<LinearLayout>(R.id.actions)

        
        overlay.isFocusable = false
        overlay.isFocusableInTouchMode = false

        tvTitle.text = title
        val hasTitle = !title.isNullOrBlank()
        tvTitle.visibility = if (hasTitle) View.VISIBLE else View.GONE
        if (!hasTitle) {
            (content.layoutParams as? ViewGroup.MarginLayoutParams)?.let { lp ->
                lp.topMargin = 0
                content.layoutParams = lp
            }
        }

        content.removeAllViews()
        content.addView(
            contentView,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.WRAP_CONTENT,
            ),
        )

        
        card.isClickable = true
        card.isFocusable = false
        card.isFocusableInTouchMode = false
        (card as? ViewGroup)?.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS
        card.setOnClickListener {  }
        actionsRow.descendantFocusability = ViewGroup.FOCUS_AFTER_DESCENDANTS

        val focusReturn =
            inheritedFocusReturn
                ?: FocusReturn().also { it.capture(activity.window?.decorView?.findFocus()) }

        val backCallback =
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    val entry = modalEntry
                    if (entry?.onBackPressed?.invoke() == true) return
                    if (entry?.cancelable == true) dismissModal()
                }
            }
        activity.onBackPressedDispatcher.addCallback(backCallback)

        
        actionsRow.removeAllViews()
        actionsRow.visibility = if (actions.isEmpty()) View.GONE else View.VISIBLE
        var preferredFocusView: View? = null
        val actionViewsByRole = HashMap<PopupActionRole, View>(3)
        val actionViews = ArrayList<View>(actions.size)
        for ((idx, a) in actions.withIndex()) {
            val btn =
                LayoutInflater.from(dialogContext)
                .inflate(R.layout.item_popup_action, actionsRow, false)
            btn.id = View.generateViewId()
            val tv = btn.findViewById<TextView>(R.id.tv_text)
            tv.text = a.text
            btn.setOnClickListener {
                a.onClick?.invoke()
                if (a.dismissOnClick) {
                    
                    
                    val current = modalEntry
                    if (current != null && current.rootView === overlay) dismissModal()
                }
            }
            val lp =
                (btn.layoutParams as? ViewGroup.MarginLayoutParams)
                    ?: ViewGroup.MarginLayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT,
                    )
            if (idx > 0) lp.marginStart = dp(dialogContext, 10f)
            btn.layoutParams = lp
            actionsRow.addView(btn)
            actionViews += btn
            if (!actionViewsByRole.containsKey(a.role)) actionViewsByRole[a.role] = btn
        }
        wireActionButtonFocus(actionViews)

        if (preferredActionRole != null) {
            preferredFocusView = actionViewsByRole[preferredActionRole]
        }
        if (preferredFocusView == null) preferredFocusView = actionViewsByRole[PopupActionRole.POSITIVE]
        if (preferredFocusView == null) preferredFocusView = actionViewsByRole[PopupActionRole.NEUTRAL]
        if (preferredFocusView == null) preferredFocusView = actionViewsByRole[PopupActionRole.NEGATIVE]
        if (preferredFocusView == null) preferredFocusView = actionsRow.getChildAt(0)

        overlay.setOnClickListener {
            if (cancelable) dismissModal()
        }

        
        applyModalSizeAndInsets(dialogContext = dialogContext, modalRoot = overlay, card = card, sizing = modalSizing)

        
        val focusListener =
            ViewTreeObserver.OnGlobalFocusChangeListener { oldFocus, newFocus ->
                val entry = modalEntry
                if (entry == null) return@OnGlobalFocusChangeListener
                
                if (entry.dismissing) return@OnGlobalFocusChangeListener
                val modalRoot = entry.rootView

                if (!modalRoot.isAttachedToWindow) return@OnGlobalFocusChangeListener
                if (newFocus != null && FocusTreeUtils.isDescendantOf(newFocus, modalRoot)) {
                    entry.lastFocusedView = WeakReference(newFocus)
                    return@OnGlobalFocusChangeListener
                }
                if (newFocus == null) {
                    
                    
                    if (oldFocus != null && FocusTreeUtils.isDescendantOf(oldFocus, modalRoot)) {
                        entry.lastFocusedView = WeakReference(oldFocus)
                    }
                    modalRoot.post {
                        if (modalEntry !== entry) return@post
                        restoreModalFocus(entry)
                    }
                    return@OnGlobalFocusChangeListener
                }

                
                modalRoot.post {
                    if (modalEntry !== entry) return@post
                    restoreModalFocus(entry)
                }
            }

        contentRoot.viewTreeObserver.addOnGlobalFocusChangeListener(focusListener)

        
        modalLayer.addView(
            root,
            FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT,
                FrameLayout.LayoutParams.MATCH_PARENT,
            ),
        )

        onModalAttached?.invoke(overlay)

        
        overlay.alpha = 0f
        card.alpha = 0f
        card.scaleX = 0.96f
        card.scaleY = 0.96f
        overlay.animate().alpha(1f).setDuration(160L).start()
        card.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(180L).start()

        val entry =
            ModalEntry(
                rootView = overlay,
                cancelable = cancelable,
                preferredFocusView = preferredFocusView,
                lastFocusedView = null,
                focusReturn = focusReturn,
                backCallback = backCallback,
                focusListener = focusListener,
                modalSizing = modalSizing,
                onDismiss = onDismiss,
                onRestoreFocus = onRestoreFocus,
                onBackPressed = onBackPressed,
            )
        modalEntry = entry

        
        
        if (autoFocus) {
            overlay.post {
                if (modalEntry === entry) restoreModalFocus(entry)
            }
            overlay.postDelayed(
                {
                    if (modalEntry === entry && !isFocusInsideModal(entry.rootView)) {
                        restoreModalFocus(entry)
                    }
                },
                80L,
            )
        }

        return object : PopupHandle {
            override val isShowing: Boolean
                get() = modalEntry?.rootView === overlay && overlay.isAttachedToWindow

            override fun dismiss() {
                if (Looper.myLooper() != Looper.getMainLooper()) {
                    mainHandler.post { dismiss() }
                    return
                }
                if (modalEntry?.rootView !== overlay) return
                dismissModal()
            }
        }
    }

    fun dismissModal() {
        checkMainThread()
        dismissModalInternal(animate = true, restoreFocus = true)
    }

    fun applyInsets(insets: WindowInsetsCompat) {
        systemBarsInsets = insets.getInsets(WindowInsetsCompat.Type.systemBars())
        imeInsets = insets.getInsets(WindowInsetsCompat.Type.ime())
        modalEntry?.rootView?.let { modalRoot ->
            val entry = modalEntry ?: return@let
            val card = modalRoot.findViewById<View>(R.id.card) ?: return@let
            applyModalSizeAndInsets(
                dialogContext = modalRoot.context,
                modalRoot = modalRoot,
                card = card,
                sizing = entry.modalSizing,
            )
        }
    }

    private fun applyModalSizeAndInsets(
        dialogContext: android.content.Context,
        modalRoot: View,
        card: View,
        sizing: PopupModalSizing,
    ) {
        val bottom = max(systemBarsInsets.bottom, imeInsets.bottom)
        modalRoot.setPadding(systemBarsInsets.left, systemBarsInsets.top, systemBarsInsets.right, bottom)

        val dm = dialogContext.resources.displayMetrics
        val maxWidthPx = dp(dialogContext, sizing.maxWidthDp.coerceAtLeast(1f))
        val targetWidthPx =
            (dm.widthPixels * sizing.widthRatio.coerceIn(0.10f, 1.0f))
                .toInt()
                .coerceAtMost(maxWidthPx)
                .coerceAtLeast(1)
        val targetHeightPx =
            (dm.heightPixels * sizing.maxHeightRatio.coerceIn(0.10f, 1.0f))
                .toInt()
                .coerceAtLeast(1)
        (card.layoutParams as? FrameLayout.LayoutParams)?.let { lp ->
            if (lp.width != targetWidthPx) {
                lp.width = targetWidthPx
                card.layoutParams = lp
            }
        }
        (card.findViewById<View>(R.id.container) as? PopupModalLayout)?.maxHeightPx = targetHeightPx
    }

    private fun dp(context: android.content.Context, value: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, value, context.resources.displayMetrics).toInt()

    private fun findFirstFocusableDescendant(root: View): View? {
        if (root.isShown && root.isFocusable) return root
        val vg = root as? ViewGroup ?: return null
        for (i in 0 until vg.childCount) {
            val child = vg.getChildAt(i) ?: continue
            findFirstFocusableDescendant(child)?.let { return it }
        }
        return null
    }

    private fun wireActionButtonFocus(actionViews: List<View>) {
        for ((index, view) in actionViews.withIndex()) {
            val left = actionViews.getOrNull(index - 1)
            val right = actionViews.getOrNull(index + 1)
            view.nextFocusLeftId = (left ?: view).id
            view.nextFocusRightId = (right ?: view).id
        }
    }

    private fun isFocusInsideModal(modalRoot: View): Boolean {
        val focused = activity.window?.decorView?.findFocus() ?: return false
        return FocusTreeUtils.isDescendantOf(focused, modalRoot)
    }

    private fun restoreModalFocus(entry: ModalEntry) {
        val modalRoot = entry.rootView
        if (!modalRoot.isAttachedToWindow) return

        val last = entry.lastFocusedView?.get()
        if (last != null && last.isAttachedToWindow && last.isShown && last.isFocusable && last.requestFocus()) return

        val desired = entry.preferredFocusView
        if (desired != null && desired.isAttachedToWindow && desired.isShown && desired.isFocusable && desired.requestFocus()) return

        val cardRoot = modalRoot.findViewById<View>(R.id.card) ?: modalRoot
        if (findFirstFocusableDescendant(cardRoot)?.requestFocus() == true) return
    }

    private fun dismissModalInternal(
        animate: Boolean,
        restoreFocus: Boolean,
    ) {
        checkMainThread()
        val entry = modalEntry ?: return
        val root = entry.rootView
        val card = root.findViewById<View>(R.id.card) ?: root

        fun finalizeDismiss() {
            if (modalEntry === entry) {
                modalEntry = null
            }
            runCatching { entry.backCallback.remove() }
            runCatching { contentRoot.viewTreeObserver.removeOnGlobalFocusChangeListener(entry.focusListener) }

            if (restoreFocus) {
                
                
                restoreUnderlyingFocus()
            }

            
            
            entry.onDismiss?.invoke()

            
            val openedNewModal = modalLayer.childCount > 1
            if (restoreFocus && !openedNewModal) {
                
                
                
                parkFocusForRestore()
                val restoredByCallback = runCatching { entry.onRestoreFocus?.invoke() }.getOrNull() == true
                if (!restoredByCallback) entry.focusReturn.restoreAndClear()
            }
            runCatching { (root.parent as? ViewGroup)?.removeView(root) }
        }

        if (!animate) {
            root.animate().cancel()
            card.animate().cancel()
            finalizeDismiss()
            return
        }

        
        
        
        if (entry.dismissing) return

        root.animate().cancel()
        card.animate().cancel()
        entry.dismissing = true

        if (restoreFocus) {
            
            
            
            
            
            parkFocusForRestore()
        }

        
        
        
        root.animate().alpha(0f).setDuration(140L).start()
        card.animate()
            .alpha(0f)
            .scaleX(0.98f)
            .scaleY(0.98f)
            .setDuration(140L)
            .withEndAction {
                finalizeDismiss()
            }
            .start()

        
        
        mainHandler.postDelayed(
            {
                if (modalEntry === entry) finalizeDismiss()
            },
             220L,
        )
    }

    private fun checkMainThread() {
        check(Looper.myLooper() == Looper.getMainLooper()) { "PopupHost must be used on main thread." }
    }

    fun hasModalView(): Boolean {
        return modalLayer.childCount > 0
    }

    fun consumeBackLikeKeyEventIfNeeded(event: KeyEvent): Boolean {
        val keyCode = event.keyCode
        val isBackLike =
            keyCode == KeyEvent.KEYCODE_BACK ||
                keyCode == KeyEvent.KEYCODE_ESCAPE ||
                keyCode == KeyEvent.KEYCODE_BUTTON_B

        if (!isBackLike) return false

        if (event.action == KeyEvent.ACTION_UP && consumeBackLikeKeyUp) {
            consumeBackLikeKeyUp = false
            return true
        }
        if (event.action != KeyEvent.ACTION_DOWN) return false

        if (!hasModalView()) return false

        
        consumeBackLikeKeyUp = true

        val entry = modalEntry
        if (entry?.onBackPressed?.invoke() == true) return true
        if (entry != null && entry.cancelable) dismissModal()
        return true
    }

    companion object {
        fun from(activity: ComponentActivity): PopupHost {
            val contentRoot = activity.findViewById<FrameLayout>(android.R.id.content)
            val existing = contentRoot.getTag(R.id.tag_popup_host) as? PopupHost
            if (existing != null) return existing

            val hostView =
                FrameLayout(activity).apply {
                    layoutParams =
                        FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT,
                        )
                    clipChildren = false
                    clipToPadding = false
                    isClickable = false
                    isFocusable = false
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }

            val modalLayer =
                FrameLayout(activity).apply {
                    layoutParams =
                        FrameLayout.LayoutParams(
                            FrameLayout.LayoutParams.MATCH_PARENT,
                            FrameLayout.LayoutParams.MATCH_PARENT,
                        )
                    clipChildren = false
                    clipToPadding = false
                    isClickable = false
                    isFocusable = false
                    importantForAccessibility = View.IMPORTANT_FOR_ACCESSIBILITY_NO
                }

            hostView.addView(modalLayer)
            contentRoot.addView(hostView)

            val host = PopupHost(activity = activity, contentRoot = contentRoot, hostView = hostView, modalLayer = modalLayer)
            contentRoot.setTag(R.id.tag_popup_host, host)

            ViewCompat.setOnApplyWindowInsetsListener(hostView) { _, insets ->
                host.applyInsets(insets)
                insets
            }
            ViewCompat.requestApplyInsets(hostView)

            return host
        }

        fun peek(activity: ComponentActivity): PopupHost? {
            val contentRoot = activity.findViewById<FrameLayout>(android.R.id.content)
            return contentRoot.getTag(R.id.tag_popup_host) as? PopupHost
        }
    }
}
