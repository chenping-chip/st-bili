package blbl.cat3399.core.ui

import android.view.View
import androidx.core.view.doOnPreDraw


inline fun View.postIfAlive(
    crossinline isAlive: () -> Boolean,
    crossinline action: () -> Unit,
) {
    post {
        if (!isAlive()) return@post
        action()
    }
}

inline fun View.postIfAttached(crossinline action: () -> Unit) {
    postIfAlive(isAlive = { isAttachedToWindow }, action = action)
}

inline fun View.postDelayedIfAlive(
    delayMillis: Long,
    crossinline isAlive: () -> Boolean,
    crossinline action: () -> Unit,
) {
    postDelayed(
        {
            if (isAlive()) action()
        },
        delayMillis,
    )
}

inline fun View.postDelayedIfAttached(
    delayMillis: Long,
    crossinline action: () -> Unit,
) {
    postDelayedIfAlive(delayMillis = delayMillis, isAlive = { isAttachedToWindow }, action = action)
}

inline fun View.doOnPreDrawIfAlive(
    crossinline isAlive: () -> Boolean,
    crossinline action: () -> Unit,
) {
    doOnPreDraw {
        if (!isAlive()) return@doOnPreDraw
        action()
    }
}
