package blbl.cat3399.core.download

import blbl.cat3399.core.api.video.VideoApiGateway
import blbl.cat3399.core.api.video.VideoPlayKind
import blbl.cat3399.core.api.video.VideoPlayRequest
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.net.await
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.Request
import java.io.File
import java.io.IOException


object VideoDownloader {

    data class ResolvedStream(
        val url: String,
        val sizeBytes: Long?,
        val label: String,
    )

    data class DownloadProgress(
        val percent: Int?,
        val bytesDone: Long,
        val totalBytes: Long?,
    )

    suspend fun resolveStream(
        bvid: String,
        aid: Long?,
        cid: Long,
    ): ResolvedStream {
        val play =
            VideoApiGateway.playUrl(
                VideoPlayRequest(
                    kind = VideoPlayKind.UGC,
                    bvid = bvid,
                    aid = aid,
                    cid = cid,
                    qn = 64,
                    fnval = 0,
                ),
            )

        
        play.progressive
            .firstOrNull { it.urls.isNotEmpty() }
            ?.let { return ResolvedStream(url = it.urls.first(), sizeBytes = null, label = "mp4") }

        
        play.dash
            ?.videos
            ?.filter { it.urls.isNotEmpty() }
            ?.maxByOrNull { it.qn }
            ?.let {
                return ResolvedStream(url = it.urls.first(), sizeBytes = null, label = "dash-${it.qn}p")
            }

        throw IOException("未获取到可下载的视频流（可能需要登录或该视频不允许下载）")
    }

    
    suspend fun downloadToFile(
        url: String,
        target: File,
        onProgress: (DownloadProgress) -> Unit,
    ): Long {
        val request = Request.Builder().url(url).build()
        val client = BiliClient.cdnOkHttp
        val response = client.newCall(request).await()
        response.use { res ->
            val body = res.body ?: throw IOException("下载响应为空 HTTP ${res.code}")
            if (!res.isSuccessful) {
                throw IOException("下载失败 HTTP ${res.code} ${res.message}")
            }
            val total = body.contentLength().takeIf { it > 0L }
            val buffer = ByteArray(64 * 1024)
            var done = 0L
            var lastReportMs = 0L
            withContext(Dispatchers.IO) {
                target.parentFile?.mkdirs()
                body.byteStream().use { input ->
                    target.outputStream().use { output ->
                        while (true) {
                            val read = input.read(buffer)
                            if (read < 0) break
                            output.write(buffer, 0, read)
                            done += read
                            val now = System.currentTimeMillis()
                            if (now - lastReportMs >= 120L || done >= (total ?: Long.MAX_VALUE)) {
                                lastReportMs = now
                                onProgress(
                                    DownloadProgress(
                                        percent = total?.let { ((done * 100) / it).toInt() },
                                        bytesDone = done,
                                        totalBytes = total,
                                    ),
                                )
                            }
                        }
                    }
                }
            }
            onProgress(
                DownloadProgress(
                    percent = 100,
                    bytesDone = done,
                    totalBytes = total,
                ),
            )
            return done
        }
    }
}
