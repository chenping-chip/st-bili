package blbl.cat3399.core.ui

import android.os.Build
import android.os.SystemClock
import android.view.FocusFinder
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.ViewTreeObserver
import androidx.recyclerview.widget.GridLayoutManager
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.recyclerview.widget.StaggeredGridLayoutManager
import blbl.cat3399.R

internal fun interface DpadItemKeyHandler {
    fun onInterceptKey(
        itemView: View,
        keyCode: Int,
        event: KeyEvent,
    ): Boolean
}

internal fun View.setDpadItemKeyHandler(handler: DpadItemKeyHandler?) {
    setTag(R.id.tag_dpad_item_key_handler, handler)
}

internal fun View.dispatchToDpadItemKeyHandler(
    keyCode: Int,
    event: KeyEvent,
): Boolean {
    val handler = getTag(R.id.tag_dpad_item_key_handler) as? DpadItemKeyHandler ?: return false
    return handler.onInterceptKey(this, keyCode, event)
}

internal fun View.dispatchToAncestorDpadItemKeyHandler(
    keyCode: Int,
    event: KeyEvent,
): Boolean {
    var current: View? = this
    while (current != null) {
        if (current.dispatchToDpadItemKeyHandler(keyCode, event)) {
            return true
        }
        current = current.parent as? View
    }
    return false
}


internal class DpadGridController(
    private val recyclerView: RecyclerView,
    private val callbacks: Callbacks,
    private val config: Config = Config(),
) {
    data class Config(
        
        val isEnabled: () -> Boolean = { true },
        
        val enableCenterLongPressToLongClick: Boolean = false,
        
        val scrollOnDownEdgeFactor: Float = 0.8f,
        
        val consumeRightEdge: Boolean = true,
        
        val consumeUpAtTopEdge: Boolean = true,
    )

    interface Callbacks {
        
        fun onTopEdge(): Boolean

        
        fun onLeftEdge(): Boolean

        
        fun onRightEdge()

        
        fun canLoadMore(): Boolean

        
        fun loadMore()
    }

    private var installed: Boolean = false
    private var pendingFocusAfterLoadMoreAnchorPos: Int = RecyclerView.NO_POSITION
    private var pendingFocusAfterLoadMoreTargetPos: Int = RecyclerView.NO_POSITION
    private val focusRetryDelayMillis: Long = 16L
    private val focusRetryMaxAttempts: Int = 30
    private var focusParkedDescendantFocusability: Int? = null
    private val focusProtectWindowMs: Long = 500L
    private var lastVerticalNavAtMs: Long = 0L
    private var lastVerticalNavDirection: Int = View.FOCUS_DOWN
    private var lastKnownFocusedAdapterPos: Int = RecyclerView.NO_POSITION
    private var lastKnownFocusedSpanIndex: Int? = null
    private var detachFocusRestoreToken: Int = 0
    private var originalOverScrollMode: Int? = null
    private var originalDefaultFocusHighlightEnabled: Boolean? = null
    private var didSuppressDefaultFocusHighlight: Boolean = false
    private var focusHighlightListener: ViewTreeObserver.OnGlobalFocusChangeListener? = null

    
    private val recyclerKeyListener =
        View.OnKeyListener { _, keyCode, event ->
            if (!installed) return@OnKeyListener false
            if (!config.isEnabled()) return@OnKeyListener false
            if (event.action != KeyEvent.ACTION_DOWN) return@OnKeyListener false
            if (!recyclerView.isFocused) return@OnKeyListener false

            when (keyCode) {
                KeyEvent.KEYCODE_DPAD_DOWN -> {
                    markVerticalNav(View.FOCUS_DOWN)
                    handleRecyclerFocusedDpadDown()
                }

                KeyEvent.KEYCODE_DPAD_UP -> {
                    markVerticalNav(View.FOCUS_UP)
                    
                    
                    if (pendingFocusAfterLoadMoreAnchorPos != RecyclerView.NO_POSITION) {
                        clearPendingFocusAfterLoadMore()
                    }
                    
                    
                    false
                }

                KeyEvent.KEYCODE_DPAD_LEFT,
                KeyEvent.KEYCODE_DPAD_RIGHT,
                -> {
                    if (pendingFocusAfterLoadMoreAnchorPos != RecyclerView.NO_POSITION) {
                        clearPendingFocusAfterLoadMore()
                    }
                    false
                }

                else -> false
            }
        }

    private val childListener =
        object : RecyclerView.OnChildAttachStateChangeListener {
            override fun onChildViewAttachedToWindow(view: View) {
                if (config.enableCenterLongPressToLongClick) {
                view.setTag(R.id.tag_long_press_handled, false)
                }
                view.setOnKeyListener { v, keyCode, event ->
                    if (!installed) return@setOnKeyListener false
                    if (!config.isEnabled()) return@setOnKeyListener false

                    if (v.dispatchToDpadItemKeyHandler(keyCode, event)) {
                        return@setOnKeyListener true
                    }

                    if (config.enableCenterLongPressToLongClick && handleCenterLongPress(v, keyCode, event)) {
                        return@setOnKeyListener true
                    }

                    if (event.action != KeyEvent.ACTION_DOWN) return@setOnKeyListener false

                    when (keyCode) {
                        KeyEvent.KEYCODE_DPAD_UP -> {
                            markVerticalNav(View.FOCUS_UP)
                            val pos = resolveAdapterPosition(v)
                            if (pos != null) {
                                rememberLastKnownFocus(position = pos)
                                handleDpadUp(pos)
                            } else {
                                
                                
                                config.consumeUpAtTopEdge
                            }
                        }

                        KeyEvent.KEYCODE_DPAD_LEFT -> handleDpadLeft(v)
                        KeyEvent.KEYCODE_DPAD_RIGHT -> handleDpadRight(v)
                        KeyEvent.KEYCODE_DPAD_DOWN -> {
                            markVerticalNav(View.FOCUS_DOWN)
                            val pos = resolveAdapterPosition(v)
                            if (pos != null) {
                                rememberLastKnownFocus(position = pos)
                                handleDpadDown(v, pos)
                            } else {
                                handleDpadDownFallback(v)
                            }
                        }

                        else -> false
                    }
                }
            }

            override fun onChildViewDetachedFromWindow(view: View) {
                maybeProtectFocusOnChildDetach(view)
                view.setOnKeyListener(null)
                if (config.enableCenterLongPressToLongClick) {
                    view.setTag(R.id.tag_long_press_handled, false)
                }
            }
        }

    fun install() {
        if (installed) return
        installed = true
        if (originalOverScrollMode == null) {
            originalOverScrollMode = recyclerView.overScrollMode
        }
        recyclerView.overScrollMode = View.OVER_SCROLL_NEVER
        ensureDefaultFocusHighlightSuppressionHook()
        recyclerView.setOnKeyListener(recyclerKeyListener)
        recyclerView.addOnChildAttachStateChangeListener(childListener)
        
        for (i in 0 until recyclerView.childCount) {
            childListener.onChildViewAttachedToWindow(recyclerView.getChildAt(i))
        }
    }

    fun release() {
        if (!installed) return
        installed = false
        unparkFocusInRecyclerViewIfNeeded()
        removeDefaultFocusHighlightSuppressionHook()
        originalOverScrollMode?.let { mode ->
            if (recyclerView.overScrollMode == View.OVER_SCROLL_NEVER) {
                recyclerView.overScrollMode = mode
            }
        }
        originalOverScrollMode = null
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            originalDefaultFocusHighlightEnabled?.let { enabled ->
                if (didSuppressDefaultFocusHighlight && !recyclerView.defaultFocusHighlightEnabled) {
                    recyclerView.defaultFocusHighlightEnabled = enabled
                }
            }
        }
        originalDefaultFocusHighlightEnabled = null
        didSuppressDefaultFocusHighlight = false
        detachFocusRestoreToken++
        clearPendingFocusAfterLoadMore()
        recyclerView.removeOnChildAttachStateChangeListener(childListener)
        recyclerView.setOnKeyListener(null)
        for (i in 0 until recyclerView.childCount) {
            childListener.onChildViewDetachedFromWindow(recyclerView.getChildAt(i))
        }
    }

    fun clearPendingFocusAfterLoadMore() {
        pendingFocusAfterLoadMoreAnchorPos = RecyclerView.NO_POSITION
        pendingFocusAfterLoadMoreTargetPos = RecyclerView.NO_POSITION
        unparkFocusInRecyclerViewIfNeeded()
    }

    
    fun parkFocusForDataSetReset() {
        
        
        parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = false)
    }

    
    fun unparkFocusAfterDataSetReset() {
        unparkFocusInRecyclerViewIfNeeded()
    }

    fun consumePendingFocusAfterLoadMore(): Boolean {
        val anchorPos = pendingFocusAfterLoadMoreAnchorPos
        if (anchorPos == RecyclerView.NO_POSITION) return false

        if (!config.isEnabled()) {
            clearPendingFocusAfterLoadMore()
            return false
        }

        val adapter = recyclerView.adapter
        if (adapter == null) {
            clearPendingFocusAfterLoadMore()
            return false
        }

        val spanCount = spanCountForLayoutManager()
        if (spanCount == null) {
            clearPendingFocusAfterLoadMore()
            return false
        }

        val focused = recyclerView.rootView?.findFocus()
        if (focused != null && !FocusTreeUtils.isDescendantOf(focused, recyclerView)) {
            clearPendingFocusAfterLoadMore()
            return false
        }

        val itemCount = adapter.itemCount
        if (itemCount <= 0) {
            clearPendingFocusAfterLoadMore()
            return false
        }

        val existingTarget = pendingFocusAfterLoadMoreTargetPos
        if (existingTarget != RecyclerView.NO_POSITION) {
            
            if (existingTarget !in 0 until itemCount) {
                clearPendingFocusAfterLoadMore()
                return false
            }
            return true
        }

        val candidatePos =
            when {
                anchorPos + spanCount in 0 until itemCount -> anchorPos + spanCount
                anchorPos + 1 in 0 until itemCount -> anchorPos + 1
                else -> null
            }
        if (candidatePos == null) {
            
            
            
            val fallbackPos = anchorPos.coerceIn(0, itemCount - 1)
            clearPendingFocusAfterLoadMore()
            scrollAndFocusAdapterPosition(fallbackPos, smooth = false)
            return true
        }

        pendingFocusAfterLoadMoreTargetPos = candidatePos
        
        parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = true)

        scrollAndFocusAdapterPosition(
            candidatePos,
            smooth = true,
            onFocused = {
                
                if (pendingFocusAfterLoadMoreTargetPos == candidatePos) {
                    clearPendingFocusAfterLoadMore()
                }
            },
        )
        return true
    }

    private fun handleCenterLongPress(v: View, keyCode: Int, event: KeyEvent): Boolean {
        if (
            keyCode != KeyEvent.KEYCODE_DPAD_CENTER &&
            keyCode != KeyEvent.KEYCODE_ENTER &&
            keyCode != KeyEvent.KEYCODE_NUMPAD_ENTER
        ) {
            return false
        }

        val handled = (v.getTag(R.id.tag_long_press_handled) as? Boolean) == true
        if (event.action == KeyEvent.ACTION_DOWN && event.repeatCount > 0) {
            if (!handled) {
                v.setTag(R.id.tag_long_press_handled, true)
                v.performLongClick()
            }
            return true
        }
        if (event.action == KeyEvent.ACTION_UP && handled) {
            v.setTag(R.id.tag_long_press_handled, false)
            return true
        }
        return false
    }

    private fun handleRecyclerFocusedDpadDown(): Boolean {
        
        
        if (pendingFocusAfterLoadMoreAnchorPos != RecyclerView.NO_POSITION) {
            
            parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = true)
            return true
        }

        val itemCount = recyclerView.adapter?.itemCount ?: 0
        if (itemCount <= 0) {
            
            return true
        }

        val candidatePos = (firstVisibleAdapterPosition() ?: 0).coerceIn(0, itemCount - 1)
        scrollAndFocusAdapterPosition(candidatePos, smooth = false)
        return true
    }

    private fun markVerticalNav(direction: Int) {
        lastVerticalNavAtMs = SystemClock.uptimeMillis()
        lastVerticalNavDirection = direction
    }

    private fun rememberLastKnownFocus(position: Int) {
        lastKnownFocusedAdapterPos = position
        val spanCount = spanCountForLayoutManager()
        if (spanCount == null || spanCount <= 0) {
            lastKnownFocusedSpanIndex = null
            return
        }
        val lm = recyclerView.layoutManager
        lastKnownFocusedSpanIndex =
            when (lm) {
                is GridLayoutManager -> lm.spanSizeLookup.getSpanIndex(position, spanCount)
                else -> position % spanCount
            }
    }

    private fun maybeProtectFocusOnChildDetach(detachedChild: View) {
        if (!installed) return
        if (!recyclerView.isAttachedToWindow) return
        if (!config.isEnabled()) return

        val hasPendingLoadMore = pendingFocusAfterLoadMoreAnchorPos != RecyclerView.NO_POSITION
        if (!hasPendingLoadMore) {
            
            
            val now = SystemClock.uptimeMillis()
            if (now - lastVerticalNavAtMs > focusProtectWindowMs) return
        }

        val focused = recyclerView.rootView?.findFocus()
        val focusWasInThisRecycler = focused != null && FocusTreeUtils.isDescendantOf(focused, recyclerView)
        if (!focusWasInThisRecycler && focused != null) return

        val detachingContainedFocus =
            focused != null && FocusTreeUtils.isDescendantOf(focused, detachedChild)
        if (!detachingContainedFocus && focused != null) return

        
        
        parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = hasPendingLoadMore)

        val token = ++detachFocusRestoreToken
        recyclerView.postIfAlive(
            isAlive = { installed && recyclerView.isAttachedToWindow && config.isEnabled() && detachFocusRestoreToken == token },
        ) {
            
            if (pendingFocusAfterLoadMoreAnchorPos != RecyclerView.NO_POSITION) return@postIfAlive
            restoreFocusAfterDetach()
        }
    }

    private fun restoreFocusAfterDetach(): Boolean {
        val adapter = recyclerView.adapter ?: return false
        val itemCount = adapter.itemCount
        if (itemCount <= 0) return false

        val focused = recyclerView.rootView?.findFocus()
        if (focused != null && focused !== recyclerView && FocusTreeUtils.isDescendantOf(focused, recyclerView)) {
            return true
        }

        val firstVisible = firstVisibleAdapterPosition() ?: return false
        val lastVisible = lastVisibleAdapterPosition() ?: firstVisible
        if (firstVisible !in 0 until itemCount) return false

        val anchor =
            pendingFocusAfterLoadMoreAnchorPos
                .takeIf { it != RecyclerView.NO_POSITION }
                ?: lastKnownFocusedAdapterPos
                    .takeIf { it != RecyclerView.NO_POSITION }
                ?: firstVisible
        val spanCount = spanCountForLayoutManager()?.coerceAtLeast(1) ?: 1
        val desired =
            when (lastVerticalNavDirection) {
                View.FOCUS_UP -> anchor - spanCount
                else -> anchor + spanCount
            }.coerceIn(0, itemCount - 1)

        val candidateInVisibleRange = desired.coerceIn(firstVisible, lastVisible)

        val candidate =
            when (val lm = recyclerView.layoutManager) {
                is GridLayoutManager -> {
                    val targetSpan = lastKnownFocusedSpanIndex
                    if (targetSpan == null) {
                        candidateInVisibleRange
                    } else {
                        findVisiblePositionWithSpanIndex(
                            lm = lm,
                            firstVisible = firstVisible,
                            lastVisible = lastVisible,
                            targetSpanIndex = targetSpan,
                            direction = lastVerticalNavDirection,
                        ) ?: candidateInVisibleRange
                    }
                }

                else -> candidateInVisibleRange
            }

        return scrollAndFocusAdapterPosition(candidate, smooth = false)
    }

    private fun lastVisibleAdapterPosition(): Int? {
        val lm = recyclerView.layoutManager ?: return null
        val pos =
            when (lm) {
                is GridLayoutManager -> lm.findLastVisibleItemPosition()
                is LinearLayoutManager -> lm.findLastVisibleItemPosition()
                is StaggeredGridLayoutManager -> {
                    val spanCount = lm.spanCount.coerceAtLeast(1)
                    val last = IntArray(spanCount)
                    lm.findLastVisibleItemPositions(last)
                    var max = Int.MIN_VALUE
                    for (p in last) {
                        if (p != RecyclerView.NO_POSITION && p > max) max = p
                    }
                    if (max == Int.MIN_VALUE) RecyclerView.NO_POSITION else max
                }

                else -> RecyclerView.NO_POSITION
            }
        return pos.takeIf { it != RecyclerView.NO_POSITION }
    }

    private fun findVisiblePositionWithSpanIndex(
        lm: GridLayoutManager,
        firstVisible: Int,
        lastVisible: Int,
        targetSpanIndex: Int,
        direction: Int,
    ): Int? {
        val spanCount = lm.spanCount.coerceAtLeast(1)
        val lookup = lm.spanSizeLookup
        return if (direction == View.FOCUS_UP) {
            for (pos in lastVisible downTo firstVisible) {
                if (lookup.getSpanIndex(pos, spanCount) == targetSpanIndex) return pos
            }
            null
        } else {
            for (pos in firstVisible..lastVisible) {
                if (lookup.getSpanIndex(pos, spanCount) == targetSpanIndex) return pos
            }
            null
        }
    }

    private fun resolveAdapterPosition(view: View): Int? {
        val rootItem = recyclerView.findContainingItemView(view) ?: view
        val holder = recyclerView.findContainingViewHolder(rootItem) ?: return null

        return (
            holder.bindingAdapterPosition.takeIf { it != RecyclerView.NO_POSITION }
                ?: holder.absoluteAdapterPosition.takeIf { it != RecyclerView.NO_POSITION }
                ?: holder.layoutPosition.takeIf { it != RecyclerView.NO_POSITION }
                ?: recyclerView.getChildLayoutPosition(rootItem).takeIf { it != RecyclerView.NO_POSITION }
        )
    }

    private fun firstVisibleAdapterPosition(): Int? {
        val lm = recyclerView.layoutManager ?: return null
        val pos =
            when (lm) {
                is GridLayoutManager -> lm.findFirstVisibleItemPosition()
                is LinearLayoutManager -> lm.findFirstVisibleItemPosition()
                is StaggeredGridLayoutManager -> {
                    val spanCount = lm.spanCount.coerceAtLeast(1)
                    val first = IntArray(spanCount)
                    lm.findFirstVisibleItemPositions(first)
                    var min = Int.MAX_VALUE
                    for (p in first) {
                        if (p != RecyclerView.NO_POSITION && p < min) min = p
                    }
                    if (min == Int.MAX_VALUE) RecyclerView.NO_POSITION else min
                }

                else -> RecyclerView.NO_POSITION
            }
        return pos.takeIf { it != RecyclerView.NO_POSITION }
    }

    private fun handleDpadUp(position: Int): Boolean {
        if (!isInTopRowAtTop(position)) return false
        val handled = callbacks.onTopEdge()
        return if (config.consumeUpAtTopEdge) true else handled
    }

    private fun handleDpadLeft(itemView: View): Boolean {
        val rootItem = recyclerView.findContainingItemView(itemView) ?: itemView
        val next = FocusFinder.getInstance().findNextFocus(recyclerView, rootItem, View.FOCUS_LEFT)
        if (next != null && FocusTreeUtils.isDescendantOf(next, recyclerView)) return false
        return callbacks.onLeftEdge()
    }

    private fun handleDpadRight(itemView: View): Boolean {
        val rootItem = recyclerView.findContainingItemView(itemView) ?: itemView
        val next = FocusFinder.getInstance().findNextFocus(recyclerView, rootItem, View.FOCUS_RIGHT)
        if (next != null && FocusTreeUtils.isDescendantOf(next, recyclerView)) return false
        if (!config.consumeRightEdge) return false
        callbacks.onRightEdge()
        
        return true
    }

    private fun handleDpadDown(itemView: View, position: Int): Boolean {
        val rootItem = recyclerView.findContainingItemView(itemView) ?: itemView
        val next = FocusFinder.getInstance().findNextFocus(recyclerView, rootItem, View.FOCUS_DOWN)
        if (next != null && FocusTreeUtils.isDescendantOf(next, recyclerView)) {
            
            
            
            next.requestFocus()
            return true
        }

        if (recyclerView.canScrollVertically(1)) {
            val dy = (rootItem.height * config.scrollOnDownEdgeFactor).toInt().coerceAtLeast(1)
            recyclerView.scrollBy(0, dy)
            val adapter = recyclerView.adapter
            val itemCount = adapter?.itemCount ?: 0
            val spanCount = spanCountForLayoutManager()
            val candidatePos =
                if (itemCount <= 0 || spanCount == null) {
                    null
                } else {
                    when {
                        position + spanCount in 0 until itemCount -> position + spanCount
                        position + 1 in 0 until itemCount -> position + 1
                        else -> null
                    }
                }
            recyclerView.postIfAlive(
                isAlive = { installed && recyclerView.isAttachedToWindow && config.isEnabled() },
            ) {
                if (tryFocusNextDownFromCurrent()) return@postIfAlive
                if (candidatePos != null) focusAdapterPosition(candidatePos)
            }
            return true
        }

        if (callbacks.canLoadMore()) {
            pendingFocusAfterLoadMoreAnchorPos = position
            pendingFocusAfterLoadMoreTargetPos = RecyclerView.NO_POSITION
            callbacks.loadMore()
            
            
            
            parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = true)
        }
        
        return true
    }

    private fun handleDpadDownFallback(itemView: View): Boolean {
        val rootItem = recyclerView.findContainingItemView(itemView) ?: itemView
        val next = FocusFinder.getInstance().findNextFocus(recyclerView, rootItem, View.FOCUS_DOWN)
        if (next != null && FocusTreeUtils.isDescendantOf(next, recyclerView)) {
            next.requestFocus()
            return true
        }

        if (recyclerView.canScrollVertically(1)) {
            val base =
                rootItem.height
                    .takeIf { it > 0 }
                    ?: (recyclerView.height.takeIf { it > 0 }?.div(2) ?: 1)
            val dy = (base * config.scrollOnDownEdgeFactor).toInt().coerceAtLeast(1)
            recyclerView.scrollBy(0, dy)
            recyclerView.postIfAlive(
                isAlive = { installed && recyclerView.isAttachedToWindow && config.isEnabled() },
            ) {
                tryFocusNextDownFromCurrent()
            }
            return true
        }

        if (callbacks.canLoadMore()) {
            val adapter = recyclerView.adapter
            val itemCount = adapter?.itemCount ?: 0
            val fallbackAnchor =
                when {
                    lastKnownFocusedAdapterPos in 0 until itemCount -> lastKnownFocusedAdapterPos
                    (lastVisibleAdapterPosition() ?: RecyclerView.NO_POSITION) in 0 until itemCount -> lastVisibleAdapterPosition()!!
                    (firstVisibleAdapterPosition() ?: RecyclerView.NO_POSITION) in 0 until itemCount -> firstVisibleAdapterPosition()!!
                    itemCount > 0 -> itemCount - 1
                    else -> RecyclerView.NO_POSITION
                }
            if (fallbackAnchor != RecyclerView.NO_POSITION) {
                pendingFocusAfterLoadMoreAnchorPos = fallbackAnchor
                pendingFocusAfterLoadMoreTargetPos = RecyclerView.NO_POSITION
            }
            callbacks.loadMore()
            
            
            parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden = true)
        }
        
        return true
    }

    private fun parkFocusInRecyclerViewForLoadMore(keepDescendantFocusabilityOverridden: Boolean = false) {
        if (!installed) return
        if (!recyclerView.isAttachedToWindow) return
        if (!config.isEnabled()) return

        
        
        val focused = recyclerView.rootView?.findFocus()
        if (focused != null && focused !== recyclerView && !FocusTreeUtils.isDescendantOf(focused, recyclerView)) {
            return
        }

        suppressRecyclerDefaultFocusHighlight()

        if (focusParkedDescendantFocusability == null) {
            
            
            focusParkedDescendantFocusability = recyclerView.descendantFocusability
            recyclerView.descendantFocusability = ViewGroup.FOCUS_BEFORE_DESCENDANTS
        }

        if (recyclerView.isFocused || recyclerView.requestFocus()) {
            if (!keepDescendantFocusabilityOverridden) {
                
                
                unparkFocusInRecyclerViewIfNeeded()
            }
            return
        }

        
        recyclerView.postIfAlive(
            isAlive = { installed && recyclerView.isAttachedToWindow && config.isEnabled() },
        ) {
            
            val currentFocused = recyclerView.rootView?.findFocus()
            if (
                currentFocused != null &&
                currentFocused !== recyclerView &&
                !FocusTreeUtils.isDescendantOf(currentFocused, recyclerView)
            ) {
                restoreRecyclerDefaultFocusHighlightIfSuppressed()
                return@postIfAlive
            }

            suppressRecyclerDefaultFocusHighlight()
            if (!recyclerView.isFocused) {
                recyclerView.requestFocus()
            }
            if (!keepDescendantFocusabilityOverridden) {
                unparkFocusInRecyclerViewIfNeeded()
            }
        }
    }

    private fun unparkFocusInRecyclerViewIfNeeded() {
        val original = focusParkedDescendantFocusability ?: return
        focusParkedDescendantFocusability = null
        recyclerView.descendantFocusability = original
    }

    private fun suppressRecyclerDefaultFocusHighlight() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        if (originalDefaultFocusHighlightEnabled == null) {
            originalDefaultFocusHighlightEnabled = recyclerView.defaultFocusHighlightEnabled
        }

        if (recyclerView.defaultFocusHighlightEnabled) {
            recyclerView.defaultFocusHighlightEnabled = false
            didSuppressDefaultFocusHighlight = true
        }
    }

    private fun restoreRecyclerDefaultFocusHighlightIfSuppressed() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (!didSuppressDefaultFocusHighlight) return

        val original = originalDefaultFocusHighlightEnabled ?: return
        if (!recyclerView.defaultFocusHighlightEnabled) {
            recyclerView.defaultFocusHighlightEnabled = original
        }
        didSuppressDefaultFocusHighlight = false
    }

    private fun ensureDefaultFocusHighlightSuppressionHook() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return
        if (focusHighlightListener != null) return

        if (originalDefaultFocusHighlightEnabled == null) {
            originalDefaultFocusHighlightEnabled = recyclerView.defaultFocusHighlightEnabled
        }

        val listener =
            ViewTreeObserver.OnGlobalFocusChangeListener { oldFocus, newFocus ->
                if (!installed) return@OnGlobalFocusChangeListener
                if (newFocus === recyclerView) {
                    suppressRecyclerDefaultFocusHighlight()
                } else if (oldFocus === recyclerView) {
                    restoreRecyclerDefaultFocusHighlightIfSuppressed()
                }
            }
        focusHighlightListener = listener
        runCatching { recyclerView.viewTreeObserver.addOnGlobalFocusChangeListener(listener) }

        
        if (recyclerView.isFocused) {
            suppressRecyclerDefaultFocusHighlight()
        }
    }

    private fun removeDefaultFocusHighlightSuppressionHook() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return

        val listener = focusHighlightListener
        focusHighlightListener = null
        if (listener != null) {
            runCatching { recyclerView.viewTreeObserver.removeOnGlobalFocusChangeListener(listener) }
        }
    }

    private fun tryFocusNextDownFromCurrent(): Boolean {
        if (!config.isEnabled()) return false
        val focused = recyclerView.findFocus() ?: return false
        if (!FocusTreeUtils.isDescendantOf(focused, recyclerView)) return false
        val itemView = recyclerView.findContainingItemView(focused) ?: return false
        val next = FocusFinder.getInstance().findNextFocus(recyclerView, itemView, View.FOCUS_DOWN)
        if (next != null && FocusTreeUtils.isDescendantOf(next, recyclerView)) {
            next.requestFocus()
            return true
        }
        return false
    }

    private fun focusAdapterPosition(position: Int): Boolean {
        val adapter = recyclerView.adapter ?: return false
        val itemCount = adapter.itemCount
        if (position !in 0 until itemCount) return false

        return scrollAndFocusAdapterPosition(position, smooth = true)
    }

    private fun scrollAndFocusAdapterPosition(position: Int, smooth: Boolean, onFocused: (() -> Unit)? = null): Boolean {
        val adapter = recyclerView.adapter
        if (adapter == null) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return false
        }
        val itemCount = adapter.itemCount
        if (position !in 0 until itemCount) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return false
        }

        recyclerView.findViewHolderForAdapterPosition(position)?.itemView?.let { itemView ->
            
            
            if (isPartiallyVisibleInRecycler(itemView) && itemView.requestFocus()) {
                onFocused?.invoke()
                return true
            }
        }

        if (smooth) recyclerView.smoothScrollToPosition(position) else recyclerView.scrollToPosition(position)
        retryFocusAdapterPosition(position, attemptsLeft = focusRetryMaxAttempts, onFocused = onFocused)
        return true
    }

    private fun retryFocusAdapterPosition(position: Int, attemptsLeft: Int, onFocused: (() -> Unit)? = null) {
        if (!isAliveForFocusJump()) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return
        }

        val adapter = recyclerView.adapter
        if (adapter == null) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return
        }
        val itemCount = adapter.itemCount
        if (position !in 0 until itemCount) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return
        }

        recyclerView.findViewHolderForAdapterPosition(position)?.itemView?.let { itemView ->
            
            
            if (isPartiallyVisibleInRecycler(itemView) && itemView.requestFocus()) {
                onFocused?.invoke()
                return
            }
        }

        if (attemptsLeft <= 0) {
            maybeAbortPendingLoadMoreFocusRetry(position)
            return
        }
        recyclerView.postDelayedIfAlive(
            delayMillis = focusRetryDelayMillis,
            isAlive = { isAliveForFocusJump() },
        ) {
            retryFocusAdapterPosition(position, attemptsLeft = attemptsLeft - 1, onFocused = onFocused)
        }
    }

    private fun maybeAbortPendingLoadMoreFocusRetry(position: Int) {
        if (pendingFocusAfterLoadMoreTargetPos != position) return
        if (pendingFocusAfterLoadMoreAnchorPos == RecyclerView.NO_POSITION) return
        
        
        clearPendingFocusAfterLoadMore()
    }

    private fun isAliveForFocusJump(): Boolean {
        if (!installed) return false
        if (!recyclerView.isAttachedToWindow) return false
        if (!config.isEnabled()) return false
        val focused = recyclerView.rootView?.findFocus()
        if (focused != null && !FocusTreeUtils.isDescendantOf(focused, recyclerView)) return false
        return true
    }

    private fun isPartiallyVisibleInRecycler(itemView: View): Boolean {
        val parentH = recyclerView.height
        if (parentH <= 0) return false
        val parentTop = recyclerView.paddingTop
        val parentBottom = parentH - recyclerView.paddingBottom
        val childTop = itemView.top
        val childBottom = itemView.bottom
        return childBottom > parentTop && childTop < parentBottom
    }

    private fun spanCountForLayoutManager(): Int? {
        val lm = recyclerView.layoutManager
        return when (lm) {
            is GridLayoutManager -> lm.spanCount.coerceAtLeast(1)
            is LinearLayoutManager -> 1
            is StaggeredGridLayoutManager -> lm.spanCount.coerceAtLeast(1)
            else -> null
        }
    }

    private fun isInTopRowAtTop(position: Int): Boolean {
        
        
        
        
        
        val lm = recyclerView.layoutManager ?: return false
        return when (lm) {
            is GridLayoutManager -> {
                val spanCount = lm.spanCount.coerceAtLeast(1)
                val groupIndex = lm.spanSizeLookup.getSpanGroupIndex(position, spanCount)
                if (groupIndex != 0) return false

                val firstVisible = lm.findFirstVisibleItemPosition()
                firstVisible == 0 || !recyclerView.canScrollVertically(-1)
            }

            is LinearLayoutManager -> {
                if (position != 0) return false
                val firstVisible = lm.findFirstVisibleItemPosition()
                firstVisible == 0 || !recyclerView.canScrollVertically(-1)
            }

            is StaggeredGridLayoutManager -> {
                val spanCount = lm.spanCount.coerceAtLeast(1)
                val first = IntArray(spanCount)
                lm.findFirstVisibleItemPositions(first)
                val nearTop = first.any { it == 0 } || !recyclerView.canScrollVertically(-1)
                nearTop && first.any { it == position }
            }

            else -> position == 0 && !recyclerView.canScrollVertically(-1)
        }
    }
}
