package blbl.cat3399.core.ui

interface TabSwitchFocusTarget : TabContentFocusTarget {
    
    fun requestFocusFirstCardFromTab(): Boolean

    
    fun requestFocusFirstCardFromContentSwitch(): Boolean

    
    fun requestFocusFirstCardFromBackToTab0(): Boolean = requestFocusFirstCardFromContentSwitch()

    override fun requestFocusPrimaryItemFromTab(): Boolean = requestFocusFirstCardFromTab()

    override fun requestFocusPrimaryItemFromContentSwitch(): Boolean = requestFocusFirstCardFromContentSwitch()

    override fun requestFocusPrimaryItemFromBackToTab0(): Boolean = requestFocusFirstCardFromBackToTab0()
}
