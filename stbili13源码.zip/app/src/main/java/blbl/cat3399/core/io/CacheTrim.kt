package blbl.cat3399.core.io

import android.content.Context
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import java.io.File


object CacheTrim {
    suspend fun trimIfOverLimit(context: Context) {
        val prefs: AppPrefs = BiliClient.prefs
        val limitMb = prefs.cacheLimitMb
        if (limitMb <= 0) return
        kotlinx.coroutines.withContext(kotlinx.coroutines.Dispatchers.IO) {
            trim(context, limitMb)
        }
    }

    fun trim(context: Context, limitMb: Int) {
        val limitBytes = limitMb * 1024L * 1024L
        val dirs = listOfNotNull(context.cacheDir, context.externalCacheDir)
        val files = ArrayList<File>()
        var total = 0L
        for (dir in dirs) {
            val stack = ArrayDeque<File>()
            dir.listFiles()?.let { stack.addAll(it) }
            while (stack.isNotEmpty()) {
                val f = stack.removeLast()
                if (f.isDirectory) {
                    f.listFiles()?.let { stack.addAll(it) }
                } else {
                    total += f.length()
                    files.add(f)
                }
            }
        }
        if (total <= limitBytes) return
        files.sortBy { it.lastModified() }
        val target = (limitBytes * 0.8).toLong()
        var freed = 0L
        for (f in files) {
            if (total - freed <= target) break
            val len = f.length()
            if (f.delete()) freed += len
        }
    }
}
