package blbl.cat3399.core.ui

import android.app.Activity
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.drawable.ColorDrawable
import android.os.Build
import android.view.View
import android.view.ViewGroup
import androidx.core.graphics.drawable.toDrawable
import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import java.io.File


object BackgroundManager {
    private const val TAG = "Background"

    fun backgroundFile(context: android.content.Context): File =
        File(File(context.filesDir, "background"), "background.jpg")

    fun apply(activity: Activity) {
        runCatching {
            val prefs: AppPrefs = BiliClient.prefs
            val path = prefs.backgroundImagePath
            val blur = prefs.backgroundBlur
            val win = activity.window ?: return
            
            val fallback =
                if (prefs.themeBrightness == AppPrefs.THEME_BRIGHTNESS_LIGHT) {
                    blbl.cat3399.R.color.blbl_bg_light
                } else {
                    blbl.cat3399.R.color.blbl_bg
                }
            if (path.isNullOrBlank()) {
                win.setBackgroundDrawableResource(fallback)
                return
            }
            val file = File(path)
            if (!file.exists()) {
                win.setBackgroundDrawableResource(fallback)
                return
            }
            val displayMetrics = activity.resources.displayMetrics
            val targetWidth = displayMetrics.widthPixels
            val targetHeight = displayMetrics.heightPixels

            val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
            BitmapFactory.decodeFile(file.absolutePath, bounds)
            var sample = 1
            while (bounds.outWidth / (sample * 2) >= targetWidth && bounds.outHeight / (sample * 2) >= targetHeight) {
                sample *= 2
            }
            val opts = BitmapFactory.Options().apply { inSampleSize = sample }
            var bitmap = BitmapFactory.decodeFile(file.absolutePath, opts) ?: return

            val maxW = (displayMetrics.widthPixels * 1.5).toInt()
            val maxH = (displayMetrics.heightPixels * 1.5).toInt()
            if (bitmap.width > maxW || bitmap.height > maxH) {
                val scale = minOf(maxW.toFloat() / bitmap.width, maxH.toFloat() / bitmap.height, 1f)
                val w = (bitmap.width * scale).toInt().coerceAtLeast(1)
                val h = (bitmap.height * scale).toInt().coerceAtLeast(1)
                val scaled = Bitmap.createScaledBitmap(bitmap, w, h, true)
                if (scaled !== bitmap) bitmap.recycle()
                bitmap = scaled
            }

            
            val cropped = centerCropToRatio(bitmap, targetWidth.toFloat() / targetHeight.coerceAtLeast(1))
            if (cropped !== bitmap) {
                bitmap.recycle()
                bitmap = cropped
            }

            val blurred =
                if (blur > 0f) {
                    try {
                        blurBitmap(bitmap, blur)
                    } catch (t: Throwable) {
                        AppLog.w(TAG, "blur failed", t)
                        bitmap
                    }
                } else {
                    bitmap
                }
            
            val dimmed = dimBitmap(blurred, if (prefs.themeBrightness == AppPrefs.THEME_BRIGHTNESS_LIGHT) 0x12 else 0x30)
            if (dimmed !== blurred && dimmed !== bitmap) blurred.recycle()
            if (dimmed !== bitmap) bitmap.recycle()

            win.setBackgroundDrawable(dimmed.toDrawable(activity.resources))
            
            
            
            
            val content = activity.findViewById<View>(android.R.id.content)
            if (content != null) {
                content.post { clearFullScreenColorBackdrops(content) }
            }
        }.onFailure { t ->
            AppLog.w(TAG, "apply background failed", t)
            runCatching { activity.window?.setBackgroundDrawableResource(blbl.cat3399.R.color.blbl_bg) }
        }
    }

    
    private fun clearFullScreenColorBackdrops(root: View) {
        root.background = null
        clearRecursive(root as? ViewGroup ?: return, depth = 0)
    }

    
    
    private fun clearRecursive(parent: ViewGroup, depth: Int) {
        if (depth > 6) return
        for (i in 0 until parent.childCount) {
            val child = parent.getChildAt(i)
            if (child is ViewGroup && child.background != null && isFullScreen(child, parent)) {
                child.background = null
                clearRecursive(child, depth + 1)
            }
        }
    }

    private fun isFullScreen(child: View, parent: View): Boolean {
        val lp = child.layoutParams
        val matchW = lp?.width == ViewGroup.LayoutParams.MATCH_PARENT
        val matchH = lp?.height == ViewGroup.LayoutParams.MATCH_PARENT
        if (matchW && matchH) return true
        if (!matchW && !matchH) return false
        return parent.width > 0 &&
            child.width >= parent.width * 0.9 &&
            child.height >= parent.height * 0.9
    }

    
    private fun centerCropToRatio(src: Bitmap, targetRatio: Float): Bitmap {
        if (targetRatio <= 0f) return src
        val imgRatio = src.width.toFloat() / src.height.coerceAtLeast(1)
        if (kotlin.math.abs(imgRatio - targetRatio) < 0.02f) return src
        return if (imgRatio > targetRatio) {
            val w = (src.height * targetRatio).toInt().coerceIn(1, src.width)
            Bitmap.createBitmap(src, (src.width - w) / 2, 0, w, src.height)
        } else {
            val h = (src.width / targetRatio).toInt().coerceIn(1, src.height)
            Bitmap.createBitmap(src, 0, (src.height - h) / 2, src.width, h)
        }
    }

    
    private fun dimBitmap(src: Bitmap, alpha: Int): Bitmap {
        if (alpha <= 0) return src
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(out)
        c.drawBitmap(src, 0f, 0f, null)
        c.drawColor((alpha.coerceIn(0, 255) shl 24) or 0x000000, android.graphics.PorterDuff.Mode.SRC_OVER)
        return out
    }

    private fun blurBitmap(src: Bitmap, blur: Float): Bitmap {
        val radiusPx = (6 + blur * 22).toInt().coerceIn(6, 48)
        val paint =
            android.graphics.Paint().apply {
                isAntiAlias = true
                maskFilter = android.graphics.BlurMaskFilter(radiusPx.toFloat(), android.graphics.BlurMaskFilter.Blur.NORMAL)
            }
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        val c = android.graphics.Canvas(out)
        val scale = (src.width + 2f * radiusPx) / src.width.toFloat()
        c.save()
        c.scale(scale, scale, src.width / 2f, src.height / 2f)
        c.drawBitmap(src, 0f, 0f, paint)
        c.restore()
        return out
    }
}
