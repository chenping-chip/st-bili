package blbl.cat3399.core.util


fun pgcAccessBadgeTextOf(rawBadges: Iterable<String?>): String? {
    val badges = rawBadges.mapNotNull { it?.trim()?.takeIf(String::isNotBlank) }
    if (badges.isEmpty()) return null

    fun anyContains(token: String): Boolean = badges.any { it.contains(token) }

    return when {
        anyContains("大会员") || anyContains("会员") -> "大会员"
        anyContains("限免") -> "限免"
        anyContains("付费") -> "付费"
        else -> null
    }
}

fun pgcAccessBadgeTextOf(vararg rawBadges: String?): String? = pgcAccessBadgeTextOf(rawBadges.asIterable())
