package blbl.cat3399.core.api

import blbl.cat3399.core.log.AppLog
import blbl.cat3399.core.net.BiliClient
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaTypeOrNull
import okhttp3.MultipartBody
import okhttp3.Request
import okhttp3.RequestBody
import okhttp3.RequestBody.Companion.asRequestBody
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.IOException
import java.io.RandomAccessFile


object UploadApi {
    private const val TAG = "UploadApi"
    private const val OCTET = "application/octet-stream"
    private const val CHUNK_SIZE = 4 * 1024 * 1024L

    data class PreuploadResult(
        val auth: String,
        val endpoint: String,
        val uposUri: String,
        val filename: String,
    )

    
    private fun uploadWebHeaders(targetUrl: String): Map<String, String> {
        
        BiliClient.ensureDeviceCookies()
        val out =
            mutableMapOf(
                "User-Agent" to BiliClient.prefs.userAgent,
                "Referer" to "https://member.bilibili.com/platform/upload/video/frame",
                "Origin" to "https://member.bilibili.com",
                "Accept" to "application/json, text/plain, */*",
                "Accept-Language" to "zh-CN,zh;q=0.9",
                "Sec-Fetch-Dest" to "empty",
                "Sec-Fetch-Mode" to "cors",
                "Sec-Fetch-Site" to "same-origin",
            )
        val cookie = BiliClient.cookies.cookieHeaderFor(targetUrl)
        if (!cookie.isNullOrBlank()) out["Cookie"] = cookie
        return out
    }

    private fun requireCsrf(): String {
        val csrf = BiliClient.cookies.getCookieValue("bili_jct").orEmpty()
        if (csrf.isBlank()) {
            throw BiliApiException(apiCode = -101, apiMessage = "未登录或登录已过期（投稿需网页登录获取完整登录态）")
        }
        return csrf
    }

    private fun normalizeEndpoint(endpoint: String): String {
        var e = endpoint.trim()
        if (e.startsWith("//")) e = "https:" + e
        if (!e.startsWith("http://") && !e.startsWith("https://")) e = "https://" + e
        return e.trimEnd('/')
    }

    

    suspend fun preupload(fileName: String, size: Long): PreuploadResult {
        
        runCatching { blbl.cat3399.core.net.WebCookieMaintainer.ensureDailyMaintenance() }
        BiliClient.ensureDeviceCookies()
        val keys = BiliClient.ensureWbiKeys()
        val url =
            BiliClient.signedWbiUrlAbsolute(
                "https://member.bilibili.com/preupload",
                mapOf(
                    "name" to fileName,
                    "size" to size.toString(),
                    "r" to "upos",
                    "profile" to "ugcf",
                    "ssl" to "0",
                    "version" to "1.7.6.1",
                ),
                keys,
            )
        val json =
            try {
                BiliClient.getJson(url, headers = uploadWebHeaders(targetUrl = url))
            } catch (t: IOException) {
                if (t.message?.contains("HTTP 403") == true || t.message?.contains("HTTP 404") == true) {
                    
                    BiliClient.resetDeviceFingerprint()
                    runCatching { blbl.cat3399.core.net.WebCookieMaintainer.ensureDailyMaintenance() }
                    BiliClient.getJson(url, headers = uploadWebHeaders(targetUrl = url))
                } else {
                    throw t
                }
            }
        val ok = json.optInt("OK", 0)
        if (ok != 1) {
            throw BiliApiException(apiCode = json.optInt("code", -1), apiMessage = json.optString("message", "上传准备失败"))
        }
        val endpoint = normalizeEndpoint(json.optString("endpoint", ""))
        val uposUri = json.optString("upos_uri", "")
        val filename = json.optString("filename", uposUri)
        val auth = json.optString("auth", "")
        if (endpoint.isBlank() || uposUri.isBlank() || auth.isBlank()) {
            throw IOException("preupload 返回不完整")
        }
        return PreuploadResult(auth = auth, endpoint = endpoint, uposUri = uposUri, filename = filename)
    }

    
    suspend fun uploadWhole(res: PreuploadResult, file: File) {
        val url = res.endpoint + "/" + res.uposUri
        val body = file.asRequestBody(OCTET.toMediaTypeOrNull())
        val request =
            Request.Builder()
                .url(url)
                .put(body)
                .header("X-Upos-Auth", res.auth)
                .build()
        BiliClient.cdnOkHttp.newCall(request).execute().use { response ->
            val text = response.body?.string().orEmpty()
            if (!response.isSuccessful) {
                throw IOException("上传失败 HTTP ${response.code} ${response.message} $text")
            }
        }
    }

    
    suspend fun uploadChunked(res: PreuploadResult, file: File): String {
        val base = res.endpoint + "/" + res.uposUri
        
        val initUrl = BiliClient.withQuery(base + "?uploads", mapOf("partsize" to CHUNK_SIZE.toString()))
        val initRequest =
            Request.Builder()
                .url(initUrl)
                .post(ByteArray(0).toRequestBody(null))
                .header("X-Upos-Auth", res.auth)
                .build()
        val initText =
            BiliClient.cdnOkHttp.newCall(initRequest).execute().use { it.body?.string().orEmpty() }
        val uploadId = runCatching { JSONObject(initText).optString("upload_id", "") }.getOrNull().orEmpty()
        if (uploadId.isBlank()) throw IOException("创建上传会话失败：$initText")

        
        val total = file.length()
        val partCount = ((total + CHUNK_SIZE - 1) / CHUNK_SIZE).toInt()
        RandomAccessFile(file, "r").use { raf ->
            val buffer = ByteArray(CHUNK_SIZE.toInt())
            for (part in 1..partCount) {
                val read = raf.read(buffer)
                if (read <= 0) break
                val data = if (read == buffer.size) buffer else buffer.copyOf(read)
                val finalUrl =
                    base + "?partNumber=" + part + "&uploadId=" + uploadId
                val partRequest =
                    Request.Builder()
                        .url(finalUrl)
                        .put(data.toRequestBody(OCTET.toMediaTypeOrNull()))
                        .header("X-Upos-Auth", res.auth)
                        .build()
                BiliClient.cdnOkHttp.newCall(partRequest).execute().use { resp ->
                    if (!resp.isSuccessful) {
                        throw IOException("分片 $part 上传失败 HTTP ${resp.code} ${resp.message}")
                    }
                }
            }
        }

        
        val parts = JSONArray()
        for (i in 1..partCount) parts.put(JSONObject().put("partNumber", i))
        val completeBody = JSONObject().put("parts", parts).toString()
        val completeUrl = base + "?output=json&uploads=" + uploadId
        val completeRequest =
            Request.Builder()
                .url(completeUrl)
                .post(completeBody.toRequestBody("application/json".toMediaTypeOrNull()))
                .header("X-Upos-Auth", res.auth)
                .build()
        BiliClient.cdnOkHttp.newCall(completeRequest).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            if (!resp.isSuccessful) {
                throw IOException("上传完成失败 HTTP ${resp.code} ${resp.message} $text")
            }
        }
        return uploadId
    }

    
    suspend fun submitVideo(
        title: String,
        desc: String,
        tag: String,
        tid: Int,
        cover: String,
        dynamic: String,
        filename: String,
        copyright: Int = 1,
        source: String = "",
    ): Pair<Long, String> {
        val csrf = requireCsrf()
        val form =
            mutableMapOf(
                "copyright" to copyright.toString(),
                "source" to source,
                "tid" to tid.toString(),
                "cover" to cover,
                "title" to title,
                "desc" to desc,
                "tag" to tag,
                "dynamic" to dynamic,
                "no_reprint" to "1",
                "no_share" to "0",
                "open_elec" to "0",
                "max_retry" to "0",
                "filename" to filename,
                "csrf" to csrf,
            )
        val url = "https://member.bilibili.com/x/vu/client/add"
        val json = postMemberWithRetry(url, form)
        val code = json.optInt("code", -1)
        if (code != 0) {
            throw BiliApiException(apiCode = code, apiMessage = json.optString("message", "投稿提交失败"))
        }
        val data = json.optJSONObject("data") ?: JSONObject()
        val aid = data.optLong("aid", 0L)
        val bvid = data.optString("bvid", "")
        if (aid <= 0L) throw IOException("投稿返回数据异常")
        return aid to bvid
    }

    
    suspend fun editVideo(aid: Long, title: String, desc: String, tag: String): Boolean {
        val csrf = requireCsrf()
        val form =
            linkedMapOf(
                "aid" to aid.toString(),
                "title" to title,
                "desc" to desc,
                "tag" to tag,
                "csrf" to csrf,
            )
        val url = "https://member.bilibili.com/x/vu/client/edit"
        val json = postMemberWithRetry(url, form)
        val code = json.optInt("code", -1)
        if (code != 0) {
            throw BiliApiException(apiCode = code, apiMessage = json.optString("message", "稿件更新失败"))
        }
        return true
    }

    
    private suspend fun postMemberWithRetry(url: String, form: Map<String, String>): JSONObject {
        suspend fun postOnce(): JSONObject {
            val signedForm = blbl.cat3399.core.net.WbiSigner.signQuery(form, BiliClient.ensureWbiKeys())
            return BiliClient.postFormJson(url, signedForm, headers = uploadWebHeaders(targetUrl = url))
        }
        return try {
            postOnce()
        } catch (t: IOException) {
            if (t.message?.contains("HTTP 403") == true || t.message?.contains("HTTP 404") == true) {
                BiliClient.resetDeviceFingerprint()
                try {
                    blbl.cat3399.core.net.WebCookieMaintainer.ensureDailyMaintenance()
                } catch (_: Throwable) {
                }
                postOnce()
            } else {
                throw t
            }
        }
    }

    
    suspend fun submitArticle(
        title: String,
        content: String,
        tag: String,
        cover: String,
    ): Long {
        val csrf = requireCsrf()
        val form =
            linkedMapOf(
                "title" to title,
                "content" to content,
                "tid" to "17", 
                "tags" to tag,
                "cover" to cover,
                "csrf" to csrf,
            )
        val url = "https://api.bilibili.com/x/article/creat"
        val json = BiliClient.postFormJson(url, form = form, headers = uploadWebHeaders(targetUrl = url))
        val code = json.optInt("code", -1)
        if (code != 0) {
            throw BiliApiException(apiCode = code, apiMessage = json.optString("message", "专栏发布失败"))
        }
        return json.optJSONObject("data")?.optLong("id", 0L) ?: 0L
    }

    

    
    suspend fun uploadDynamicImage(file: File): String {
        val csrf = requireCsrf()
        val body =
            MultipartBody.Builder()
                .setType(MultipartBody.FORM)
                .addFormDataPart("file", file.name, file.asRequestBody("image/*".toMediaTypeOrNull()))
                .addFormDataPart("csrf", csrf)
                .build()
        val raw =
            BiliClient.requestString(
                url = "https://api.bilibili.com/x/dynamic/upload",
                method = "POST",
                body = body,
            )
        val json = withContext(Dispatchers.Default) { JSONObject(raw) }
        val code = json.optInt("code", -1)
        if (code != 0) {
            throw BiliApiException(apiCode = code, apiMessage = json.optString("message", "图片上传失败"))
        }
        val url = json.optJSONObject("data")?.optString("image_url", "").orEmpty()
        if (url.isBlank()) throw IOException("图片上传返回为空")
        return url
    }

    
    suspend fun publishDraw(text: String, imageUrls: List<String>): Boolean {
        val csrf = requireCsrf()
        val upUid = BiliClient.cookies.getCookieValue("DedeUserID").orEmpty()
        val payload =
            JSONObject()
                .put("category", 4)
                .put("dynamic_id", "0")
                .put("up_uid", upUid)
                .put("ext", JSONObject().put("emots", JSONObject()).put("ctrl", "").toString())
                .put("content", text)
                .put("images", JSONArray(imageUrls))
                .put("tags", "")
                .toString()
        val raw =
            BiliClient.requestString(
                url = "https://api.bilibili.com/x/pc/publish",
                method = "POST",
                body = payload.toRequestBody("application/json".toMediaTypeOrNull()),
            )
        val json = withContext(Dispatchers.Default) { JSONObject(raw) }
        val code = json.optInt("code", -1)
        if (code != 0) {
            throw BiliApiException(apiCode = code, apiMessage = json.optString("message", "发布失败"))
        }
        return true
    }

    
    val UPLOAD_TIDS: List<Pair<Int, String>> =
        listOf(
            1 to "动画",
            3 to "音乐",
            17 to "游戏",
            36 to "知识",
            188 to "科技",
            234 to "运动",
            223 to "汽车",
            160 to "生活",
            76 to "美食",
            75 to "动物圈",
            239 to "VLOG",
            119 to "鬼畜",
            155 to "时尚",
            202 to "资讯",
            5 to "娱乐",
            181 to "影视",
            37 to "纪录片",
            23 to "电影",
            11 to "电视剧",
        )
}
