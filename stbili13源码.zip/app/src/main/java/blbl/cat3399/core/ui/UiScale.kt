package blbl.cat3399.core.ui

import android.content.Context
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs

object UiScale {
    
    
    const val BASELINE_DENSITY = 1.5f
    const val BASELINE_SHORT_SIDE_PX = 1080f

    
    fun factor(context: Context): Float {
        val prefs =
            try {
                BiliClient.prefs
            } catch (_: UninitializedPropertyAccessException) {
                AppPrefs(context.applicationContext)
            }
        val raw = prefs.uiScaleFactor
        return raw.coerceIn(AppPrefs.UI_SCALE_FACTOR_MIN, AppPrefs.UI_SCALE_FACTOR_MAX)
    }
}
