package blbl.cat3399.core.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import blbl.cat3399.R
import blbl.cat3399.core.net.BiliClient
import blbl.cat3399.core.prefs.AppPrefs
import blbl.cat3399.feature.live.LivePlayerActivity
import blbl.cat3399.feature.player.PlayerActivity

object ThemePresets {
    data class Spec(
        val baseThemeRes: Int,
        val overlayRes: Int? = null,
    )

    fun applyTo(activity: Activity) {
        val spec = resolve(activity)
        activity.setTheme(spec.baseThemeRes)
        spec.overlayRes?.let { activity.theme.applyStyle(it, true) }
    }

    fun resolve(context: Context): Spec {
        
        val activity = context.findActivity()
        if (activity is PlayerActivity || activity is LivePlayerActivity) {
            return Spec(baseThemeRes = R.style.Theme_Blbl_Player_Fixed, overlayRes = null)
        }

        val prefs = runCatching { BiliClient.prefs }.getOrNull()
        val preset =
            AppPrefs.normalizeThemePreset(
                prefs?.themePreset,
            )
        val brightness =
            AppPrefs.normalizeThemeBrightness(
                prefs?.themeBrightness,
            )
        val md3 = prefs?.md3UiEnabled == true
        val accent =
            AppPrefs.normalizeThemeAccent(
                prefs?.themeAccent,
            )

        fun accentOverlay(): Int =
            when (accent) {
                AppPrefs.THEME_ACCENT_PINK -> R.style.ThemeOverlay_Blbl_Accent_TvPink
                AppPrefs.THEME_ACCENT_BLUE -> R.style.ThemeOverlay_Blbl_Accent_Blue
                AppPrefs.THEME_ACCENT_GREEN -> R.style.ThemeOverlay_Blbl_Accent_Green
                AppPrefs.THEME_ACCENT_ORANGE -> R.style.ThemeOverlay_Blbl_Accent_Orange
                AppPrefs.THEME_ACCENT_RED -> R.style.ThemeOverlay_Blbl_Accent_Red
                else -> R.style.ThemeOverlay_Blbl_Accent_Violet
            }

        return when (preset) {
            AppPrefs.THEME_PRESET_TV_PINK ->
                if (md3) {
                    Spec(
                        baseThemeRes = R.style.Theme_Blbl_Md3_Light,
                        overlayRes = R.style.ThemeOverlay_Blbl_Accent_TvPink,
                    )
                } else {
                    Spec(
                        baseThemeRes = R.style.Theme_Blbl_Base_PinkLight,
                        overlayRes = R.style.ThemeOverlay_Blbl_Accent_TvPink,
                    )
                }

            AppPrefs.THEME_PRESET_TV_PINK_ILLUSTRATION ->
                if (md3) {
                    Spec(
                        baseThemeRes = R.style.Theme_Blbl_Md3_Light,
                        overlayRes = R.style.ThemeOverlay_Blbl_Accent_Classic,
                    )
                } else {
                    Spec(
                        baseThemeRes = R.style.Theme_Blbl_Base_TvPinkIllustration,
                        overlayRes = R.style.ThemeOverlay_Blbl_Accent_Classic,
                    )
                }

            else ->
                when (brightness) {
                    AppPrefs.THEME_BRIGHTNESS_LIGHT ->
                        if (md3) {
                            Spec(
                                baseThemeRes = R.style.Theme_Blbl_Md3_Light,
                                overlayRes = accentOverlay(),
                            )
                        } else {
                            Spec(
                                baseThemeRes = R.style.Theme_Blbl_Base_Light,
                                overlayRes = accentOverlay(),
                            )
                        }

                    else ->
                        if (md3) {
                            Spec(
                                baseThemeRes = R.style.Theme_Blbl_Md3_Dark,
                                overlayRes = accentOverlay(),
                            )
                        } else {
                            Spec(
                                baseThemeRes = R.style.Theme_Blbl_Base_Dark,
                                overlayRes = accentOverlay(),
                            )
                        }
                }
        }
    }

    private fun Context.findActivity(): Activity? {
        var current: Context? = this
        while (current is ContextWrapper) {
            if (current is Activity) return current
            current = current.baseContext
        }
        return current as? Activity
    }
}
