package blbl.cat3399.ui


interface SidebarFocusHost {
    
    fun requestFocusSidebarSelectedNav(): Boolean
}

